import re

# ===================================================
# --- TERMINAL ANSI PARSER (For GUI Emulation) ---
# ===================================================
def ansi_to_html(text):
    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
    html_text = text.replace('<', '&lt;').replace('>', '&gt;')
    colors = {
        '30': 'black', '31': '#ff0000', '32': '#00ff00', '33': '#ffff00',
        '34': '#0000ff', '35': '#ff00ff', '36': '#00ffff', '37': 'white',
        '90': '#808080', '91': '#ff0000', '92': '#00ff00', '93': '#ffff00',
        '94': '#0000ff', '95': '#ff00ff', '96': '#00ffff', '97': '#ffffff'
    }
    for code, color in colors.items():
        html_text = html_text.replace(f'\x1b[{code}m', f'<span style="color: {color};">')
    html_text = html_text.replace('\x1b[0m', '</span>')
    return ansi_escape.sub('', html_text) 

# ===================================================
# --- CLI MODE HANDLERS (INTERACTIVE & HEADLESS) ---
# ===================================================

def print_banner():
    print("\033[92m")
    print(r"""
     █████╗ ██╗     ██╗    ██████╗  █████╗ ███████╗ █████╗ 
    ██╔══██╗██║     ██║    ██╔══██╗██╔══██╗╚══███╔╝██╔══██╗
    ███████║██║     ██║    ██████╔╝███████║  ███╔╝ ███████║
    ██╔══██║██║     ██║    ██╔══██╗██╔══██║ ███╔╝  ██╔══██║
    ██║  ██║███████╗██║    ██║  ██║██║  ██║███████╗██║  ██║
    ╚═╝  ╚═╝╚══════╝╚═╝    ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝
    
         ALI RAZA RECON FRAMEWORK (ARF) v1.0
           "Automate. Discover. Dominate."
    """)
    print("\033[0m")