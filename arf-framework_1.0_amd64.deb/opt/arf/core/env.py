import os
import sys

# --- ULTIMATE SILENCER FOR KALI LINUX TERMINAL SPAM ---
os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = "--disable-gpu --no-sandbox --disable-software-rasterizer --disable-dev-shm-usage --disable-logging --log-level=3"
os.environ["QT_LOGGING_RULES"] = "*=false" 
os.environ["QT_MAC_DISABLE_FOREGROUND_CG_PROMPT"] = "1"

# ===================================================
# --- NEW: SYSTEM MONITOR DEPENDENCY ---
# ===================================================
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False

# ===================================================
# --- OS TASKBAR ICON FIX (For Windows) ---
# ===================================================
try:
    import ctypes
    # Tells Windows this is a standalone app, not just a generic python script
    myappid = 'aliraza.reconframework.arf.v2'
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)
except Exception:
    pass

# ===================================================
# --- OPTIONAL DEPENDENCIES ---
# ===================================================
try:
    import shodan
    SHODAN_AVAILABLE = True
except ImportError:
    SHODAN_AVAILABLE = False

try:
    from fpdf import FPDF, XPos, YPos
    FPDF_AVAILABLE = True
except ImportError:
    FPDF_AVAILABLE = False

try:
    from playwright.async_api import async_playwright
    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    PLAYWRIGHT_AVAILABLE = False