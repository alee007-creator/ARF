import os
import json
from core.database import db

# ===================================================
# --- PERSISTENCE & CONFIGURATION SYSTEM ---
# ===================================================
CONFIG_FILE = "config.json"

def initialize_environment():
    """Builds the local ecosystem for the framework."""
    # 1. Create essential output directories
    dirs = ["Scan_Results", "Spider_Wordlists"]
    for d in dirs:
        if not os.path.exists(d):
            os.makedirs(d, exist_ok=True)
            print(f"\033[94m[*] Created Workspace Directory: {d}/\033[0m")

    # 2. Initialize Database
    # This triggers the file creation for arf_vault.db if it's missing
    # We no longer instantiate ARFDatabase here because we import 'db' directly!
    try:
        # Just checking if the imported db object exists/connected
        if db:
            print(f"\033[94m[*] SQLite Vault Verified.\033[0m")
    except Exception as e:
        print(f"\033[91m[!] Database Initialization Failed: {e}\033[0m")

def load_config():
    # 1. Define the completely neutral template
    default_config = {
        "project_name": "Default_Workspace",
        "shodan_keys": {"Default_Workspace": ""},
        "webhook_urls": {"Default_Workspace": ""},
        "out_of_scope": {"Default_Workspace": ""},
        "api_keys": {
            "vt": "",
            "greynoise": "",
            "pulsedive": "",
            "censys_id": ""
        },
        "history": {"Default_Workspace": []},
        "manual_history": {"Default_Workspace": []},
        "custom_presets": {
            "nmap": {}, "subfinder": {}, "assetfinder": {}, "amass": {},
            "dnsx": {}, "tlsx": {}, "naabu": {}, "httpx": {},
            "nuclei": {}, "whatweb": {}, "wafw00f": {}, "ffuf": {},
            "wfuzz": {}, "katana": {}, "gau": {}, "cloud_enum": {},
            "dig": {}, "nslookup": {}, "holehe": {}, "theHarvester": {},
            "whois": {}, "nikto": {}, "searchsploit": {}
        },
        "wireless_enabled": False
    }

    # 2. If the file doesn't exist, create it and return defaults
    if not os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, 'w') as f:
                json.dump(default_config, f, indent=4)
            print(f"[+] Initialized fresh generic configuration: {CONFIG_FILE}")
        except Exception as e:
            print(f"[!] Warning: Could not create config file: {e}")
        return default_config

    # 3. If file exists, load and run your migration logic
    try:
        with open(CONFIG_FILE, 'r') as f:
            data = json.load(f)
            current_proj = data.get("project_name", "Default_Workspace")

            # --- MIGRATION LOGIC (Ensures older configs get new fields) ---
            keys_to_check = ["shodan_keys", "webhook_urls", "out_of_scope", "history", "manual_history"]
            for key in keys_to_check:
                if key not in data or not isinstance(data[key], dict):
                    data[key] = {current_proj: "" if "history" not in key else []}
                if current_proj not in data[key]:
                    data[key][current_proj] = "" if "history" not in key else []

            if "api_keys" not in data:
                data["api_keys"] = default_config["api_keys"]

            if "custom_presets" not in data:
                data["custom_presets"] = default_config["custom_presets"]

            if "wireless_enabled" not in data:
                data["wireless_enabled"] = False

            return data
    except Exception:
        return default_config
    
def save_config(config):
    """Safely commits the current application state to config.json."""
    try:
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=4)
        # Optional: Print a silent debug message for CLI users
        # print(f"\033[94m[*] Configuration state synchronized.\033[0m")
    except Exception as e:
        print(f"\033[91m[!] FATAL: Failed to write to {CONFIG_FILE}: {e}\033[0m")