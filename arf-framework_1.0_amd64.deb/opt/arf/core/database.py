import sqlite3
import threading
import ast
import datetime

# ===================================================
# --- SQLITE3 RELATIONAL DATABASE ENGINE ---
# ===================================================
class ARFDatabase:
    def __init__(self, db_path="arf_vault.db"):
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.lock = threading.RLock() # <--- THE FIX: Upgraded to Re-entrant Lock
        self.cursor = self.conn.cursor() 
        self.setup_tables()

    def setup_tables(self):
        with self.lock:
            # 1. Create schemas with the NEW 'workspace' and 'exec_mode' columns included
            self.cursor.execute("""
                CREATE TABLE IF NOT EXISTS scans (
                    scan_id TEXT PRIMARY KEY,
                    workspace TEXT,
                    target TEXT,
                    scan_type TEXT,
                    timestamp TEXT,
                    risk_score INTEGER,
                    exec_mode TEXT
                )
            """)
            self.cursor.execute("""
                CREATE TABLE IF NOT EXISTS assets (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    scan_id TEXT,
                    workspace TEXT,
                    subdomain TEXT,
                    ip TEXT,
                    os TEXT,
                    waf TEXT,
                    js_secrets INTEGER,
                    services TEXT,
                    vulns TEXT,
                    lat REAL,
                    lon REAL,
                    city TEXT,
                    country TEXT,
                    exec_mode TEXT
                )
            """)
            self.cursor.execute("""
                CREATE TABLE IF NOT EXISTS tool_outputs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    scan_id TEXT,
                    workspace TEXT,
                    tool_name TEXT,
                    raw_text TEXT,
                    exec_mode TEXT
                )
            """)

            # 2. SMART MIGRATION: Safely inject columns into an existing DB file
            migrations = [
                "ALTER TABLE scans ADD COLUMN exec_mode TEXT DEFAULT 'GUI'",
                "ALTER TABLE assets ADD COLUMN exec_mode TEXT DEFAULT 'GUI'",
                "ALTER TABLE tool_outputs ADD COLUMN exec_mode TEXT DEFAULT 'GUI'",
                "ALTER TABLE assets ADD COLUMN workspace TEXT DEFAULT 'Unknown'",
                "ALTER TABLE tool_outputs ADD COLUMN workspace TEXT DEFAULT 'Unknown'"
            ]
            for query in migrations:
                try:
                    self.cursor.execute(query)
                except sqlite3.OperationalError:
                    pass # Column already exists, safe to ignore

            self.conn.commit()

    def _get_ws_and_mode_for_scan(self, sid):
        """Internal Helper: Auto-fetches the workspace and exec_mode for a given scan_id."""
        self.cursor.execute("SELECT workspace, exec_mode FROM scans WHERE scan_id=?", (sid,))
        res = self.cursor.fetchone()
        return (res[0], res[1]) if res else ("Unknown", "GUI")

    def save_scan_meta(self, sid, ws, target, stype, risk, exec_mode="GUI"):
        ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self.lock:
            self.conn.execute("""
                INSERT OR REPLACE INTO scans (scan_id, workspace, target, scan_type, timestamp, risk_score, exec_mode) 
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (sid, ws, target, stype, ts, risk, exec_mode))
            self.conn.commit()

    def save_asset(self, sid, sub, ip, os_val, waf, secrets, services, vulns, lat, lon, city, country, workspace=None, exec_mode=None):
        with self.lock:
            # Auto-lookup workspace and mode if not explicitly passed
            ws_fallback, mode_fallback = self._get_ws_and_mode_for_scan(sid)
            ws = workspace if workspace else ws_fallback
            em = exec_mode if exec_mode else mode_fallback
            
            self.conn.execute("""
                INSERT INTO assets (scan_id, workspace, subdomain, ip, os, waf, js_secrets, services, vulns, lat, lon, city, country, exec_mode) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (sid, ws, sub, ip, os_val, waf, secrets, str(services), str(vulns), lat, lon, city, country, em))
            self.conn.commit()

    def save_tool_output(self, sid, tool, text, workspace=None, exec_mode=None):
        with self.lock:
            # Auto-lookup workspace and mode if not explicitly passed
            ws_fallback, mode_fallback = self._get_ws_and_mode_for_scan(sid)
            ws = workspace if workspace else ws_fallback
            em = exec_mode if exec_mode else mode_fallback
            
            self.conn.execute("INSERT INTO tool_outputs (scan_id, workspace, tool_name, raw_text, exec_mode) VALUES (?, ?, ?, ?, ?)", (sid, ws, tool, text, em))
            self.conn.commit()

    def delete_tool_output(self, sid, tool):
        with self.lock:
            self.conn.execute("DELETE FROM tool_outputs WHERE scan_id=? AND tool_name=?", (sid, tool))
            self.conn.commit()

    def get_asset_data(self, scan_id):
        rows = []  
        data = {}
        
        with self.lock:
            try:
                cursor = self.conn.cursor()
                cursor.execute("SELECT subdomain, ip, os, waf, js_secrets, services, vulns, lat, lon, city, country FROM assets WHERE scan_id=?", (scan_id,))
                rows = cursor.fetchall()
            except Exception as e:
                print(f"[!] SQLite Read Error in get_asset_data: {e}")
                
        for r in rows:
            try:
                data[r[0]] = {
                    "ip": r[1], "os": r[2], "waf": r[3], "js_secrets": r[4],
                    "services": ast.literal_eval(r[5]) if r[5] else {},
                    "vulns": ast.literal_eval(r[6]) if r[6] else [],
                    "lat": r[7], "lon": r[8], "city": r[9], "country": r[10],
                    "screenshot": "Failed" 
                }
            except Exception:
                continue

        return data

    def get_tool_logs(self, scan_id):
        with self.lock:
            cursor = self.conn.cursor()
            cursor.execute("SELECT tool_name, raw_text FROM tool_outputs WHERE scan_id=?", (scan_id,))
            return cursor.fetchall()
            
    def get_scan_risk(self, scan_id):
        with self.lock:
            cursor = self.conn.cursor()
            cursor.execute("SELECT risk_score FROM scans WHERE scan_id=?", (scan_id,))
            res = cursor.fetchone()
            return res[0] if res else 0 
        
    def save_asset_data(self, scan_id, data_dict):
        """Iterates through parsed JSON assets and saves them to the relational table."""
        for target, info in data_dict.items():
            ip_val = info.get("ip", "Unknown")
            services_val = info.get("services", {})
            vulns_val = info.get("vulns", [])
            
            # Feed the parsed data into your existing, robust save_asset function!
            self.save_asset(
                sid=scan_id,
                sub=target,
                ip=ip_val,
                os_val="Unknown",
                waf="Unknown",
                secrets=0,
                services=services_val,
                vulns=vulns_val,
                lat=0.0,
                lon=0.0,
                city="Unknown",
                country="Unknown"
            )

# Instantiate the global database object
db = ARFDatabase()