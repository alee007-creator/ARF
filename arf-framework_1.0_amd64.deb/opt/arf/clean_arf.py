import os
import shutil

# --- FILES CONTAINING SENSITIVE DATA OR HISTORY ---
files_to_kill = [
    "config.json",     # Contains API keys, Webhooks, and Workspace Scope rules
    "arf_vault.db"     # SQLite Vault containing all historical scans, assets, and logs
]

# --- DIRECTORIES CONTAINING SCAN ARTIFACTS & ENVS ---
folders_to_kill = [
    "Scan_Results",    # Target reports, Executive PDFs, Network Graphs, Raw Text
    "Spider_Wordlists",# Automatically generated wordlists from the web crawler
    "__pycache__",     # Python execution cache
    "venv"             # Virtual Environment
]

print("\033[93m[*] Framework Sanitization & Factory Reset Initiated...\033[0m")

# 1. Erase Sensitive Files (Config & Database)
for f in files_to_kill:
    if os.path.exists(f):
        try:
            os.remove(f)
            print(f"\033[91m[-] Purged Vault/Config: {f}\033[0m")
        except Exception as e:
            print(f"\033[91m[!] Error deleting {f}: {e}\033[0m")

# 2. Erase Data Directories (Reports, Wordlists & Venv)
for d in folders_to_kill:
    if os.path.exists(d):
        try:
            shutil.rmtree(d)
            print(f"\033[91m[-] Nuked Directory: {d}/\033[0m")
        except Exception as e:
            print(f"\033[91m[!] Error deleting {d}: {e}\033[0m")

print("\n\033[92m[+] Sanitization Complete. The framework is zeroed out and ready for distribution.\033[0m")