import sys, os, tempfile, subprocess, re, time, getpass
from PyQt6.QtCore import QCoreApplication
from core.config import load_config, save_config
from core.database import db
from core.utils import print_banner, ansi_to_html
from workers.recon_worker import AdvancedReconWorker
from workers.autoscan_workers import DomainAutoScanWorker, IPAutoScanWorker
from workers.spider_worker import SpiderWorker
from workers.cmd_workers import ToolWorker
from gui.all_tabs import InstallationTab

def interactive_cli_menu():
    """The Metasploit-style interactive terminal menu."""
    print_banner()
    print("[+] Initializing Headless Interactive Console...")
    
    temp_config = load_config()
    cli_api_keys = temp_config.get("api_keys", {})

    while True:
        # Reload config in case it was modified in a previous loop iteration
        temp_config = load_config()
        active_proj = temp_config.get("project_name", "Default_Workspace")

        print("\n\033[96m[--- ARF TACTICAL COMMAND MENU ---]\033[0m")
        print(f"  \033[93mActive Workspace: [{active_proj}]\033[0m\n")
        print("  [1] Live Reconnaissance Pipeline (Full Async Engine)")
        print("  [2] Domain Kill-Chain (19 Bash Tools)")
        print("  [3] IP Address Kill-Chain (12 Bash Tools)")
        print("  [4] Spider Target (Generate Contextual Wordlist)")
        print("  [5] Execute Single Arsenal Tool")
        print("  [6] Install / Update ARF Tools")
        print("  [7] Workspace & Config Manager")
        print("  [0] Exit Framework")
        
        choice = input("\n\033[91mARF>\033[0m Select an option: ").strip()
        
        if choice == "0":
            print("[*] Terminating framework. Goodbye.")
            sys.exit(0)
            
        if choice not in ["1", "2", "3", "4", "5", "6", "7"]:
            print("[-] Invalid choice. Please select 0-7.")
            continue

        # --- Handle Workspace Manager ---
        if choice == "7":
            print("\n\033[96m[!] ARF WORKSPACE MANAGER\033[0m")
            
            # Fetch all known workspaces from DB and Config
            workspaces = set()
            try:
                with db.lock:
                    db.cursor.execute("SELECT DISTINCT workspace FROM scans")
                    for row in db.cursor.fetchall():
                        workspaces.add(row[0])
            except Exception: pass
            
            for ws in temp_config.get("shodan_keys", {}).keys():
                workspaces.add(ws)
            workspaces.add(active_proj)
            
            print("\n\033[93m--- Existing Workspaces ---\033[0m")
            ws_list = sorted(list(workspaces))
            for idx, w in enumerate(ws_list):
                print(f"  [{idx}] {w}")
                
            print("\n[+] Enter the number of an existing workspace to load/edit.")
            print("[+] Or type a NEW name to create a new workspace.")
            ws_input = input("ARF> Selection / Name: ").strip()
            
            if ws_input.isdigit() and 0 <= int(ws_input) < len(ws_list):
                selected_ws = ws_list[int(ws_input)]
            elif ws_input:
                selected_ws = ws_input
            else:
                print("[-] Invalid input. Returning to menu.")
                continue
                
            print(f"\n[*] Configuring Workspace: \033[92m{selected_ws}\033[0m")
            
            # Get current values if they exist, to allow hitting Enter to keep them
            cur_shodan = temp_config.get("shodan_keys", {}).get(selected_ws, "")
            cur_webhook = temp_config.get("webhook_urls", {}).get(selected_ws, "")
            cur_scope = temp_config.get("out_of_scope", {}).get(selected_ws, "")
            
            new_shodan = input(f"Shodan Key [{cur_shodan}]: ").strip() or cur_shodan
            new_webhook = input(f"Webhook URL [{cur_webhook}]: ").strip() or cur_webhook
            new_scope = input(f"Out of Scope Regex [{cur_scope}]: ").strip() or cur_scope
            
            # Ensure dicts exist
            if "shodan_keys" not in temp_config: temp_config["shodan_keys"] = {}
            if "webhook_urls" not in temp_config: temp_config["webhook_urls"] = {}
            if "out_of_scope" not in temp_config: temp_config["out_of_scope"] = {}
            
            # Save data
            temp_config["shodan_keys"][selected_ws] = new_shodan
            temp_config["webhook_urls"][selected_ws] = new_webhook
            temp_config["out_of_scope"][selected_ws] = new_scope
            temp_config["project_name"] = selected_ws
            
            save_config(temp_config)
            print(f"\n\033[92m[+] Workspace '{selected_ws}' saved and set as ACTIVE.\033[0m")
            continue

        # --- Handle Installer separately since it doesn't need targets ---
        if choice == "6":
            print("\n\033[96m[!] ARF INSTALLATION & UPDATE MANAGER\033[0m")
            print("  [1] Master Bootstrapper (Full OS Upgrade + Compile All Tools)")
            print("  [2] Targeted Updater (Select a specific module to install/update)")
            
            sub_choice = input("\nARF> Select an option: ").strip()
            # LAZY LOAD GUI COMPONENT ONLY WHEN NEEDED
            # We don't need the whole Qt app just to grab the dictionary!
            
            # Extracting the install map statically to avoid loading QWidget
            install_map = {
                "Ollama (AI Engine)": "curl -fsSL https://ollama.com/install.sh | sh",
                "cloud_enum (with Path Fix)": """
git clone https://github.com/initstring/cloud_enum.git /opt/cloud_enum 2>/dev/null || git -C /opt/cloud_enum pull
pip3 install --break-system-packages -r /opt/cloud_enum/requirements.txt || pip3 install -r /opt/cloud_enum/requirements.txt
rm -f /usr/local/bin/cloud_enum
echo -e '#!/bin/bash\ncd /opt/cloud_enum && /usr/bin/python3 cloud_enum.py "$@"' > /usr/local/bin/cloud_enum
chmod +x /usr/local/bin/cloud_enum
""",
                "subfinder": "export GOPATH=$HOME/go; export PATH=$PATH:/usr/local/go/bin:$GOPATH/bin; go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest && cp $HOME/go/bin/* /usr/local/bin/ 2>/dev/null || true",
                "httpx": "export GOPATH=$HOME/go; export PATH=$PATH:/usr/local/go/bin:$GOPATH/bin; go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest && cp $HOME/go/bin/* /usr/local/bin/ 2>/dev/null || true",
                "naabu": "export GOPATH=$HOME/go; export PATH=$PATH:/usr/local/go/bin:$GOPATH/bin; go install -v github.com/projectdiscovery/naabu/v2/cmd/naabu@latest && cp $HOME/go/bin/* /usr/local/bin/ 2>/dev/null || true",
                "katana": "export GOPATH=$HOME/go; export PATH=$PATH:/usr/local/go/bin:$GOPATH/bin; go install -v github.com/projectdiscovery/katana/cmd/katana@latest && cp $HOME/go/bin/* /usr/local/bin/ 2>/dev/null || true",
                "nuclei": "export GOPATH=$HOME/go; export PATH=$PATH:/usr/local/go/bin:$GOPATH/bin; go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest && cp $HOME/go/bin/* /usr/local/bin/ 2>/dev/null || true",
                "dnsx": "export GOPATH=$HOME/go; export PATH=$PATH:/usr/local/go/bin:$GOPATH/bin; go install -v github.com/projectdiscovery/dnsx/cmd/dnsx@latest && cp $HOME/go/bin/* /usr/local/bin/ 2>/dev/null || true",
                "tlsx": "export GOPATH=$HOME/go; export PATH=$PATH:/usr/local/go/bin:$GOPATH/bin; go install -v github.com/projectdiscovery/tlsx/cmd/tlsx@latest && cp $HOME/go/bin/* /usr/local/bin/ 2>/dev/null || true",
                "ffuf": "export GOPATH=$HOME/go; export PATH=$PATH:/usr/local/go/bin:$GOPATH/bin; go install -v github.com/ffuf/ffuf/v2@latest && cp $HOME/go/bin/* /usr/local/bin/ 2>/dev/null || true",
                "gau": "export GOPATH=$HOME/go; export PATH=$PATH:/usr/local/go/bin:$GOPATH/bin; go install -v github.com/lc/gau/v2/cmd/gau@latest && cp $HOME/go/bin/* /usr/local/bin/ 2>/dev/null || true",
                "assetfinder": "export GOPATH=$HOME/go; export PATH=$PATH:/usr/local/go/bin:$GOPATH/bin; go install -v github.com/tomnomnom/assetfinder@latest && cp $HOME/go/bin/* /usr/local/bin/ 2>/dev/null || true",
                "amass": "export GOPATH=$HOME/go; export PATH=$PATH:/usr/local/go/bin:$GOPATH/bin; go install -v github.com/owasp-amass/amass/v4/...@master && cp $HOME/go/bin/* /usr/local/bin/ 2>/dev/null || true",
                "Python Core (Shodan, fpdf2, Playwright...)": "pip3 install --break-system-packages shodan fpdf2 playwright beautifulsoup4 aiohttp dnspython requests PyQt6 PyQt6-WebEngine psutil pyvis holehe lxml orjson maigret sherlock maltego-trx || pip3 install shodan fpdf2 playwright beautifulsoup4 aiohttp dnspython requests PyQt6 PyQt6-WebEngine psutil pyvis holehe lxml orjson maigret sherlock maltego-trx; playwright install chromium",
                "GitDorker (Automated Search)": """
git clone https://github.com/obheda12/GitDorker.git /opt/GitDorker 2>/dev/null || git -C /opt/GitDorker pull
pip3 install --break-system-packages -r /opt/GitDorker/requirements.txt || pip3 install -r /opt/GitDorker/requirements.txt
rm -f /usr/local/bin/gitdorker
echo -e '#!/bin/bash\ncd /opt/GitDorker && /usr/bin/python3 GitDorker.py "$@"' > /usr/local/bin/gitdorker
chmod +x /usr/local/bin/gitdorker
""",
                "Native Packages (Nmap, Nikto, Whois...)": """
if command -v apt-get &> /dev/null; then apt-get update -y && apt-get install -y whois dnsutils nmap whatweb wafw00f wfuzz nikto exploitdb theharvester git wget curl libpcap-dev python3-pyqt6.qtwebengine;
elif command -v dnf &> /dev/null; then dnf install -y whois bind-utils nmap whatweb wafw00f wfuzz nikto exploitdb theharvester git wget curl libpcap-devel python3-qt6-webengine;
elif command -v pacman &> /dev/null; then pacman -S --noconfirm whois bind nmap whatweb wafw00f wfuzz nikto exploitdb theharvester git wget curl libpcap python-pyqt6-webengine;
else echo "Unsupported package manager for native tools."; fi
"""
            }
            
            if sub_choice == "1":
                print("\nSupported OS: ubuntu, debian, mint, fedora, arch")
                distro = input("Enter your OS distribution: ").strip().lower()
                if distro not in ["ubuntu", "debian", "mint", "fedora", "arch"]:
                    print("[-] Unsupported OS. Returning to menu.")
                    continue
                
                # Manual injection of generate script to avoid GUI load
                go_and_python_script = """
echo "[*] Installing Python Tool Dependencies..."
pip3 install --break-system-packages shodan fpdf2 playwright beautifulsoup4 aiohttp dnspython requests PyQt6 PyQt6-WebEngine psutil pyvis holehe lxml orjson || pip3 install shodan fpdf2 playwright beautifulsoup4 aiohttp dnspython requests PyQt6 PyQt6-WebEngine psutil pyvis holehe lxml orjson
playwright install chromium

echo "[*] Checking Ollama (AI Engine) Status..."
if ! command -v ollama &> /dev/null; then
    echo "[-] Ollama not found. Installing now..."
    curl -fsSL https://ollama.com/install.sh | sh
else
    echo "[+] Ollama is already installed. Skipping to save bandwidth."
fi

echo "[*] Setting up Golang Compiler Environment..."
export GOPATH=$HOME/go
export PATH=$PATH:/usr/local/go/bin:$GOPATH/bin
echo "[*] Compiling Advanced Recon Tools from Source (This may take a few minutes)..."
go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
go install -v github.com/tomnomnom/assetfinder@latest
go install -v github.com/owasp-amass/amass/v4/...@master
go install -v github.com/projectdiscovery/naabu/v2/cmd/naabu@latest
go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest
go install -v github.com/projectdiscovery/katana/cmd/katana@latest
go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest
go install -v github.com/lc/gau/v2/cmd/gau@latest
go install -v github.com/ffuf/ffuf/v2@latest
go install -v github.com/projectdiscovery/dnsx/cmd/dnsx@latest
go install -v github.com/projectdiscovery/tlsx/cmd/tlsx@latest

echo "[*] Cloning & Configuring Cloud Enum..."
if [ ! -d "/opt/cloud_enum" ]; then
    git clone https://github.com/initstring/cloud_enum.git /opt/cloud_enum 2>/dev/null
else
    git -C /opt/cloud_enum pull
fi
pip3 install --break-system-packages -r /opt/cloud_enum/requirements.txt || pip3 install -r /opt/cloud_enum/requirements.txt
rm -f /usr/local/bin/cloud_enum
echo -e '#!/bin/bash\ncd /opt/cloud_enum && /usr/bin/python3 cloud_enum.py "$@"' > /usr/local/bin/cloud_enum
chmod +x /usr/local/bin/cloud_enum

echo "[*] Symlinking Go Binaries to Universal Path..."
cp $HOME/go/bin/* /usr/local/bin/ 2>/dev/null || true
echo "✅ MASTER BOOTSTRAP COMPLETE"
"""
                if distro in ["ubuntu", "debian", "mint"]:
                    script = f"#!/bin/bash\necho '[*] Performing APT OS Upgrade...'\napt-get update -y && apt-get full-upgrade -y\necho '[*] Installing native APT dependencies...'\napt-get install -y python3-pip golang whois dnsutils nmap whatweb wafw00f wfuzz nikto exploitdb theharvester git wget curl libpcap-dev python3-pyqt6.qtwebengine\n{go_and_python_script}"
                elif distro == "fedora":
                    script = f"#!/bin/bash\necho '[*] Performing DNF OS Upgrade...'\ndnf update -y\necho '[*] Installing native DNF dependencies...'\ndnf install -y python3-pip golang whois bind-utils nmap whatweb wafw00f wfuzz nikto git wget curl libpcap-devel python3-qt6-webengine\n{go_and_python_script}"
                elif distro == "arch":
                    script = f"#!/bin/bash\necho '[*] Performing Pacman OS Upgrade...'\npacman -Syu --noconfirm\necho '[*] Installing native Pacman dependencies...'\npacman -S --noconfirm python-pip go whois bind nmap whatweb wafw00f wfuzz nikto exploitdb git wget curl libpcap python-pyqt6-webengine\n{go_and_python_script}"
                
            elif sub_choice == "2":
                print("\n\033[93m--- Available Modules ---\033[0m")
                tools = list(install_map.keys())
                for idx, t in enumerate(tools):
                    print(f"  [{idx}] {t}")
                    
                tool_idx = input("\nARF> Select module number to update: ").strip()
                if not tool_idx.isdigit() or int(tool_idx) < 0 or int(tool_idx) >= len(tools):
                    print("[-] Invalid selection. Returning to menu.")
                    continue
                    
                selected_tool = tools[int(tool_idx)]
                bash_command = install_map[selected_tool]
                script = f"#!/bin/bash\necho '[*] Executing Targeted Build Script for: {selected_tool}...'\n{bash_command}\necho '✅ UPDATE COMPLETE'"
            else:
                print("[-] Invalid choice. Returning to menu.")
                continue

            import getpass
            pwd = getpass.getpass("\n[🔒] Enter sudo password to authorize installation: ")
            
            fd, temp_path = tempfile.mkstemp(suffix=".sh")
            with os.fdopen(fd, 'w') as f: f.write(script)
            os.chmod(temp_path, 0o755)
            
            print("\n[*] Escaping Python to execute root installation script...")
            subprocess.run(["sudo", "-S", "bash", temp_path], input=f"{pwd}\n", text=True)
            os.remove(temp_path)
            print("\n\033[92m[+] INSTALLATION / UPDATE COMPLETE. ARSENAL READY.\033[0m")
            continue

        # --- Gather Target Details for Scanners ---
        target = input("\033[91mARF>\033[0m Enter Target (e.g. example.com): ").strip()
        if not target:
            print("[-] Target cannot be empty.")
            continue
            
        # Default to the active workspace we just loaded
        project = input(f"\033[91mARF>\033[0m Project Workspace [{active_proj}]: ").strip() or active_proj
        
        # --- Headless Signal Handlers ---
        def cli_log(msg):
            clean_msg = re.sub(r'<[^>]+>', '', msg)
            clean_msg = clean_msg.replace('&lt;', '<').replace('&gt;', '>')
            print(clean_msg)
            
        def cli_done():
            print(f"\n\033[92m[+] Execution Complete. Data securely vaulted in Scan_Results/{project}/\033[0m")
            global app # Need access to the app we instantiate below
            app.quit()
            
        def spider_done(path, count):
            cli_log(f"\033[92m[+] SUCCESS: Saved {count} words to {path}\033[0m")
            cli_done()

        # LAZY LOAD QCOREAPPLICATION ONLY IF A SCAN IS TRIGGERED
        app = QCoreApplication.instance() or QCoreApplication(sys.argv)

        # --- Engine Routing (Notice exec_mode="CLI" injected everywhere!) ---
        if choice == "1":
            threads = input("\033[91mARF>\033[0m Threads [50]: ").strip()
            threads = int(threads) if threads.isdigit() else 50
            cli_log(f"\n[*] Launching Live Recon Engine against {target}...")
            # Inject the active workspace's scope and keys into the worker
            active_shodan = temp_config.get("shodan_keys", {}).get(project, "")
            active_webhook = temp_config.get("webhook_urls", {}).get(project, "")
            active_scope = temp_config.get("out_of_scope", {}).get(project, "")
            
            worker = AdvancedReconWorker(target, "wordlist.txt", active_shodan, threads, active_webhook, False, 60, project, active_scope, cli_api_keys, exec_mode="CLI")
            worker.signals.log_signal.connect(cli_log)
            worker.signals.finished_signal.connect(cli_done)
            worker.start()
            app.exec() 

        elif choice == "2":
            cli_log(f"\n[*] Launching Detached Domain Kill-Chain against {target}...")
            worker = DomainAutoScanWorker([target], "wordlist.txt", project, exec_mode="CLI")
            worker.output_signal.connect(cli_log)
            worker.finished_signal.connect(cli_done)
            worker.start()
            app.exec()

        elif choice == "3":
            cli_log(f"\n[*] Launching Detached IP Kill-Chain against {target}...")
            worker = IPAutoScanWorker([target], "wordlist.txt", project, exec_mode="CLI")
            worker.output_signal.connect(cli_log)
            worker.finished_signal.connect(cli_done)
            worker.start()
            app.exec()

        elif choice == "4":
            cli_log(f"\n[*] Initializing Web Spider against {target}...")
            worker = SpiderWorker(target, project)
            worker.log_signal.connect(cli_log)
            worker.error_signal.connect(cli_log)
            worker.finished_signal.connect(spider_done)
            worker.start()
            app.exec()

        elif choice == "5":
            tool = input("\033[91mARF>\033[0m Tool Name (e.g. nmap, nuclei): ").strip()
            args = input("\033[91mARF>\033[0m Arguments (Use {t} to inject target, e.g. '-sV {t}'): ").strip()
            
            if "{t}" in args:
                cmd_string = args.replace("{t}", target)
                full_cmd = [tool] + cmd_string.split()
            else:
                full_cmd = [tool] + args.split() + [target]
                
            cli_log(f"\n[*] Executing: {' '.join(full_cmd)}")
            
            # Capture and Save Single Tool Output
            captured_output = []
            
            def capture_and_log(msg):
                clean_msg = re.sub(r'<[^>]+>', '', msg).replace('&lt;', '<').replace('&gt;', '>')
                captured_output.append(clean_msg)
                print(clean_msg)
                
            def finalize_tool_run():
                scan_id = f"MANUAL_{tool}_{int(time.time())}"
                target_summary = f"{tool} | {target} | {args}"
                
                try:
                    with db.lock:
                        db.save_scan_meta(scan_id, project, target_summary, "Manual", 0, exec_mode="CLI")
                        db.save_tool_output(scan_id, tool, "\n".join(captured_output), project, exec_mode="CLI")
                    print(f"\n\033[92m[+] Output successfully vaulted under ID: {scan_id}\033[0m")
                except Exception as e:
                    print(f"\n\033[91m[!] Failed to save to database: {e}\033[0m")
                cli_done()

            worker = ToolWorker(full_cmd)
            worker.output_signal.connect(capture_and_log)
            worker.error_signal.connect(capture_and_log)
            worker.finished_signal.connect(finalize_tool_run)
            worker.start()
            app.exec()


def run_headless_auto(args):
    """The non-interactive, single-command executor for Cronjobs and Scripts."""
    print_banner()
    print(f"[*] Engine Selected: {args.engine.upper()}")
    print(f"[*] Routed to Workspace: {args.project.upper()}\n")
    
    if args.engine == "install":
        print("\033[96m[!] ARF INSTALLATION & UPDATE MANAGER\033[0m")
        print("  [1] Master Bootstrapper (Full OS Upgrade + Compile All Tools)")
        print("  [2] Targeted Updater (Select a specific module to install/update)")
        
        choice = input("\nARF> Select an option: ").strip()
        dummy_installer = InstallationTab()
        
        if choice == "1":
            print("\nSupported OS: ubuntu, debian, mint, fedora, arch")
            distro = input("Enter your OS distribution: ").strip().lower()
            if distro not in ["ubuntu", "debian", "mint", "fedora", "arch"]:
                print("[-] Unsupported OS. Exiting.")
                sys.exit(1)
            script = dummy_installer.generate_script(distro)
            
        elif choice == "2":
            print("\n\033[93m--- Available Modules ---\033[0m")
            tools = list(dummy_installer.install_map.keys())
            for idx, t in enumerate(tools):
                print(f"  [{idx}] {t}")
                
            tool_idx = input("\nARF> Select module number to update: ").strip()
            if not tool_idx.isdigit() or int(tool_idx) < 0 or int(tool_idx) >= len(tools):
                print("[-] Invalid selection. Exiting.")
                sys.exit(1)
                
            selected_tool = tools[int(tool_idx)]
            bash_command = dummy_installer.install_map[selected_tool]
            script = f"#!/bin/bash\necho '[*] Executing Targeted Build Script for: {selected_tool}...'\n{bash_command}\necho '✅ UPDATE COMPLETE'"
        else:
            print("[-] Invalid choice. Exiting.")
            sys.exit(1)
            
        import getpass
        pwd = getpass.getpass("\n[🔒] Enter sudo password to authorize installation: ")
        
        fd, temp_path = tempfile.mkstemp(suffix=".sh")
        with os.fdopen(fd, 'w') as f: f.write(script)
        os.chmod(temp_path, 0o755)
        
        print("\n[*] Escaping Python to execute root installation script...")
        subprocess.run(["sudo", "-S", "bash", temp_path], input=f"{pwd}\n", text=True)
        os.remove(temp_path)
        print("\n\033[92m[+] INSTALLATION / UPDATE COMPLETE. ARSENAL READY.\033[0m")
        sys.exit(0)

    app = QCoreApplication.instance() or QCoreApplication(sys.argv)
    temp_config = load_config()
    cli_api_keys = temp_config.get("api_keys", {})
    
    def cli_log(msg): 
        print(re.sub(r'<[^>]+>', '', msg).replace('&lt;', '<').replace('&gt;', '>'))
        
    def cli_done(): 
        print(f"\n[+] Execution Complete. Exiting Automation.")
        app.quit()

    targets_list = [t.strip() for t in args.targets.split(',') if t.strip()]
    target = targets_list[0] if targets_list else ""

    if args.engine == "live":
        worker = AdvancedReconWorker(args.targets, args.wordlist, args.shodan, args.threads, args.webhook, args.continuous, args.interval, args.project, args.scope, cli_api_keys, exec_mode="CLI")
        worker.signals.log_signal.connect(cli_log)
        worker.signals.finished_signal.connect(cli_done)
        worker.start()

    elif args.engine == "domain":
        worker = DomainAutoScanWorker(targets_list, args.wordlist, args.project, exec_mode="CLI")
        worker.output_signal.connect(cli_log)
        worker.finished_signal.connect(cli_done)
        worker.start()

    elif args.engine == "ip":
        worker = IPAutoScanWorker(targets_list, args.wordlist, args.project, exec_mode="CLI")
        worker.output_signal.connect(cli_log)
        worker.finished_signal.connect(cli_done)
        worker.start()

    elif args.engine == "spider":
        worker = SpiderWorker(target, args.project)
        worker.log_signal.connect(cli_log)
        worker.error_signal.connect(cli_log)
        worker.finished_signal.connect(lambda p, c: [cli_log(f"[+] Saved {c} words to {p}"), cli_done()])
        worker.start()
        
    elif args.engine == "tool":
        if not args.toolname:
            print("[-] Error: --toolname is required when using the 'tool' engine.")
            sys.exit(1)
            
        if "{t}" in args.toolargs:
            cmd_string = args.toolargs.replace("{t}", target)
            full_cmd = [args.toolname] + cmd_string.split()
        else:
            full_cmd = [args.toolname] + args.toolargs.split() + [target]
            
        cli_log(f"[*] Executing: {' '.join(full_cmd)}")
        
        # --- THE FIX: Capture and Save Single Tool Output (Headless Mode) ---
        captured_output = []
        
        def capture_and_log(msg):
            clean_msg = re.sub(r'<[^>]+>', '', msg).replace('&lt;', '<').replace('&gt;', '>')
            captured_output.append(clean_msg)
            print(clean_msg)
            
        def finalize_tool_run():
            scan_id = f"MANUAL_{args.toolname}_{int(time.time())}"
            target_summary = f"{args.toolname} | {target} | {args.toolargs}"
            
            try:
                with db.lock:
                    db.save_scan_meta(scan_id, args.project, target_summary, "Manual", 0, exec_mode="CLI")
                    db.save_tool_output(scan_id, args.toolname, "\n".join(captured_output), args.project, exec_mode="CLI")
                print(f"\n[+] Output successfully vaulted under ID: {scan_id}")
            except Exception as e:
                print(f"\n[!] Failed to save to database: {e}")
            cli_done()

        worker = ToolWorker(full_cmd)
        worker.output_signal.connect(capture_and_log)
        worker.error_signal.connect(capture_and_log)
        worker.finished_signal.connect(finalize_tool_run)
        worker.start()

    app.exec()