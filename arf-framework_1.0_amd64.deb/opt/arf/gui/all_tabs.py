import os, time, datetime, re, subprocess, shutil, textwrap, csv, platform
from PyQt6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QCheckBox, QProgressBar, QTextEdit, QFileDialog, QTabWidget, QTableWidget, QTableWidgetItem, QHeaderView, QGroupBox, QFormLayout, QMessageBox, QSpinBox, QInputDialog, QTextBrowser, QComboBox, QGridLayout, QAbstractItemView
from PyQt6.QtCore import Qt, QTimer, QUrl
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWebEngineCore import QWebEnginePage

from core.database import db
from core.config import save_config
from core.env import PSUTIL_AVAILABLE, FPDF_AVAILABLE
from core.utils import ansi_to_html
from workers.cmd_workers import ToolWorker, ManualWorker, InstallWorker
from workers.autoscan_workers import DomainAutoScanWorker, IPAutoScanWorker
from workers.spider_worker import SpiderWorker

try:
    import psutil
except ImportError:
    pass

# ===================================================
# --- NEW: VISUAL ATTACK SURFACE DIFFING TAB ---
# ===================================================
class DiffEngineTab(QWidget):
    def __init__(self, app_config):
        super().__init__()
        self.app_config = app_config
        layout = QVBoxLayout(self)

        controls = QHBoxLayout()
        self.scan_a_btn = QPushButton("Select Scan A (Baseline)")
        self.scan_a_btn.clicked.connect(lambda: self.load_scan('A'))
        self.scan_a_lbl = QLabel("None Selected")

        self.scan_b_btn = QPushButton("Select Scan B (Newest)")
        self.scan_b_btn.clicked.connect(lambda: self.load_scan('B'))
        self.scan_b_lbl = QLabel("None Selected")

        compare_btn = QPushButton("🔥 RUN DIFF ENGINE")
        compare_btn.setStyleSheet("background-color: #aa0000; color: white;")
        compare_btn.clicked.connect(self.compare_scans)

        controls.addWidget(self.scan_a_btn); controls.addWidget(self.scan_a_lbl)
        controls.addWidget(self.scan_b_btn); controls.addWidget(self.scan_b_lbl)
        controls.addWidget(compare_btn)
        layout.addLayout(controls)

        self.diff_output = QTextBrowser()
        self.diff_output.setStyleSheet("background-color: #050505; color: #00ff00;")
        layout.addWidget(self.diff_output)

        self.data_a = {}
        self.data_b = {}

    def load_scan(self, slot):
        scan_id, ok = QInputDialog.getText(self, "Load Scan", "Enter Exact Scan Folder Name (e.g., example_com_LiveRecon_...):")
        if ok and scan_id:
            data = db.get_asset_data(scan_id.strip())
            if not data:
                QMessageBox.critical(self, "Error", "No assets found in vault for that scan ID.")
                return
            if slot == 'A':
                self.data_a = data
                self.scan_a_lbl.setText(scan_id.strip())
            else:
                self.data_b = data
                self.scan_b_lbl.setText(scan_id.strip())

    def compare_scans(self):
        if not self.data_a or not self.data_b:
            QMessageBox.warning(self, "Missing Data", "Please select BOTH Scan A and Scan B.")
            return

        self.diff_output.clear()
        self.diff_output.append("<h3>[+] VISUAL DIFF ENGINE RESULTS</h3>")
        
        hosts_a = set(self.data_a.keys())
        hosts_b = set(self.data_b.keys())

        new_hosts = hosts_b - hosts_a
        dead_hosts = hosts_a - hosts_b
        common_hosts = hosts_a.intersection(hosts_b)

        if new_hosts:
            self.diff_output.append("<b style='color:#00ff00;'>[NEW ASSETS DETECTED]</b>")
            for h in new_hosts: self.diff_output.append(f" + {h} ({self.data_b[h].get('ip')})")
            self.diff_output.append("<br>")

        if dead_hosts:
            self.diff_output.append("<b style='color:#888888;'>[ASSETS TAKEN OFFLINE]</b>")
            for h in dead_hosts: self.diff_output.append(f" - {h}")
            self.diff_output.append("<br>")

        self.diff_output.append("<b style='color:#ffff00;'>[PORT / VULN DELTAS ON EXISTING ASSETS]</b>")
        for h in common_hosts:
            ports_a = set(self.data_a[h].get('services', {}).keys())
            ports_b = set(self.data_b[h].get('services', {}).keys())
            new_ports = ports_b - ports_a
            
            vulns_a = set(self.data_a[h].get('vulns', []))
            vulns_b = set(self.data_b[h].get('vulns', []))
            new_vulns = vulns_b - vulns_a

            if new_ports or new_vulns:
                self.diff_output.append(f"<br><u>Host: {h}</u>")
                if new_ports: self.diff_output.append(f" <span style='color:#00ff00;'>-> New Ports Opened: {new_ports}</span>")
                if new_vulns: self.diff_output.append(f" <span style='color:#ff0000;'>-> New Vulns Found: {new_vulns}</span>")

class SystemMonitorTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        
        # --- CPU Performance Section ---
        cpu_group = QGroupBox("CORE PROCESSOR (CPU)")
        cpu_layout = QVBoxLayout()
        self.cpu_bar = QProgressBar()
        self.cpu_label = QLabel("Analyzing CPU load...")
        # Styling for a "Hacker" look
        self.cpu_bar.setStyleSheet("QProgressBar::chunk { background-color: #00ff00; }")
        cpu_layout.addWidget(self.cpu_label); cpu_layout.addWidget(self.cpu_bar)
        cpu_group.setLayout(cpu_layout); layout.addWidget(cpu_group)
        
        # --- RAM Usage Section ---
        ram_group = QGroupBox("VOLATILE MEMORY (RAM)")
        ram_layout = QVBoxLayout()
        self.ram_bar = QProgressBar()
        self.ram_label = QLabel("Analyzing RAM usage...")
        ram_layout.addWidget(self.ram_label); ram_layout.addWidget(self.ram_bar)
        ram_group.setLayout(ram_layout); layout.addWidget(ram_group)

        # --- NEW: NETWORK THROUGHPUT SECTION ---
        net_group = QGroupBox("NETWORK TRAFFIC (I/O)")
        net_layout = QHBoxLayout()
        self.net_sent_label = QLabel("Sent: 0 KB/s")
        self.net_recv_label = QLabel("Recv: 0 KB/s")
        self.net_sent_label.setStyleSheet("color: #00ff00; font-weight: bold;")
        self.net_recv_label.setStyleSheet("color: #00ff00; font-weight: bold;")
        net_layout.addWidget(self.net_sent_label); net_layout.addWidget(self.net_recv_label)
        net_group.setLayout(net_layout); layout.addWidget(net_group)

        # --- NEW: TOP PROCESS MONITOR ---
        proc_group = QGroupBox("CRITICAL PROCESS WATCHER")
        proc_layout = QVBoxLayout()
        self.proc_label = QLabel("Top Resource Consumer: Loading...")
        self.proc_label.setStyleSheet("color: #888888; font-family: 'Consolas';")
        proc_layout.addWidget(self.proc_label)
        proc_group.setLayout(proc_layout); layout.addWidget(proc_group)

        # Timing Setup
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_stats)
        self.timer.start(2000)
        self.last_net = psutil.net_io_counters() if PSUTIL_AVAILABLE else None
        self.update_stats()

    def update_stats(self):
        if not PSUTIL_AVAILABLE:
            self.cpu_label.setText("psutil not installed.")
            return
        
        try:
            # 1. CPU Tracking
            cpu = psutil.cpu_percent()
            self.cpu_bar.setValue(int(cpu))
            self.cpu_label.setText(f"Total CPU Usage: {cpu}%")
            color = "#ff0000" if cpu > 80 else "#00ff00"
            self.cpu_bar.setStyleSheet(f"QProgressBar::chunk {{ background-color: {color}; }}")

            # 2. RAM Tracking
            ram = psutil.virtual_memory()
            self.ram_bar.setValue(int(ram.percent))
            self.ram_label.setText(f"RAM Used: {ram.used // (1024**2)}MB / {ram.total // (1024**2)}MB")
            ram_color = "#ff0000" if ram.percent > 85 else "#00ff00"
            self.ram_bar.setStyleSheet(f"QProgressBar::chunk {{ background-color: {ram_color}; }}")

            # 3. Network Speed Calculation (Safeguarded against restricted environments)
            current_net = psutil.net_io_counters()
            if current_net and self.last_net:
                sent_speed = (current_net.bytes_sent - self.last_net.bytes_sent) // 2048 
                recv_speed = (current_net.bytes_recv - self.last_net.bytes_recv) // 2048
                self.net_sent_label.setText(f"▲ Outbound: {sent_speed} KB/s")
                self.net_recv_label.setText(f"▼ Inbound: {recv_speed} KB/s")
            self.last_net = current_net

            # 4. Top Process Finder
            top_proc = sorted(psutil.process_iter(['name', 'memory_percent']), 
                             key=lambda p: p.info['memory_percent'], reverse=True)[0]
            p_name = top_proc.info['name']
            p_mem = top_proc.info['memory_percent']
            self.proc_label.setText(f"HEAVIEST PROCESS: {p_name} ({p_mem:.1f}% RAM)")
            
        except Exception:
            pass # Fails gracefully in restricted networking environments

# ===================================================
# --- UPDATED: SYSTEM COMMANDS TAB WITH BUSY STATE ---
# ===================================================
class SystemCommandsTab(QWidget):
    def __init__(self):
        super().__init__()
        self.active_workers = []
        layout = QVBoxLayout(self)
        group = QGroupBox("System Audit && Enumeration")
        
        btn_layout = QGridLayout()
        
        commands = [
            ("WhoAmI", ["whoami"]), ("ID/Groups", ["id"]), ("Sudo Privs", ["sudo", "-l"]),
            ("Last 10 Logins", ["last", "-n", "10"]), ("Env Secrets", ["env"]), ("SSH Key Check", ["ls", "-la", ".ssh"]),
            ("IP Brief", ["hostname", "-I"]), ("Route Table", ["ip", "route"]), ("ARP Cache", ["arp", "-n"]),
            ("IP Neighbors", ["ip", "neigh"]), ("DNS/Resolv", ["cat", "/etc/resolv.conf"]), ("Socket Stats", ["ss", "-tulnp"]),
            ("Kernel Info", ["uname", "-a"]), ("OS Version", ["cat", "/etc/os-release"]), ("Disk Usage", ["df", "-h"]),
            ("Process Tree", ["ps", "faux"]), ("Cron Jobs", ["ls", "-la", "/etc/cron.d"]), ("Docker Check", ["ls", "-la", "/.dockerenv"]),
            ("SUID Files", ["find", "/", "-perm", "-4000", "-type", "f"]), ("Capabilities", ["getcap", "-r", "/"]),
            ("Writable Conf", ["find", "/etc", "-writable", "-type", "f"]), ("Shadow Test", ["cat", "/etc/shadow"]),
            ("AppArmor Status", ["aa-status"]), ("Active Services", ["systemctl", "list-units", "--type=service", "--state=running"])
        ]
        
        row, col = 0, 0
        for name, cmd in commands:
            btn = QPushButton(name)
            btn.setToolTip(f"Executes: {' '.join(cmd)}")
            # Connect to run_system_cmd
            btn.clicked.connect(lambda checked, c=cmd: self.run_system_cmd(c))
            btn_layout.addWidget(btn, row, col)
            
            col += 1
            if col > 3:
                col = 0
                row += 1
        
        group.setLayout(btn_layout)
        layout.addWidget(group)
        
        self.output_area = QTextBrowser()
        self.output_area.setStyleSheet("background-color: #050505; color: #00ff00; border: 1px solid #003300;")
        layout.addWidget(self.output_area, stretch=1)

    def run_system_cmd(self, cmd):
        # 1. Capture the specific button that triggered this call
        clicked_btn = self.sender()
        if not clicked_btn: return
        
        original_text = clicked_btn.text()

        # 2. UI Guard: Disable button and show "Busy" state
        clicked_btn.setEnabled(False)
        clicked_btn.setText("⏳ BUSY...")
        clicked_btn.setStyleSheet("background-color: #111; color: #555; border: 1px solid #222;")

        self.output_area.append(f"<b style='color:#ffffff;'>root@arf:~#</b> <span style='color:#00ff00;'>{' '.join(cmd)}</span>")
        
        worker = ToolWorker(cmd)
        self.active_workers.append(worker) 
        
        def handle_output(txt):
            if "Permission denied" in txt:
                self.output_area.append(f"<i style='color:#ff8800;'>[!] Security Block: Access restricted by OS.</i>")
            elif "No such file" in txt:
                self.output_area.append(f"<i style='color:#888888;'>[-] Indicator Not Found: Path does not exist.</i>")
            else:
                self.output_area.append(txt)

        worker.output_signal.connect(handle_output)
        
        # 3. Connect cleanup to a restoration function
        worker.finished_signal.connect(lambda: self.restore_button(clicked_btn, original_text, worker))
        
        worker.start()

    def restore_button(self, btn, old_text, worker):
        """Re-enables the button and cleans up the worker thread."""
        btn.setEnabled(True)
        btn.setText(old_text)
        btn.setStyleSheet("") # Reverts to the stylesheet defined in setup_advanced_qss
        
        if worker in self.active_workers:
            self.active_workers.remove(worker)

# ===================================================
# --- ENVIRONMENT INSTALLATION TAB UI ---
# ===================================================
class InstallationTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        
        # --- 1. MASTER INSTALLER GROUP ---
        group = QGroupBox("1-Click Master Environment Installer (Full OS Bootstrapper)")
        vlayout = QVBoxLayout()
        lbl = QLabel("Select your exact Linux distribution. This performs a full OS upgrade, and compiles/installs ALL tools (Warning: Re-downloads large AI models).")
        lbl.setWordWrap(True); lbl.setStyleSheet("color: #00aa00;")
        vlayout.addWidget(lbl)
        
        btn_layout = QHBoxLayout()
        self.btn_ubuntu = QPushButton("Ubuntu"); self.btn_ubuntu.setStyleSheet("border-color: #00aa00;")
        self.btn_ubuntu.clicked.connect(lambda: self.trigger_master_install("ubuntu"))
        self.btn_debian = QPushButton("Debian"); self.btn_debian.setStyleSheet("border-color: #00aa00;")
        self.btn_debian.clicked.connect(lambda: self.trigger_master_install("debian"))
        self.btn_mint = QPushButton("Linux Mint"); self.btn_mint.setStyleSheet("border-color: #00aa00;")
        self.btn_mint.clicked.connect(lambda: self.trigger_master_install("mint"))
        self.btn_fedora = QPushButton("Fedora"); self.btn_fedora.setStyleSheet("border-color: #00aa00;")
        self.btn_fedora.clicked.connect(lambda: self.trigger_master_install("fedora"))
        self.btn_arch = QPushButton("Arch Linux"); self.btn_arch.setStyleSheet("border-color: #00aa00;")
        self.btn_arch.clicked.connect(lambda: self.trigger_master_install("arch"))
        
        btn_layout.addWidget(self.btn_ubuntu); btn_layout.addWidget(self.btn_debian); btn_layout.addWidget(self.btn_mint)
        btn_layout.addWidget(self.btn_fedora); btn_layout.addWidget(self.btn_arch)
        vlayout.addLayout(btn_layout); group.setLayout(vlayout); layout.addWidget(group)

        # --- 2. TARGETED TOOL UPDATER GROUP ---
        single_group = QGroupBox("Targeted Module Installer / Updater (Fast)")
        s_layout = QHBoxLayout()
        
        self.tool_combo = QComboBox()
        self.tool_combo.setStyleSheet("padding: 8px; font-size: 14px; background-color: #141414; color: #00ff00; border: 1px solid #005500;")
        
        # Map of individual tools to their exact installation/update bash commands
        self.install_map = {
            "Ollama (AI Engine)": "curl -fsSL https://ollama.com/install.sh | sh",
            "cloud_enum (with Path Fix)": """
git clone https://github.com/initstring/cloud_enum.git /opt/cloud_enum 2>/dev/null || git -C /opt/cloud_enum pull
pip3 install --break-system-packages -r /opt/cloud_enum/requirements.txt || pip3 install -r /opt/cloud_enum/requirements.txt
rm -f /usr/local/bin/cloud_enum
echo -e '#!/bin/bash\ncd /opt/cloud_enum && /usr/bin/python3 cloud_enum.py "$@"' > /usr/local/bin/cloud_enum
chmod +x /usr/local/bin/cloud_enum
""",
            "subfinder": "export GOPATH=$HOME/go; export PATH=$PATH:/usr/local/go/bin:$GOPATH/bin; go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest && cp $HOME/go/bin/* /usr/local/bin/ 2>/dev/null || true",
            "httpx": "export GOPATH=$HOME/go; export PATH=$PATH:/usr/local/go/bin:$GOPATH/bin; go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest && cp $HOME/go/bin/* /usr/local/bin/ 2>/dev/null || true",
            "naabu": "export GOPATH=$HOME/go; export PATH=$PATH:/usr/local/go/bin:$GOPATH/bin; go install -v github.com/projectdiscovery/naabu/v2/cmd/naabu@latest && cp $HOME/go/bin/* /usr/local/bin/ 2>/dev/null || true",
            "katana": "export GOPATH=$HOME/go; export PATH=$PATH:/usr/local/go/bin:$GOPATH/bin; go install -v github.com/projectdiscovery/katana/cmd/katana@latest && cp $HOME/go/bin/* /usr/local/bin/ 2>/dev/null || true",
            "nuclei": "export GOPATH=$HOME/go; export PATH=$PATH:/usr/local/go/bin:$GOPATH/bin; go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest && cp $HOME/go/bin/* /usr/local/bin/ 2>/dev/null || true",
            "dnsx": "export GOPATH=$HOME/go; export PATH=$PATH:/usr/local/go/bin:$GOPATH/bin; go install -v github.com/projectdiscovery/dnsx/cmd/dnsx@latest && cp $HOME/go/bin/* /usr/local/bin/ 2>/dev/null || true",
            "tlsx": "export GOPATH=$HOME/go; export PATH=$PATH:/usr/local/go/bin:$GOPATH/bin; go install -v github.com/projectdiscovery/tlsx/cmd/tlsx@latest && cp $HOME/go/bin/* /usr/local/bin/ 2>/dev/null || true",
            "ffuf": "export GOPATH=$HOME/go; export PATH=$PATH:/usr/local/go/bin:$GOPATH/bin; go install -v github.com/ffuf/ffuf/v2@latest && cp $HOME/go/bin/* /usr/local/bin/ 2>/dev/null || true",
            "gau": "export GOPATH=$HOME/go; export PATH=$PATH:/usr/local/go/bin:$GOPATH/bin; go install -v github.com/lc/gau/v2/cmd/gau@latest && cp $HOME/go/bin/* /usr/local/bin/ 2>/dev/null || true",
            "assetfinder": "export GOPATH=$HOME/go; export PATH=$PATH:/usr/local/go/bin:$GOPATH/bin; go install -v github.com/tomnomnom/assetfinder@latest && cp $HOME/go/bin/* /usr/local/bin/ 2>/dev/null || true",
            "amass": "export GOPATH=$HOME/go; export PATH=$PATH:/usr/local/go/bin:$GOPATH/bin; go install -v github.com/owasp-amass/amass/v4/...@master && cp $HOME/go/bin/* /usr/local/bin/ 2>/dev/null || true",
            "Python Core (Shodan, fpdf2, Playwright...)": "pip3 install --break-system-packages shodan fpdf2 playwright beautifulsoup4 aiohttp dnspython requests PyQt6 PyQt6-WebEngine psutil pyvis holehe lxml orjson maigret sherlock maltego-trx || pip3 install shodan fpdf2 playwright beautifulsoup4 aiohttp dnspython requests PyQt6 PyQt6-WebEngine psutil pyvis holehe lxml orjson maigret sherlock maltego-trx; playwright install chromium",
            "GitDorker (Automated Search)": """
git clone https://github.com/obheda12/GitDorker.git /opt/GitDorker 2>/dev/null || git -C /opt/GitDorker pull
pip3 install --break-system-packages -r /opt/GitDorker/requirements.txt || pip3 install -r /opt/GitDorker/requirements.txt
rm -f /usr/local/bin/gitdorker
echo -e '#!/bin/bash\ncd /opt/GitDorker && /usr/bin/python3 GitDorker.py "$@"' > /usr/local/bin/gitdorker
chmod +x /usr/local/bin/gitdorker
""",
            "Native Packages (Nmap, Nikto, Whois...)": """
if command -v apt-get &> /dev/null; then apt-get update -y && apt-get install -y whois dnsutils nmap whatweb wafw00f wfuzz nikto exploitdb theharvester git wget curl libpcap-dev python3-pyqt6.qtwebengine;
elif command -v dnf &> /dev/null; then dnf install -y whois bind-utils nmap whatweb wafw00f wfuzz nikto exploitdb theharvester git wget curl libpcap-devel python3-qt6-webengine;
elif command -v pacman &> /dev/null; then pacman -S --noconfirm whois bind nmap whatweb wafw00f wfuzz nikto exploitdb theharvester git wget curl libpcap python-pyqt6-webengine;
else echo "Unsupported package manager for native tools."; fi
"""
        }
        self.tool_combo.addItems(self.install_map.keys())
        
        self.btn_single = QPushButton("Update / Install Selected")
        self.btn_single.setStyleSheet("background-color: #008800; color: #000000; font-weight: bold; padding: 8px;")
        self.btn_single.clicked.connect(self.trigger_single_install)
        
        s_layout.addWidget(self.tool_combo); s_layout.addWidget(self.btn_single)
        single_group.setLayout(s_layout); layout.addWidget(single_group)
        
        # --- 3. OUTPUT LOG ---
        self.output_area = QTextEdit(); self.output_area.setReadOnly(True)
        layout.addWidget(self.output_area)
        self.worker = None

    def trigger_single_install(self):
        tool_name = self.tool_combo.currentText()
        bash_command = self.install_map[tool_name]
        
        password, ok = QInputDialog.getText(self, "Root Access Required", f"Enter sudo password to update/install:\n{tool_name}", QLineEdit.EchoMode.Password)
        if not ok or not password:
            self.output_area.append("[-] Installation cancelled. Sudo password required.")
            return
            
        self.output_area.clear()
        self.output_area.append(f"[*] Commencing Targeted Update/Install for: {tool_name}...\n")
        
        script = f"#!/bin/bash\necho '[*] Executing targeted build script...'\n{bash_command}\necho '✅ UPDATE COMPLETE'"
        
        self.btn_single.setEnabled(False)
        self.worker = InstallWorker(script, password)
        self.worker.output_signal.connect(self.output_area.append)
        self.worker.finished_signal.connect(lambda: self.btn_single.setEnabled(True))
        self.worker.start()

    def trigger_master_install(self, distro):
        password, ok = QInputDialog.getText(self, "Root Access Required", "Enter your sudo password to begin Full Bootstrapper:", QLineEdit.EchoMode.Password)
        if not ok or not password:
            self.output_area.append("[-] Installation cancelled. Sudo password required.")
            return
        self.output_area.clear()
        self.output_area.append(f"[*] Initializing Full OS Bootstrap Sequence for {distro.upper()}...\n")
        self.btn_ubuntu.setEnabled(False); self.btn_debian.setEnabled(False); self.btn_mint.setEnabled(False)
        self.btn_fedora.setEnabled(False); self.btn_arch.setEnabled(False)
        script = self.generate_script(distro)
        self.worker = InstallWorker(script, password)
        self.worker.output_signal.connect(self.output_area.append)
        self.worker.finished_signal.connect(self.enable_buttons)
        self.worker.start()

    def enable_buttons(self):
        self.output_area.append("\n[+] FULL INSTALLATION ROUTINE FINISHED.")
        self.btn_ubuntu.setEnabled(True); self.btn_debian.setEnabled(True); self.btn_mint.setEnabled(True)
        self.btn_fedora.setEnabled(True); self.btn_arch.setEnabled(True)

    def generate_script(self, distro):
        go_and_python_script = """
echo "[*] Installing Python Tool Dependencies..."
pip3 install --break-system-packages shodan fpdf2 playwright beautifulsoup4 aiohttp dnspython requests PyQt6 PyQt6-WebEngine psutil pyvis holehe lxml orjson || pip3 install shodan fpdf2 playwright beautifulsoup4 aiohttp dnspython requests PyQt6 PyQt6-WebEngine psutil pyvis holehe lxml orjson
playwright install chromium

echo "[*] Checking Ollama (AI Engine) Status..."
if ! command -v ollama &> /dev/null; then
    echo "[-] Ollama not found. Installing now..."
    curl -fsSL https://ollama.com/install.sh | sh
else
    echo "[+] Ollama is already installed. Skipping to save bandwidth."
fi

echo "[*] Setting up Golang Compiler Environment..."
export GOPATH=$HOME/go
export PATH=$PATH:/usr/local/go/bin:$GOPATH/bin
echo "[*] Compiling Advanced Recon Tools from Source (This may take a few minutes)..."
go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
go install -v github.com/tomnomnom/assetfinder@latest
go install -v github.com/owasp-amass/amass/v4/...@master
go install -v github.com/projectdiscovery/naabu/v2/cmd/naabu@latest
go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest
go install -v github.com/projectdiscovery/katana/cmd/katana@latest
go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest
go install -v github.com/lc/gau/v2/cmd/gau@latest
go install -v github.com/ffuf/ffuf/v2@latest
go install -v github.com/projectdiscovery/dnsx/cmd/dnsx@latest
go install -v github.com/projectdiscovery/tlsx/cmd/tlsx@latest

echo "[*] Cloning & Configuring Cloud Enum..."
if [ ! -d "/opt/cloud_enum" ]; then
    git clone https://github.com/initstring/cloud_enum.git /opt/cloud_enum 2>/dev/null
else
    git -C /opt/cloud_enum pull
fi
pip3 install --break-system-packages -r /opt/cloud_enum/requirements.txt || pip3 install -r /opt/cloud_enum/requirements.txt
rm -f /usr/local/bin/cloud_enum
echo -e '#!/bin/bash\ncd /opt/cloud_enum && /usr/bin/python3 cloud_enum.py "$@"' > /usr/local/bin/cloud_enum
chmod +x /usr/local/bin/cloud_enum

echo "[*] Symlinking Go Binaries to Universal Path..."
cp $HOME/go/bin/* /usr/local/bin/ 2>/dev/null || true
echo "✅ MASTER BOOTSTRAP COMPLETE"
"""
        if distro in ["ubuntu", "debian", "mint"]:
            # --- FIX ADDED: python3-pyqt6.qtwebengine added to the end of the apt-get line ---
            return f"#!/bin/bash\necho '[*] Performing APT OS Upgrade...'\napt-get update -y && apt-get full-upgrade -y\necho '[*] Installing native APT dependencies...'\napt-get install -y python3-pip golang whois dnsutils nmap whatweb wafw00f wfuzz nikto exploitdb theharvester git wget curl libpcap-dev python3-pyqt6.qtwebengine\n{go_and_python_script}"
        
        elif distro == "fedora":
            # Fedora equivalent: python3-qt6-webengine
            return f"#!/bin/bash\necho '[*] Performing DNF OS Upgrade...'\ndnf update -y\necho '[*] Installing native DNF dependencies...'\ndnf install -y python3-pip golang whois bind-utils nmap whatweb wafw00f wfuzz nikto git wget curl libpcap-devel python3-qt6-webengine\n{go_and_python_script}"
        
        elif distro == "arch":
            # Arch equivalent: python-pyqt6-webengine
            return f"#!/bin/bash\necho '[*] Performing Pacman OS Upgrade...'\npacman -Syu --noconfirm\necho '[*] Installing native Pacman dependencies...'\npacman -S --noconfirm python-pip go whois bind nmap whatweb wafw00f wfuzz nikto exploitdb git wget curl libpcap python-pyqt6-webengine\n{go_and_python_script}"

# ===================================================
# --- DOMAIN & IP AUTO-SCAN TAB UI ---
# ===================================================
class AutoScanTab(QWidget):
    def __init__(self, mode, error_callback, wordlist_input_widget, app_config):
        super().__init__()
        self.mode = mode
        self.error_callback = error_callback; self.wordlist_input_widget = wordlist_input_widget
        self.app_config = app_config
        layout = QVBoxLayout(self)
        title = "Domain Kill-Chain (19 Tools)" if mode == "Domain" else "IP Address Kill-Chain (12 Tools)"
        input_group = QGroupBox(title); flayout = QFormLayout()
        input_group.setMinimumHeight(115)
        
        target_layout = QHBoxLayout()
        self.target_input = QLineEdit(); self.target_input.setPlaceholderText(f"Enter {mode}(s) separated by commas...")
        self.browse_btn = QPushButton("Browse List"); self.browse_btn.clicked.connect(self.browse_file)
        target_layout.addWidget(self.target_input); target_layout.addWidget(self.browse_btn)
        
        btn_layout = QHBoxLayout()
        self.run_btn = QPushButton(f"LAUNCH {mode.upper()} SCAN")
        self.run_btn.setStyleSheet("background-color: #00aa00; color: #000000; font-weight: bold;")
        self.run_btn.clicked.connect(self.run_scan)
        
        self.term_btn = QPushButton("TERMINATE SCAN")
        self.term_btn.setStyleSheet("background-color: #aa0000; color: #ffffff; font-weight: bold;")
        self.term_btn.setEnabled(False)
        self.term_btn.clicked.connect(self.terminate_scan)
        
        btn_layout.addWidget(self.run_btn); btn_layout.addWidget(self.term_btn)
        flayout.addRow(f"{mode}(s):", target_layout); flayout.addRow("", btn_layout)
        input_group.setLayout(flayout); layout.addWidget(input_group)
        
        self.output_area = QTextBrowser()
        # FIX 1: Keep only the last 2000 lines in memory. Old lines are deleted automatically.
        self.output_area.document().setMaximumBlockCount(2000) 
        # FIX 2: Disable word wrap so massive JSON strings don't crash the C++ rendering engine!
        self.output_area.setLineWrapMode(QTextBrowser.LineWrapMode.NoWrap)
        layout.addWidget(self.output_area, stretch=1)
        self.worker = None

        # ==========================================
        # --- WORKFLOW ROUTING PANEL ---
        # ==========================================
        route_layout = QHBoxLayout()
        self.btn_goto_export = QPushButton("➡️ Scan Complete? Go to Target History Tab")
        self.btn_goto_export.setStyleSheet("background-color: #003366; color: #ffffff; border: 1px solid #0055ff; padding: 10px; font-weight: bold;")
        self.btn_goto_export.setEnabled(False) # Will turn on when scan finishes
        route_layout.addWidget(self.btn_goto_export)
        layout.addLayout(route_layout)

    def browse_file(self):
        file_path, _ = QFileDialog.getOpenFileName(self, f"Select {self.mode}s List", "", "Text Files (*.txt);;All Files (*)")
        if file_path: self.target_input.setText(file_path)

    def run_scan(self):
        raw_input = self.target_input.text().strip(); wordlist = self.wordlist_input_widget.text().strip()
        if not raw_input: return
        targets = []
        if os.path.isfile(raw_input):
            with open(raw_input, 'r') as f: targets = [line.strip() for line in f if line.strip()]
        else: targets = [t.strip() for t in raw_input.split(',') if t.strip()]

        self.run_btn.setEnabled(False); self.term_btn.setEnabled(True); self.output_area.clear()
        
        # --- WORKSPACE ROUTING FIX ---
        # Grab the active workspace name (defaulting to Default_Workspace)
        project = self.app_config.get("project_name", "Default_Workspace")
        
        # Pass the project name into the workers
        if self.mode == "Domain":
            self.worker = DomainAutoScanWorker(targets, wordlist, project)
        else:
            self.worker = IPAutoScanWorker(targets, wordlist, project)
            
        self.worker.output_signal.connect(self.output_area.setHtml)
        self.worker.error_signal.connect(self.error_callback)
        self.worker.finished_signal.connect(self.scan_completed)
        self.worker.start()
        
    def terminate_scan(self):
        if self.worker and self.worker.isRunning():
            self.worker.stop(); self.output_area.append("\n<b style='color:#ff0000;'>[!] Force termination signal sent...</b>")

    def scan_completed(self):
        self.run_btn.setEnabled(True); self.term_btn.setEnabled(False); self.btn_goto_export.setEnabled(True)
        
        save_dir = self.worker.current_save_dir
        if not save_dir:
            self.output_area.append("\n<b style='color:#ff0000;'>[!] Scan aborted. No valid targets were provided.</b>")
            return
        
        raw_text = self.output_area.toPlainText()
        scan_id = os.path.basename(save_dir)
        
        # 1. Save the Raw Master Log to Vault
        db.save_tool_output(scan_id, "GUI_Master_Log", raw_text)
        
        # 2. Save HTML copy for local viewing
        html_text = f"<html><body style='background-color:#0d0d0d;color:#00ff00;'><pre>{raw_text}</pre></body></html>"
        with open(os.path.join(save_dir, "GUI_Master_Log.html"), 'w', encoding='utf-8') as f:
            f.write(html_text)
            
        self.output_area.append(f"\n<b style='color:#00ff00;'>[+] Session Log Stored securely in SQLite Vault.</b>")

# ===================================================
# --- UNIVERSAL TOOL TAB CLASS ---
# ===================================================
class UniversalToolTab(QWidget):
    def __init__(self, tool_name, default_presets, app_config, save_config_callback, error_callback):
        super().__init__()
        layout = QVBoxLayout(self)
        self.tool_name = tool_name; self.app_config = app_config
        self.save_config_callback = save_config_callback; self.error_callback = error_callback
        self.target_queue = []; self.worker = None

        if self.tool_name not in self.app_config["custom_presets"]: self.app_config["custom_presets"][self.tool_name] = {}

        input_group = QGroupBox(f"[{tool_name.upper()}] Configuration"); flayout = QFormLayout()
        input_group.setMinimumHeight(135)
        
        target_layout = QHBoxLayout()
        self.target_input = QLineEdit(); self.target_input.setPlaceholderText("Enter Target(s) separated by commas...")
        self.browse_target_btn = QPushButton("Browse List"); self.browse_target_btn.clicked.connect(lambda: self.target_input.setText(QFileDialog.getOpenFileName()[0] or ""))
        target_layout.addWidget(self.target_input); target_layout.addWidget(self.browse_target_btn)
        flayout.addRow("Target(s):", target_layout)
        
        self.args_input = QLineEdit(); self.args_input.setPlaceholderText("Use {t} macro to inject target into args...")
        
        btn_layout = QHBoxLayout()
        self.run_manual_btn = QPushButton(f"Execute {tool_name}")
        self.run_manual_btn.setStyleSheet("background-color: #00aa00; color: #000000; font-weight: bold;")
        self.run_manual_btn.clicked.connect(self.initiate_scan_queue)
        
        self.term_manual_btn = QPushButton("Terminate"); self.term_manual_btn.setEnabled(False)
        self.term_manual_btn.setStyleSheet("background-color: #aa0000; color: #ffffff; font-weight: bold;")
        self.term_manual_btn.clicked.connect(self.terminate_scan)
        
        btn_layout.addWidget(self.args_input); btn_layout.addWidget(self.run_manual_btn); btn_layout.addWidget(self.term_manual_btn)
        flayout.addRow("Custom Args:", btn_layout)

        self.detached_chk = QCheckBox("Spawn in Detached Native Terminal (For Dashboards/Interactive Tools)")
        self.detached_chk.setStyleSheet("color: #ffff00; font-weight: bold;")
        flayout.addRow("", self.detached_chk)
        input_group.setLayout(flayout); layout.addWidget(input_group)

        preset_group = QGroupBox("Saved Modules"); self.preset_layout = QHBoxLayout()
        preset_group.setMinimumHeight(70)
        for btn_name, args in default_presets.items(): self.create_preset_button(btn_name, args, False)
        for btn_name, args in self.app_config["custom_presets"][self.tool_name].items(): self.create_preset_button(btn_name, args, True)
        preset_group.setLayout(self.preset_layout); layout.addWidget(preset_group)

        add_script_group = QGroupBox("Save Custom Module"); add_layout = QHBoxLayout()
        add_script_group.setMinimumHeight(70)
        self.new_script_name = QLineEdit(); self.new_script_name.setPlaceholderText("Name")
        self.new_script_args = QLineEdit(); self.new_script_args.setPlaceholderText("Args w/ {t}")
        save_script_btn = QPushButton("Save"); save_script_btn.clicked.connect(self.save_custom_script)
        add_layout.addWidget(QLabel("Name:")); add_layout.addWidget(self.new_script_name)
        add_layout.addWidget(QLabel("Args:")); add_layout.addWidget(self.new_script_args); add_layout.addWidget(save_script_btn)
        add_script_group.setLayout(add_layout); layout.addWidget(add_script_group)

        self.output_area = QTextBrowser()
        layout.addWidget(self.output_area, stretch=1)
        
    def create_preset_button(self, name, args, is_custom):
        btn = QPushButton(name)
        btn.setStyleSheet(f"background-color: {'#00aa00' if is_custom else '#141414'}; color: {'#000000' if is_custom else '#00ff00'}; border-radius: 4px;") 
        btn.clicked.connect(lambda checked, a=args: self.args_input.setText(a))
        self.preset_layout.addWidget(btn)

    def save_custom_script(self):
        name = self.new_script_name.text().strip(); args = self.new_script_args.text().strip()
        if not name or not args: return
        self.app_config["custom_presets"][self.tool_name][name] = args
        self.save_config_callback()
        self.create_preset_button(name, args, is_custom=True)
        self.new_script_name.clear(); self.new_script_args.clear()

    def initiate_scan_queue(self):
        raw_input = self.target_input.text().strip(); self.current_args = self.args_input.text().strip()
        if not raw_input:
            QMessageBox.warning(self, "Warning", "Please enter target(s) first!")
            return
        if os.path.isfile(raw_input):
            with open(raw_input, 'r') as f: self.target_queue = [line.strip() for line in f if line.strip()]
        else: self.target_queue = [t.strip() for t in raw_input.split(',') if t.strip()]

        # --- THE ANT FIX: Prevent GUI Crash on Empty Files ---
        if not self.target_queue:
            QMessageBox.warning(self, "Warning", "The provided target list is completely empty!")
            return

        # --- THE ANT FIX: Prevent Self-Inflicted Fork Bombs ---
        if self.detached_chk.isChecked() and len(self.target_queue) > 1:
            QMessageBox.critical(self, "Detached Mode Overload", "You cannot run a multi-target list in Detached Mode! This would spawn dozens of terminal windows and crash your OS.\n\nPlease uncheck 'Spawn in Detached Native Terminal' or scan a single target.")
            self.target_queue.clear()
            return

        self.run_manual_btn.setEnabled(False); self.term_manual_btn.setEnabled(True); self.output_area.clear()
        
        project = self.app_config.get("project_name", "Default_Workspace")
        self.active_manual_scan_id = f"MANUAL_{self.tool_name}_{int(time.time())}"
        
        target_summary = f"{self.tool_name} | {self.target_queue[0]} | {self.current_args}"
        db.save_scan_meta(self.active_manual_scan_id, project, target_summary, "Manual", 0)
        
        self.process_next_target()
        
    def terminate_scan(self):
        self.target_queue.clear()
        if self.worker and self.worker.isRunning():
            self.worker.stop()
            self.output_area.append("\n<b style='color:#ff0000;'>[!] Force termination signal sent. Queue cleared.</b>")

    def spawn_detached_process(self, full_cmd):
        """Spawns a detached native terminal for heavy external tools like airodump-ng."""
        cmd_str = " ".join(full_cmd)
        self.fancy_log(f"<span style='color:#ffff00;'>[#] Spawning native terminal for: {cmd_str}</span>")
        try:
            if platform.system() == "Windows":
                subprocess.Popen(f'start cmd.exe /K "{cmd_str}"', shell=True)
                return True
            elif platform.system() == "Linux":
                safe_cmd_str = cmd_str.replace('"', '\\"')
                bash_cmd = f"{safe_cmd_str}; echo \"\"; echo \"================================\"; read -p \"Process complete. Press Enter to close this window...\" -n 1;"
                
                terminals = ['x-terminal-emulator', 'qterminal', 'gnome-terminal', 'konsole', 'xterm']
                for term in terminals:
                    try:
                        if term == 'gnome-terminal':
                            subprocess.Popen([term, '--', 'bash', '-c', bash_cmd], start_new_session=True)
                        else:
                            subprocess.Popen([term, '-e', f'bash -c "{bash_cmd}"'], start_new_session=True)
                        return True
                    except FileNotFoundError:
                        continue
                self.fancy_log("<span style='color:#ff0000;'>[!] Could not find a supported Linux terminal emulator.</span>")
                return False
            else:
                self.fancy_log("<span style='color:#ff0000;'>[!] Detached mode is not supported on this OS.</span>")
                return False
        except Exception as e:
            self.fancy_log(f"<span style='color:#ff0000;'>[!] Failed to spawn terminal: {str(e)}</span>")
            return False

    def process_next_target(self):
        if not self.target_queue:
            self.output_area.append("\n<b style='color:#00ff00;'>[*] All targets in queue processed.</b>")
            self.run_manual_btn.setEnabled(True); self.term_manual_btn.setEnabled(False)
            if not self.detached_chk.isChecked():
                raw_text = self.output_area.toPlainText()
                
                # Fetch the ID we generated in initiate_scan_queue
                scan_id = getattr(self, 'active_manual_scan_id', f"MANUAL_{int(time.time())}")
                db.save_tool_output(scan_id, self.tool_name, raw_text)
                
                self.output_area.append(f"\n<b style='color:#00aa00;'>[+] Network tool output securely preserved in SQLite Vault.</b>")
            return

        target = self.target_queue.pop(0)
        
        # --- POINT 2 FIX: ROBUST TARGET CLEANING ---
        strip_targets = ["nmap", "whois", "dig", "nslookup", "theHarvester", "searchsploit", "subfinder", "assetfinder", "amass", "nikto", "cloud_enum", "naabu"]
        if self.tool_name in strip_targets:
            # 1. Remove protocol (http/https)
            target = re.sub(r'^https?://', '', target)
            # 2. Remove sub-paths (e.g., example.com/login -> example.com)
            target = target.split('/')[0]
            # 3. Final polish: remove trailing dots or spaces
            target = target.strip().rstrip('.')
            
        actual_binary = self.tool_name
        if actual_binary == "httpx" and shutil.which("httpx-toolkit"):
            actual_binary = "httpx-toolkit"
            
        if "{t}" in self.current_args:
            cmd_string = self.current_args.replace("{t}", target)
            full_cmd = [actual_binary] + cmd_string.split()
        else:
            full_cmd = [actual_binary] + self.current_args.split() + [target]
            
        # ====================================================
        # THE EXECUTION ENGINE (This runs the actual tool!)
        # ====================================================
        if self.detached_chk.isChecked():
            self.spawn_detached_process(full_cmd)
            QTimer.singleShot(500, self.process_next_target) 
        else:
            self.output_area.append(f"<br><b style='color:#00ff00;'>[#] Executing internally: {' '.join(full_cmd)}</b><br>")
            self.worker = ToolWorker(full_cmd)
            # --- FIX 3: Inject the strict <pre> formatting ---
            self.worker.output_signal.connect(lambda txt: self.output_area.append(f"<pre style='margin:0; font-family: monospace;'>{txt}</pre>"))
            self.worker.error_signal.connect(self.error_callback)
            self.worker.finished_signal.connect(self.process_next_target)
            self.worker.start()

# ===================================================
# --- NEW: WIRELESS RECONNAISSANCE (802.11) ---
# ===================================================
class WirelessReconTab(QWidget):
    def __init__(self, detached_spawner, log_callback, app_config): # <--- ADDED app_config
        super().__init__()
        self.spawn_detached = detached_spawner
        self.fancy_log = log_callback
        self.app_config = app_config # <--- SAVED IT TO THE CLASS
        layout = QVBoxLayout(self)
        
        # --- ADAPTER MANAGEMENT ---
        adapter_group = QGroupBox("Wireless Adapter Management && Interference Control")
        a_layout = QVBoxLayout() # Switched to VBox to stack rows
        
        # Row 1: Interface Selection & Monitor Mode
        row1 = QHBoxLayout()
        self.iface_combo = QComboBox()
        self.iface_combo.setStyleSheet("padding: 8px; font-size: 14px; background-color: #141414; color: #00ff00; border: 1px solid #005500;")
        self.refresh_interfaces()
        
        refresh_btn = QPushButton("🔄 Refresh")
        refresh_btn.clicked.connect(self.refresh_interfaces)

        # --- NEW: Fetch MAC & Info Button ---
        self.mac_info_btn = QPushButton("📋 Fetch MAC && IP Info")
        self.mac_info_btn.setStyleSheet("background-color: #0000aa; color: #ffffff; font-weight: bold;")
        self.mac_info_btn.setToolTip("Displays physical MAC addresses for all network interfaces.")
        self.mac_info_btn.clicked.connect(self.fetch_interface_details)
        # ------------------------------------
        
        self.start_mon_btn = QPushButton("🔌 Enable Mon")
        self.start_mon_btn.setStyleSheet("background-color: #005500; color: #ffffff; font-weight: bold;")
        self.start_mon_btn.clicked.connect(lambda: self.run_adapter_cmd("start"))
        
        self.stop_mon_btn = QPushButton("🛑 Disable Mon")
        self.stop_mon_btn.setStyleSheet("background-color: #550000; color: #ffffff; font-weight: bold;")
        self.stop_mon_btn.clicked.connect(lambda: self.run_adapter_cmd("stop"))
        
        row1.addWidget(QLabel("Iface:")); row1.addWidget(self.iface_combo)
        row1.addWidget(refresh_btn); row1.addWidget(self.mac_info_btn) # <--- Added to layout
        row1.addWidget(self.start_mon_btn); row1.addWidget(self.stop_mon_btn)
        
        # Row 2: Interference & NetworkManager Controls (The Fix)
        row2 = QHBoxLayout()
        kill_btn = QPushButton("💀 Kill Interfering Processes (check kill)")
        kill_btn.setStyleSheet("background-color: #aa5500; color: #ffffff; font-weight: bold;")
        kill_btn.setToolTip("Runs 'airmon-ng check kill' to stop wpa_supplicant and NetworkManager from interfering.")
        kill_btn.clicked.connect(lambda: self.execute_raw_cmd(["pkexec", "airmon-ng", "check", "kill"], "Interfering processes terminated."))

        stop_nm_btn = QPushButton("⛔ Stop NetworkManager")
        stop_nm_btn.setStyleSheet("background-color: #880000; color: #ffffff;")
        stop_nm_btn.clicked.connect(lambda: self.execute_raw_cmd(["pkexec", "systemctl", "stop", "NetworkManager"], "NetworkManager service stopped."))

        start_nm_btn = QPushButton("🌐 Start NetworkManager")
        start_nm_btn.setStyleSheet("background-color: #0000aa; color: #ffffff;")
        start_nm_btn.clicked.connect(lambda: self.execute_raw_cmd(["pkexec", "systemctl", "start", "NetworkManager"], "NetworkManager service started."))
        
        sync_btn = QPushButton("💾 Sync Logs to Vault")
        sync_btn.setStyleSheet("background-color: #008888; color: #ffffff; font-weight: bold;")
        sync_btn.setToolTip("Sucks all live_terminal_session.txt files into SQLite and deletes them to clean the folder.")
        sync_btn.clicked.connect(self.sync_wireless_logs_to_db)
        
        row2.addWidget(kill_btn); row2.addWidget(stop_nm_btn); row2.addWidget(start_nm_btn)
        row2.addWidget(sync_btn)
        
        a_layout.addLayout(row1)
        a_layout.addLayout(row2)
        adapter_group.setLayout(a_layout); layout.addWidget(adapter_group)

        # --- TACTICAL WIRELESS SCANS ---
        scan_group = QGroupBox("802.11 Tactical Scanners (Spawns in Detached Terminal)")
        s_layout = QGridLayout()
        
        scans = [
            ("📡 Airodump-ng (Discover APs & Clients)", "airodump-ng {i}"),
            ("🔒 Wash (Scan for WPS Vulnerabilities)", "wash -i {i}"),
            ("💥 Wifite (Automated Attack Toolkit)", "wifite -i {i} --kill"),
            ("📡 Besside-ng (Auto-Handshake Capture)", "besside-ng {i}"),
            ("📻 Kismet (Wireless Wardriving)", "kismet -c {i}")
        ]
        
        row, col = 0, 0
        for name, cmd in scans:
            btn = QPushButton(name)
            btn.setToolTip(f"Executes: {cmd}")
            btn.clicked.connect(lambda checked, c=cmd: self.launch_scan(c))
            s_layout.addWidget(btn, row, col)
            col += 1
            if col > 1: # 2 buttons per row
                col = 0
                row += 1
                
        scan_group.setLayout(s_layout); layout.addWidget(scan_group)
        
        # --- OUTPUT AREA ---
        self.output_area = QTextBrowser()
        self.output_area.setStyleSheet("background-color: #050505; color: #00ff00; border: 1px solid #1a5e20;")
        self.output_area.append("<i>[SYSTEM]: Ensure your Wi-Fi adapter supports Monitor Mode & Packet Injection. Standard internal laptop cards usually do not.</i>")
        layout.addWidget(self.output_area, stretch=1)

    def refresh_interfaces(self):
        # 1. Save the currently selected interface before we clear the list
        current_selection = self.iface_combo.currentText()
        
        self.iface_combo.clear()
        try:
            # Parses /sys/class/net for wireless interfaces
            ifaces = [i for i in os.listdir('/sys/class/net') if 'wlan' in i or 'wlp' in i or 'mon' in i]
            if not ifaces:
                self.iface_combo.addItem("No wireless interfaces found")
                self.start_mon_btn.setEnabled(False) # Prevent Crash
                self.stop_mon_btn.setEnabled(False)  # Prevent Crash
            else:
                self.start_mon_btn.setEnabled(True)
                self.stop_mon_btn.setEnabled(True)
                self.iface_combo.addItems(ifaces)
                
                # 2. SMART RESTORE LOGIC
                if current_selection in ifaces:
                    # If the exact interface still exists, re-select it
                    self.iface_combo.setCurrentText(current_selection)
                elif f"{current_selection}mon" in ifaces:
                    # If it changed from 'wlan1' to 'wlan1mon', auto-select the new monitor interface
                    self.iface_combo.setCurrentText(f"{current_selection}mon")
                elif current_selection.endswith("mon") and current_selection[:-3] in ifaces:
                    # If it changed from 'wlan1mon' back to 'wlan1', revert back safely
                    self.iface_combo.setCurrentText(current_selection[:-3])
                    
        except Exception:
            self.iface_combo.addItem("Error reading interfaces")
            
    def fetch_interface_details(self):
        """Executes and merges 'ip link' and 'ip addr' for a complete hardware/IP profile."""
        self.output_area.append("<br><b style='color:#00ffff;'>[*] HARDWARE RECON: Fetching Interface Profiles (MAC + IP)...</b>")
        try:
            # 1. Fetch MAC Addresses and State
            res_link = subprocess.run(["ip", "-br", "link"], capture_output=True, text=True)
            # 2. Fetch IP Addresses
            res_addr = subprocess.run(["ip", "-br", "addr"], capture_output=True, text=True)
            
            if res_link.returncode == 0 and res_addr.returncode == 0:
                interfaces = {}
                
                # Parse MACs
                for line in res_link.stdout.strip().split('\n'):
                    parts = line.split()
                    if len(parts) >= 3:
                        iface = parts[0]
                        state = parts[1]
                        mac = parts[2]
                        interfaces[iface] = {'state': state, 'mac': mac, 'ip': 'Unassigned'}
                        
                # Parse IPs (Combines IPv4 and IPv6 if present)
                for line in res_addr.stdout.strip().split('\n'):
                    parts = line.split()
                    if len(parts) >= 3:
                        iface = parts[0]
                        ips = " ".join(parts[2:]) 
                        if iface in interfaces:
                            interfaces[iface]['ip'] = ips
                            
                # Build the Custom UI Table
                header = f"{'INTERFACE':<15} {'STATE':<10} {'MAC ADDRESS':<20} {'IP ADDRESS(ES)'}"
                separator = "-" * 85
                clean_output = f"{header}\n{separator}\n"
                
                for iface, data in interfaces.items():
                    # Format each row to align perfectly
                    clean_output += f"{iface:<15} {data['state']:<10} {data['mac']:<20} {data['ip']}\n"
                
                self.output_area.append(f"<pre style='color:#00ff00;'>{clean_output}</pre>")
                self.fancy_log("[INFO] Interface MAC and IP details fetched successfully.")
            else:
                # Fallback to ifconfig if 'ip' commands fail
                res2 = subprocess.run(["ifconfig"], capture_output=True, text=True)
                self.output_area.append(f"<pre style='color:#00ff00;'>{ansi_to_html(res2.stdout)}</pre>")
                
        except Exception as e:
            self.output_area.append(f"<span style='color:#ff0000;'>[!] Failed to fetch interfaces: {str(e)}</span>")        

    def run_adapter_cmd(self, action):
        iface = self.iface_combo.currentText()
        if "No wireless" in iface or not iface: return
        
        self.output_area.append(f"<br><b style='color:#ffff00;'>[*] Attempting to {action} Monitor Mode on {iface}...</b>")
        cmd = ["pkexec", "airmon-ng", action, iface]
        
        try:
            res = subprocess.run(cmd, capture_output=True, text=True)
            output = res.stdout if res.stdout else res.stderr
            self.output_area.append(f"<pre>{ansi_to_html(output)}</pre>")
            self.fancy_log(f"[INFO] airmon-ng {action} executed on {iface}")
            # Refresh to show the new 'wlan0mon' interface name
            QTimer.singleShot(1500, self.refresh_interfaces) 
        except Exception as e:
            self.output_area.append(f"<span style='color:#ff0000;'>[!] Execution failed: {str(e)}</span>")

    def execute_raw_cmd(self, cmd, success_msg):
        """Helper to run system-level commands like check kill or systemctl."""
        self.output_area.append(f"<br><b style='color:#ffff00;'>[*] Executing: {' '.join(cmd)}...</b>")
        try:
            res = subprocess.run(cmd, capture_output=True, text=True)
            output = res.stdout if res.stdout else res.stderr
            if output:
                self.output_area.append(f"<pre>{ansi_to_html(output)}</pre>")
            self.output_area.append(f"<span style='color:#00ff00;'>[+] {success_msg}</span>")
            self.fancy_log(f"[INFO] {success_msg}")
        except Exception as e:
            self.output_area.append(f"<span style='color:#ff0000;'>[!] Execution failed: {str(e)}</span>")

    def launch_scan(self, cmd_template):
        iface = self.iface_combo.currentText()
        if "No wireless" in iface or not iface: 
            QMessageBox.warning(self, "Warning", "Please select a valid interface first.")
            return
            
        # 1. Prepare the tool command (airodump-ng wlan1mon, etc.)
        full_cmd_str = cmd_template.replace("{i}", iface)
        
        # 2. Setup paths and clean tool name (removes emojis like 📡 for the folder name)
        tool_raw = cmd_template.split()[0].strip()
        tool_clean = "".join(filter(str.isalnum, tool_raw)) 
        ts = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        
        # Fetch the active workspace and route the path
        project = self.app_config.get("project_name", "Default_Workspace")
        save_dir = f"Scan_Results/{project}/Wireless_{tool_clean}_{ts}"
        
        # 3. Create the directory
        os.makedirs(save_dir, exist_ok=True)
        abs_save_dir = os.path.abspath(save_dir)
        log_file = os.path.join(abs_save_dir, "live_terminal_session.txt")

        # 4. Construct the Recorder Command
        # We use 'sudo script' so the password prompt happens BEFORE the recording starts.
        # -q: quiet (no startup message)
        # -f: flush (write to disk immediately)
        # -c: the command to execute
        record_cmd = f"sudo script -q -f -c '{full_cmd_str}' '{log_file}'"
        
        # 5. Build the final payload list (following your backup format)
        # We 'cd' into the directory so the tool's native logs (.cap, .pcap) land there too.
        full_cmd = ["cd", f"'{abs_save_dir}'", "&&", record_cmd]
        
        # 6. UI Logging
        self.output_area.append(f"<br><b style='color:#00ff00;'>[✔] SESSION RECORDER ACTIVE</b>")
        self.output_area.append(f"<span style='color:#00ff00;'>[+] Destination: {save_dir}/</span>")
        self.output_area.append(f"<span style='color:#ffffff;'>[+] Note: Ctrl+C will stop the tool and preserve the log.</span>")
        
        self.fancy_log(f"[INFO] Spawning recorded wireless scan: {full_cmd_str}")
        
        # 7. Hand off to detached terminal
        self.spawn_detached(full_cmd)
        
    def sync_wireless_logs_to_db(self):
        """Scans the workspace, moves terminal logs to SQLite, and cleans up empty folders."""
        project = self.app_config.get("project_name", "Default_Workspace")
        base_path = f"Scan_Results/{project}/"
        
        if not os.path.exists(base_path):
            QMessageBox.information(self, "Sync", "No wireless data found for this workspace.")
            return

        self.output_area.append("<br><b style='color:#00ffff;'>[*] SIPHON PROTOCOL: Sweeping Wireless Folders...</b>")
        synced_count = 0
        deleted_count = 0
        
        for folder in os.listdir(base_path):
            folder_path = os.path.join(base_path, folder)
            log_path = os.path.join(folder_path, "live_terminal_session.txt")
            
            if os.path.isdir(folder_path) and os.path.exists(log_path):
                try:
                    with open(log_path, 'r', errors='ignore') as f:
                        content = f.read()
                    
                    scan_id = f"WIFI_{int(time.time())}_{folder}"
                    db.save_scan_meta(scan_id, project, folder, "Wireless", 0)
                    db.save_tool_output(scan_id, "Wireless_Capture", content)
                    
                    # 1. Delete the log file after successfully saving to the database
                    os.remove(log_path)
                    synced_count += 1
                    
                    # 2. --- THE EMPTY FOLDER CLEANUP FIX ---
                    # If the folder is now completely empty, delete it.
                    # If it contains .cap, .csv, or handshake files, it safely leaves them alone!
                    if not os.listdir(folder_path):
                        os.rmdir(folder_path)
                        deleted_count += 1
                        
                except Exception as e:
                    self.output_area.append(f"<span style='color:#ff0000;'>[!] Failed to sync {folder}: {e}</span>")
                
        self.output_area.append(f"<span style='color:#00ff00;'>[+] Successfully siphoned {synced_count} wireless logs to the SQLite Vault!</span>")
        if deleted_count > 0:
            self.output_area.append(f"<span style='color:#00aa00;'>[+] Automatically purged {deleted_count} empty scan directories.</span>")
            
        self.fancy_log(f"[INFO] Wireless Vault Sync Complete. {synced_count} logs processed, {deleted_count} empty folders removed.")