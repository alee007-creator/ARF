import platform
import os, sys, re, time, datetime, subprocess, shutil, textwrap, csv
from PyQt6.QtWidgets import QMainWindow, QWidget, QVBoxLayout, QFileDialog, QHBoxLayout, QLabel, QLineEdit, QPushButton, QCheckBox, QSpinBox, QProgressBar, QTextEdit, QTabWidget, QTableWidget, QTableWidgetItem, QHeaderView, QGroupBox, QFormLayout, QMessageBox, QListWidget, QInputDialog, QSystemTrayIcon, QTextBrowser, QComboBox, QApplication, QAbstractItemView, QScrollArea
from PyQt6.QtCore import Qt, QTimer, QUrl, QCoreApplication, QThread
from PyQt6.QtGui import QFont, QTextCursor, QIcon, QPixmap, QAction
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWebEngineCore import QWebEnginePage

from core.config import load_config, save_config
from core.database import db
from core.env import FPDF_AVAILABLE
from core.utils import ansi_to_html
from workers.ai_worker import AIWorker
from workers.spider_worker import SpiderWorker
from workers.recon_worker import AdvancedReconWorker
from workers.cmd_workers import ManualWorker
from gui.custom_widgets import SideTabBar
from gui.all_tabs import DiffEngineTab, SystemMonitorTab, SystemCommandsTab, InstallationTab, AutoScanTab, UniversalToolTab, WirelessReconTab

try:
    from fpdf import FPDF, XPos, YPos
except ImportError:
    pass

class ReconProGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ALI RAZA Recon Framework (ARF) v1.0 - Hacker Edition")
        
        # --- NEW: State Tracking for AI & PDF ---
        self.current_scan_data = None
        self.current_scan_dir = None
        self.current_risk_score = 0
        
        # 1. Load the permanent configuration
        self.config = load_config()

        # 2. --- THE HARD RESET ---
        # This forces the feature to OFF every time the app opens, 
        # even if it was saved as 'True' in the config file.
        self.config["wireless_enabled"] = False
        
        # Fixed Window Icon Appears on taskbar and window corner
        icon_path = ""
        system_icon = "/usr/share/pixmaps/arf-icon.png"
        
        # 1. Force the GUI to use the installed Linux system icon
        if os.path.exists(system_icon):
            icon_path = system_icon
        # 2. Fallbacks if running as raw python code
        elif os.path.exists("icon.png"):
            icon_path = "icon.png"
        elif os.path.exists("icon.svg"):
            icon_path = "icon.svg"

        if icon_path:
            app_icon = QIcon(icon_path)
        else:
            app_icon = self.style().standardIcon(self.style().StandardPixmap.SP_ComputerIcon)
            
        self.setWindowIcon(app_icon)
        QApplication.setWindowIcon(app_icon)
        
        self.tray_icon = QSystemTrayIcon(self)
        self.tray_icon.setIcon(app_icon)
        self.tray_icon.show()

        self.is_presentation_mode = False
        self.setup_advanced_qss() 
        self.setup_display_scaling()
        self.setup_menu_bar()     
        
        # --- THE SCROLL FIX: Wrap the entire GUI in a Master Scroll Area ---
        self.master_scroll = QScrollArea()
        self.master_scroll.setWidgetResizable(True)
        self.master_scroll.setStyleSheet("QScrollArea { border: none; background-color: #050508; }")
        
        central_widget = QWidget()
        self.master_scroll.setWidget(central_widget)
        self.setCentralWidget(self.master_scroll)
        
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(15, 15, 15, 15)
        
        self.setup_banner(main_layout)
        
        config_layout = QHBoxLayout()
        self.setup_config_panel(config_layout)
        self.setup_options_panel(config_layout)
        main_layout.addLayout(config_layout)
        
        scan_btn_layout = QHBoxLayout()
        self.scan_btn = QPushButton("[📡] START LIVE RECONNAISSANCE PIPELINE")
        self.scan_btn.setToolTip("Launch the primary multi-threaded infrastructure scan.") 
        self.scan_btn.setStyleSheet("""
            QPushButton { background-color: #008800; color: #000000; font-size: 16px; padding: 12px; border-radius: 4px;}
            QPushButton:hover { background-color: #00ff00; }
        """)
        self.scan_btn.setFixedHeight(45)  # <--- Locks button height
        self.scan_btn.clicked.connect(self.start_scan)
        
        self.term_scan_btn = QPushButton("[💣] TERMINATE PIPELINE")
        self.term_scan_btn.setFixedHeight(45)  # <--- Locks button height
        self.term_scan_btn.setEnabled(False)
        self.term_scan_btn.setStyleSheet("""
            QPushButton { background-color: #aa0000; color: #ffffff; font-size: 16px; padding: 12px; border-radius: 4px;}
            QPushButton:hover { background-color: #ff0000; }
        """)
        self.term_scan_btn.clicked.connect(self.terminate_scan)
        
        scan_btn_layout.addWidget(self.scan_btn); scan_btn_layout.addWidget(self.term_scan_btn)
        main_layout.addLayout(scan_btn_layout)
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedHeight(10)      # <--- Shrinks it to a sleek line
        self.progress_bar.setTextVisible(False)   # <--- Removes the empty text area
        main_layout.addWidget(self.progress_bar)
        
        self.sidebar = QListWidget()
        self.sidebar.setMinimumHeight(450) # <--- THE SCROLL FIX: Refuse to be squished!
        main_layout.addWidget(self.sidebar, stretch=1)
        
        # Dictionary to map sidebar items to their tab index
        self.modules_dict = {}
        
        # --- NEW: Categorized Module Hub Window ---
        self.secondary_window = QWidget(self)
        self.secondary_window.setWindowFlags(Qt.WindowType.Window)
        self.secondary_window.setWindowTitle("ARF Module Hub")
        self.secondary_window.resize(1350, 900) 
        sec_main_layout = QVBoxLayout(self.secondary_window)
        sec_main_layout.setContentsMargins(15, 15, 15, 15)

        # 1. The Top-Level Category Tabs (Navbar Style)
        self.category_tabs = QTabWidget()
        self.category_tabs.setObjectName("CategoryTabs") # <--- CRITICAL FOR CSS
        self.category_tabs.tabBar().setExpanding(True) 
        self.category_tabs.currentChanged.connect(self.update_secondary_title) 
        sec_main_layout.addWidget(self.category_tabs)

        # 2. Create the 4 Sub-Tab Widgets
        self.cat_widgets = []
        cat_names = ["🔍 Recon && Data", "🛠️ System Diagnostics", "🚀 Automation && Config", "🛡️ ARF Tool Arsenal"]
        
        for name in cat_names:
            sub_tab = QTabWidget()
            sub_tab.setObjectName("SubTabs") # <--- CRITICAL FOR CSS
            
            custom_bar = SideTabBar()
            custom_bar.setMinimumWidth(230)
            
            sub_tab.setTabBar(custom_bar) 
            sub_tab.setTabPosition(QTabWidget.TabPosition.West)
            self.category_tabs.addTab(sub_tab, name)
            self.cat_widgets.append(sub_tab)
            
        self.current_category_assignment = 0

        # Connect clicks to our new pop-out function
        self.sidebar.itemClicked.connect(self.open_tool_window)
        self.setup_modules()
        
        # Timer to update AI Service Status every 5 seconds
        self.status_timer = QTimer(self)
        self.status_timer.timeout.connect(self.update_ai_service_status)
        self.status_timer.start(5000)

    def setup_menu_bar(self):
        menu_bar = self.menuBar()
        menu_bar.setStyleSheet("background-color: #050505; color: #00ff00; font-weight: bold; padding: 4px; font-size: 14px; border-bottom: 1px solid #005500;")
        
        # --- 1. MAIN MENU ---
        main_menu = menu_bar.addMenu("☰ Menu")
        new_win_action = main_menu.addAction("🪟 New Tab Window (Ctrl+T)")
        new_win_action.triggered.connect(self.request_new_tab)
        
        # Quick access to your backend files
        open_config_action = main_menu.addAction("📁 Open Project Folder")
        open_config_action.triggered.connect(lambda: os.startfile(os.getcwd()) if platform.system() == "Windows" else subprocess.Popen(["xdg-open", os.getcwd()]))
        
        main_menu.addSeparator()
        panic_action = main_menu.addAction("🚨 EMERGENCY PURGE (PANIC BUTTON)")
        panic_action.setShortcut("Ctrl+Shift+K")
        panic_action.triggered.connect(self.panic_purge)
        main_menu.addSeparator()
        main_menu.addAction("❌ Exit All").triggered.connect(QApplication.instance().quit)

        # --- 2. VIEW MENU ---
        view_menu = menu_bar.addMenu("👁️ View")
        self.presentation_action = view_menu.addAction("Toggle Instructor/Presentation Mode")
        self.presentation_action.setToolTip("Scales up all fonts making it perfect for screen-sharing in class or community screenshots.")
        self.presentation_action.triggered.connect(self.toggle_presentation_mode)
        
        view_menu.addSeparator()
        
        fullscreen_action = view_menu.addAction("🖵 Toggle Fullscreen (F11)")
        fullscreen_action.setShortcut("F11")
        fullscreen_action.triggered.connect(self.toggle_fullscreen)
        
        reset_size_action = view_menu.addAction("🗗 Reset Window Size")
        reset_size_action.setToolTip("Recalculates the optimal 85% screen ratio.")
        reset_size_action.triggered.connect(self.setup_display_scaling)

        # --- 3. TOOLS MENU (NEW) ---
        tools_menu = menu_bar.addMenu("🛠️ Tools")
        sys_terminal = tools_menu.addAction("💻 Spawn Native OS Terminal")
        sys_terminal.setToolTip("Opens a fresh terminal window in the background.")
        sys_terminal.triggered.connect(self.spawn_system_terminal)
        
        tools_menu.addSeparator()
        # Checkable Wireless Mode
        self.wireless_action = QAction("📻 Enable Wireless Recon Mode", self)
        self.wireless_action.setCheckable(True)
        self.wireless_action.setChecked(self.config.get("wireless_enabled", False))
        self.wireless_action.triggered.connect(self.toggle_wireless_module)
        tools_menu.addAction(self.wireless_action)
        clear_cache = tools_menu.addAction("🗑️ Clear Temporary Data")
        clear_cache.triggered.connect(lambda: QMessageBox.information(self, "Cache Cleared", "Local DNS and temporary scan caches have been flushed."))
        health_action = tools_menu.addAction("🩺 Run Pre-Flight Health Check")
        health_action.triggered.connect(self.run_health_check)

        # --- 4. HELP MENU (NEW) ---
        help_menu = menu_bar.addMenu("❓ Help")
        docs_action = help_menu.addAction("📖 Documentation")
        docs_action.triggered.connect(self.show_arf_docs)
        
        about_action = help_menu.addAction("ℹ️ About ARF")
        about_action.triggered.connect(self.show_about_dialog)

        # --- ACTIVE WORKSPACE INDICATOR ---
        current_ws = self.config.get("project_name", "Default_Workspace")
        self.workspace_status_lbl = QLabel(f"ACTIVE WORKSPACE: [{current_ws}]  ")
        self.workspace_status_lbl.setStyleSheet("color: #ff0000; font-family: 'Consolas'; font-weight: bold; margin-right: 15px;")
        menu_bar.setCornerWidget(self.workspace_status_lbl, Qt.Corner.TopRightCorner)
        
    def spawn_system_terminal(self):
        """Safely attempts to spawn a native OS terminal without crashing the GUI."""
        try:
            if platform.system() == "Windows":
                subprocess.Popen(["cmd.exe"], creationflags=subprocess.CREATE_NEW_CONSOLE)
            elif platform.system() == "Linux":
                # List of common Linux terminal emulators, prioritized by Kali/Debian defaults
                terminals = ['x-terminal-emulator', 'qterminal', 'gnome-terminal', 'konsole', 'xfce4-terminal', 'alacritty', 'terminator', 'xterm']
                
                spawned = False
                for term in terminals:
                    try:
                        subprocess.Popen([term])
                        spawned = True
                        break # Successfully launched, break the loop
                    except FileNotFoundError:
                        continue # Try the next terminal in the list
                
                if not spawned:
                    QMessageBox.warning(self, "Terminal Error", "Could not find a supported Linux terminal emulator on your system.")
            else:
                QMessageBox.information(self, "OS Not Supported", "Detached terminal spawning is not set up for macOS yet.")
                
        except Exception as e:
            QMessageBox.critical(self, "Execution Error", f"A fatal error occurred while trying to spawn the terminal:\n\n{str(e)}")  
            
    def spawn_detached_process(self, full_cmd):
        """Spawns a detached native terminal for heavy external tools like airodump-ng."""
        cmd_str = " ".join(full_cmd)
        self.fancy_log(f"<span style='color:#ffff00;'>[#] Spawning native terminal for: {cmd_str}</span>")
        try:
            if platform.system() == "Windows":
                subprocess.Popen(f'start cmd.exe /K "{cmd_str}"', shell=True)
                return True
            elif platform.system() == "Linux":
                safe_cmd_str = cmd_str.replace('"', '\\"')
                bash_cmd = f"{safe_cmd_str}; echo \"\"; echo \"================================\"; read -p \"Process complete. Press Enter to close this window...\" -n 1;"
                
                terminals = ['x-terminal-emulator', 'qterminal', 'gnome-terminal', 'konsole', 'xterm']
                for term in terminals:
                    try:
                        if term == 'gnome-terminal':
                            subprocess.Popen([term, '--', 'bash', '-c', bash_cmd], start_new_session=True)
                        else:
                            subprocess.Popen([term, '-e', f'bash -c "{bash_cmd}"'], start_new_session=True)
                        return True
                    except FileNotFoundError:
                        continue
                self.fancy_log("<span style='color:#ff0000;'>[!] Could not find a supported Linux terminal emulator.</span>")
                return False
            else:
                self.fancy_log("<span style='color:#ff0000;'>[!] Detached mode is not supported on this OS.</span>")
                return False
        except Exception as e:
            self.fancy_log(f"<span style='color:#ff0000;'>[!] Failed to spawn terminal: {str(e)}</span>")
            return False          

    def request_new_tab(self):
        """Sends a signal to the Master Hub to spawn a new tab."""
        if hasattr(self, 'master_hub_add_tab'):
            self.master_hub_add_tab()
            self.tray_icon.showMessage("New Workspace", "Spawned a new Recon workspace tab.", QSystemTrayIcon.MessageIcon.Information, 3000)

    def toggle_presentation_mode(self):
        self.is_presentation_mode = not self.is_presentation_mode
        if self.is_presentation_mode:
            new_style = self.styleSheet().replace("font-size: 13px;", "font-size: 18px;").replace("font-size: 14px;", "font-size: 20px;")
            self.setStyleSheet(new_style)
            # Sync the pop-up hub!
            if hasattr(self, 'secondary_window') and self.secondary_window:
                self.secondary_window.setStyleSheet(new_style)
                
            QMessageBox.information(self, "Instructor Mode", "Presentation Mode Enabled. Fonts scaled up for screen sharing/screenshots.")
        else:
            self.setup_advanced_qss()
            if hasattr(self, 'secondary_window') and self.secondary_window:
                self.secondary_window.setStyleSheet(self.styleSheet()) # Reset pop-up hub
            
    def toggle_fullscreen(self):
        """Toggles the Master Hub parent window between fullscreen and normal mode."""
        parent_window = self.window()
        if parent_window:
            if parent_window.isFullScreen():
                parent_window.showNormal()
            else:
                parent_window.showFullScreen()       
            
    def show_about_dialog(self):
        """Displays the comprehensive software information window featuring 16 core points."""
        from PyQt6.QtWidgets import QMessageBox
        
        msg = QMessageBox(self)
        msg.setWindowTitle("About ARF - System Overview")
        msg.setIcon(QMessageBox.Icon.Information)
        
        # Enhanced Hacker Aesthetic CSS
        msg.setStyleSheet("""
            QMessageBox { 
                background-color: #050508; 
            }
            QLabel { 
                color: #00ff00; 
                font-family: 'Consolas', monospace; 
            }
            QPushButton { 
                background-color: #0a0a0c; 
                color: #00ff00; 
                border: 1px solid #1a5e20; 
                padding: 6px 12px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #00ff00;
                color: #000000;
            }
        """)

        # Organized 16-Point Feature Matrix (Updated for v1.0 Master Build)
        about_content = """
        <h2 style='color:#00ff00; margin-bottom: 0;'>ALI RAZA RECON FRAMEWORK (ARF) v1.0</h2>
        <h4 style='color:#ffffff; margin-top: 0;'>\"Automate. Discover. Dominate.\" - Hacker Edition</h4>
        <hr style='border: 1px solid #1a5e20;'>

        <p style='color:#00cc00;'>ARF is a professional-grade, multi-threaded offensive security workstation designed for high-concurrency infrastructure auditing and AI-driven tactical strategy.</p>

        <b style='color:#ffffff;'>CORE WEAPONIZED FEATURES:</b>
        <table width='100%' style='color:#00ff00; font-size: 12px; margin-top: 10px;'>
            <tr>
                <td>• 🤖 <b>Hybrid AI (Local + AWS Cloud)</b></td>
                <td>• ⚡ <b>High-Concurrency Async Engine</b></td>
            </tr>
            <tr>
                <td>• 🕸️ <b>Interactive PyVis Topology</b></td>
                <td>• 🗺️ <b>Global Geo-OSINT Mapping</b></td>
            </tr>
            <tr>
                <td>• 📄 <b>Executive PDF Reporting</b></td>
                <td>• 📻 <b>Tactical Wireless Suite</b></td>
            </tr>
            <tr>
                <td>• ⚖️ <b>Real-Time Risk Meter</b></td>
                <td>• 🗂️ <b>Global Workspace (~/ARF_Workspace)</b></td>
            </tr>
            <tr>
                <td>• 🕷️ <b>Custom Wordlist Spidering</b></td>
                <td>• 🕵️ <b>Detached Bash Kill-Chains</b></td>
            </tr>
            <tr>
                <td>• 🔄 <b>Visual Surface Diffing</b></td>
                <td>• 🛠️ <b>Native Debian (.deb) Deployment</b></td>
            </tr>
            <tr>
                <td>• 📉 <b>System Hardware Telemetry</b></td>
                <td>• 🚨 <b>Emergency Panic Purge</b></td>
            </tr>
            <tr>
                <td>• 💻 <b>Interactive Headless CLI</b></td>
                <td>• 🗄️ <b>Unified SQLite Vault Auditing</b></td>
            </tr>
        </table>
        
        <hr style='border: 1px solid #1a5e20;'>
        <p style='color:#888888; font-size: 11px;'><i>Proprietary framework developed for advanced infrastructure security research and red-team orchestration.</i></p>
        """

        msg.setText(about_content)
        msg.exec()   
        
    def update_secondary_title(self, index):
        """Updates the pop-up window title dynamically when a top category tab is clicked."""
        if hasattr(self, 'secondary_window'):
            parent_tab_name = "ARF"
            top_level = self.window()
            if top_level and hasattr(top_level, 'tabs'):
                parent_tab_name = top_level.tabs.tabText(top_level.tabs.indexOf(self))
            
            category_name = self.category_tabs.tabText(index)
            self.secondary_window.setWindowTitle(f"{parent_tab_name} - {category_name}")    
            
    def setup_advanced_qss(self):
        self.setStyleSheet("""
            QMainWindow, QWidget { background-color: #050508; color: #00FF41; font-family: 'Consolas', 'Courier New', monospace; font-size: 13px; }
            
            QGroupBox { border: 1px solid #1a5e20; border-radius: 2px; margin-top: 20px; padding-top: 10px; font-weight: bold; color: #00FF41; background-color: rgba(10, 10, 15, 0.8); }
            QGroupBox::title { subcontrol-origin: margin; subcontrol-position: top left; left: 10px; top: 0px; padding: 0 5px; background-color: #050508; color: #00FF41;}
            
            QPushButton { background-color: #0a0a0c; border: 1px solid #00FF41; border-radius: 0px; padding: 8px 16px; font-weight: bold; color: #00FF41; text-transform: uppercase; min-height: 25px; }
            QPushButton:hover { background-color: #00FF41; color: #000000; }
            QPushButton:pressed { background-color: #008800; color: #ffffff; }
            
            QLineEdit, QSpinBox { background-color: #030305; border: 1px solid #1a5e20; border-radius: 0px; padding: 8px; color: #00FF41; min-height: 25px; }
            QLineEdit:focus { border-color: #00FF41; background-color: #0a0a0c; }
            
            QListWidget { background-color: #030305; border: 1px solid #1a5e20; border-radius: 0px; outline: none; padding: 5px; }
            QListWidget::item { padding: 12px; border-bottom: 1px solid #111111; color: #00FF41; }
            QListWidget::item:hover { background-color: #002200; border-left: 2px solid #00FF41;}
            QListWidget::item:selected { background-color: #00FF41; color: #000000; font-weight: bold; }
            
            QTextEdit, QTextBrowser { background-color: #000000; color: #00FF41; font-family: 'Consolas', monospace; border: 1px solid #1a5e20; padding: 10px; }
            
            QTabWidget::pane { border: 1px solid #1a5e20; top: -1px; background: #050508; }
            QTabBar::tab { background: #0a0a0c; color: #1a5e20; padding: 10px 20px; border: 1px solid #1a5e20; margin-right: 2px;}
            QTabBar::tab:selected { background: #00FF41; color: #000000; font-weight: bold;}
            
            QTableWidget { background-color: #030305; gridline-color: #1a5e20; color: #00FF41;}
            QHeaderView::section { background-color: #0a0a0c; color: #00FF41; padding: 8px; border: 1px solid #1a5e20; font-weight: bold;}
            
            QProgressBar { border: 1px solid #1a5e20; text-align: center; color: #ffffff; font-weight: bold; background-color: #000000;}
            QProgressBar::chunk { background-color: #00FF41; }
        """)
        
    def setup_display_scaling(self):
        """Fetches monitor hardware specs and scales the UI dynamically."""
        screen = QApplication.primaryScreen()
        if not screen: return
        
        geometry = screen.geometry()
        w_screen, h_screen = geometry.width(), geometry.height()
        
        # 1. Dynamic Font Scaling (Applied to this Workspace Tab)
        base_font = max(11, int(13 * (h_screen / 1080.0)))
        current_qss = self.styleSheet()
        # We use a regex or a safer replace to ensure we only hit the base font
        new_qss = current_qss.replace("font-size: 13px;", f"font-size: {base_font}px;")
        self.setStyleSheet(new_qss)

        # 2. Target the Top-Level Window (The Hub)
        # We look for the actual QMainWindow ancestor
        top_level = self.window()
        
        # We only resize if the window found is a QMainWindow (MasterHub)
        # and if it isn't already maximized/fullscreen.
        if top_level and isinstance(top_level, QMainWindow):
            if not top_level.isMaximized() and not top_level.isFullScreen():
                target_w = int(w_screen * 0.85)
                target_h = int(h_screen * 0.85)
                top_level.resize(target_w, target_h)
                
                # Perfect Centering
                frame_geo = top_level.frameGeometry()
                frame_geo.moveCenter(screen.availableGeometry().center())
                top_level.move(frame_geo.topLeft())
        
    def setup_banner(self, layout):
        # --- THE LOGO PATH FIX ---
        # Get absolute path to the /opt/arf directory where the logo is installed
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        logo_png = os.path.join(base_dir, "logo.png")
        logo_svg = os.path.join(base_dir, "logo.svg")

        if os.path.exists(logo_png) or os.path.exists(logo_svg):
            logo_label = QLabel()
            pixmap = QPixmap(logo_png) if os.path.exists(logo_png) else QPixmap(logo_svg)
            pixmap = pixmap.scaled(600, 150, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
            logo_label.setPixmap(pixmap)
            logo_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            layout.addWidget(logo_label)
        else:
            banner_label = QLabel(r"""
      █████╗ ██╗     ██╗    ██████╗  █████╗ ███████╗ █████╗ 
     ██╔══██╗██║     ██║    ██╔══██╗██╔══██╗╚══███╔╝██╔══██╗
     ███████║██║     ██║    ██████╔╝███████║  ███╔╝ ███████║
     ██╔══██║██║     ██║    ██╔══██╗██╔══██║ ███╔╝  ██╔══██║
     ██║  ██║███████╗██║    ██║  ██║██║  ██║███████╗██║  ██║
     ╚═╝  ╚═╝╚══════╝╚═╝    ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝
            """)
            banner_label.setFont(QFont("Consolas", 10, QFont.Weight.Bold))
            banner_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            banner_label.setStyleSheet("color: #00ff00;") 
            layout.addWidget(banner_label)
            
            branding_label = QLabel("ALI RAZA RECON FRAMEWORK (ARF) v1.0\n\"Automate. Discover. Dominate.\"")
            branding_label.setFont(QFont("Consolas", 14, QFont.Weight.Bold))
            branding_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            branding_label.setStyleSheet("color: #ffffff; margin-bottom: 10px;")
            layout.addWidget(branding_label)
            
        # --- POINT 3: EXPOSURE METER UI (ADD AT THE VERY END) ---
        meter_layout = QVBoxLayout()
        
        self.risk_label = QLabel("WORKSPACE RISK LEVEL: IDLE")
        self.risk_label.setStyleSheet("color: #888888; font-weight: bold; font-size: 14px;")
        self.risk_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        self.risk_meter = QProgressBar()
        self.risk_meter.setRange(0, 100)
        self.risk_meter.setValue(0)
        self.risk_meter.setFormat("%p% THREAT LOAD")
        self.risk_meter.setStyleSheet("""
            QProgressBar { 
                border: 2px solid #1a5e20; 
                border-radius: 5px; 
                text-align: center; 
                height: 25px; 
                background: #000; 
                color: white; 
                font-weight: bold;
            }
            QProgressBar::chunk { 
                background-color: #550000; 
            } 
        """)
        
        meter_layout.addWidget(self.risk_label)
        meter_layout.addWidget(self.risk_meter)
        layout.addLayout(meter_layout)

    def setup_config_panel(self, layout):
        # --- CORE CONFIGURATION GROUP ---
        group = QGroupBox("Core Configuration")
        flayout = QFormLayout()
        
        self.target_input = QLineEdit()
        self.target_input.setPlaceholderText("example.com, 192.168.1.1, testphp.vulnweb.com")
        btn = QPushButton("Browse"); btn.clicked.connect(lambda: self.target_input.setText(QFileDialog.getOpenFileName()[0] or ""))
        t_layout = QHBoxLayout(); t_layout.addWidget(self.target_input); t_layout.addWidget(btn)
        flayout.addRow("Target(s):", t_layout)
        
        # --- UPGRADED WORDLIST BROWSER ---
        wl_layout = QHBoxLayout()
        self.wordlist_input = QLineEdit("wordlist.txt")
        self.wordlist_input.setPlaceholderText("/usr/share/wordlists/...")
        
        self.wl_browse_btn = QPushButton("📁 Browse")
        self.wl_browse_btn.setStyleSheet("background-color: #0b2210; color: #00ff00; border: 1px solid #00ff00; font-weight: bold; padding: 4px;")
        self.wl_browse_btn.clicked.connect(self.browse_global_wordlist)
        
        wl_layout.addWidget(self.wordlist_input)
        wl_layout.addWidget(self.wl_browse_btn)
        flayout.addRow("Wordlist:", wl_layout)
        
        spider_btn = QPushButton("🕷️ Spider Target for Custom Wordlist")
        spider_btn.setStyleSheet("background-color: #000044; color: white;")
        spider_btn.clicked.connect(self.generate_spider_wordlist)
        flayout.addRow("", spider_btn)
        
        # --- SCOPE ENFORCER (WORKSPACE AWARE) ---
        current_proj = self.config.get("project_name", "Default_Workspace")
        saved_scope = self.config.get("out_of_scope", {}).get(current_proj, "")
        
        self.scope_input = QLineEdit(saved_scope)
        self.scope_input.setPlaceholderText("Regex or keywords (e.g., .dev., outofscope.com, 10.0.0.)")
        self.scope_input.setStyleSheet("border: 1px solid #ff0000;") # Red border to denote danger zone
        flayout.addRow("Out of Scope:", self.scope_input)
        
        # --- SHODAN KEY ---
        current_shodan = self.config.get("shodan_keys", {}).get(current_proj, "")
        self.shodan_input = QLineEdit(current_shodan)
        self.shodan_input.setEchoMode(QLineEdit.EchoMode.Password)
        flayout.addRow("Shodan Key:", self.shodan_input)
        
        group.setLayout(flayout); layout.addWidget(group, stretch=2)

        # =========================================================
        # --- NEW: GLOBAL THREAT INTEL APIS (FREE TIERS) ---
        # =========================================================
        api_group = QGroupBox("Global Threat Intelligence APIs")
        api_layout = QFormLayout()
        
        # Fetch existing keys from config
        api_keys = self.config.get("api_keys", {})
        
        self.vt_input = QLineEdit(api_keys.get("vt", ""))
        self.vt_input.setEchoMode(QLineEdit.EchoMode.Password)
        api_layout.addRow("VirusTotal:", self.vt_input)
        
        self.greynoise_input = QLineEdit(api_keys.get("greynoise", ""))
        self.greynoise_input.setEchoMode(QLineEdit.EchoMode.Password)
        api_layout.addRow("GreyNoise:", self.greynoise_input)
        
        self.pulsedive_input = QLineEdit(api_keys.get("pulsedive", ""))
        self.pulsedive_input.setEchoMode(QLineEdit.EchoMode.Password)
        api_layout.addRow("Pulsedive:", self.pulsedive_input)
        
        # --- CENSYS PLATFORM v3 (Single PAT Token) ---
        self.censys_id_input = QLineEdit(api_keys.get("censys_id", ""))
        self.censys_id_input.setPlaceholderText("Paste Censys PAT (e.g., censys_empx...)")
        self.censys_id_input.setEchoMode(QLineEdit.EchoMode.Password)
        api_layout.addRow("Censys PAT:", self.censys_id_input)

        # --- AWS BEDROCK BEARER TOKEN ---
        self.aws_bedrock_input = QLineEdit(api_keys.get("aws_bedrock", ""))
        self.aws_bedrock_input.setPlaceholderText("ABSKQmVkcm9...")
        self.aws_bedrock_input.setEchoMode(QLineEdit.EchoMode.Password)
        api_layout.addRow("AWS Bedrock Key:", self.aws_bedrock_input)
        
        api_group.setLayout(api_layout); layout.addWidget(api_group, stretch=2)

    def browse_global_wordlist(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Select Dictionary / Wordlist", "/usr/share/wordlists", "Text Files (*.txt);;All Files (*)")
        if file_path:
            self.wordlist_input.setText(file_path)    

    def setup_options_panel(self, layout):
        group = QGroupBox("Monitoring && Output")
        vlayout = QVBoxLayout()
        current_proj = self.config.get("project_name", "Default_Workspace")
        current_webhook = self.config.get("webhook_urls", {}).get(current_proj, "")
        self.webhook_input = QLineEdit(current_webhook)
        self.webhook_input.setPlaceholderText("Discord/Slack Webhook URL")
        vlayout.addWidget(self.webhook_input)
        
        cont_layout = QHBoxLayout()
        self.continuous_check = QCheckBox("Continuous Monitoring")
        self.interval_spin = QSpinBox(); self.interval_spin.setRange(1, 1440); self.interval_spin.setValue(60)
        cont_layout.addWidget(self.continuous_check); cont_layout.addWidget(self.interval_spin)
        vlayout.addLayout(cont_layout)
        
        self.threads_input = QLineEdit("50")
        t_layout = QHBoxLayout(); t_layout.addWidget(QLabel("Threads:")); t_layout.addWidget(self.threads_input)
        vlayout.addLayout(t_layout)
        group.setLayout(vlayout); layout.addWidget(group, stretch=1)

    def trigger_save_config(self): save_config(self.config)

    def add_module(self, widget, name):
        # 1. Pop-up Window Title (Needs && to show a single &)
        clean_title = name.strip(' >#*~')
        target_cat = self.cat_widgets[self.current_category_assignment]
        target_cat.addTab(widget, clean_title)
        
        # 2. Sidebar Name (Needs to convert && back to a clean &)
        sidebar_display_name = name.replace("&&", "&")
        
        # Store using the sidebar name
        self.modules_dict[sidebar_display_name] = (self.current_category_assignment, target_cat.count() - 1)
        self.sidebar.addItem(sidebar_display_name)

    def add_separator(self):
        self.sidebar.addItem("━━━━━━━━━━━━━━━━━━━")
        item = self.sidebar.item(self.sidebar.count() - 1)
        item.setFlags(Qt.ItemFlag.NoItemFlags) # Make the line unclickable
        
    def open_tool_window(self, item):
        """Opens the categorized window with fully separated, bordered components."""
        name = item.text()
        
        if name in self.modules_dict:
            cat_idx, tool_idx = self.modules_dict[name]
            
            self.secondary_window.show()
            self.category_tabs.setCurrentIndex(cat_idx)
            self.cat_widgets[cat_idx].setCurrentIndex(tool_idx)
            
            self.update_secondary_title(cat_idx)

            if not self.secondary_window.styleSheet():
                hub_style = self.styleSheet() + """
                    /* 1. DESTROY THE GIANT OUTER BOX */
                    QTabWidget#CategoryTabs::pane { 
                        border: none; 
                        background: transparent; 
                    }
                    
                    /* 2. THE RIGHT-SIDE OUTPUT BOX */
                    QTabWidget#SubTabs::pane { 
                        border: 1px solid #00FF41; 
                        background-color: #050508; 
                        border-radius: 4px;
                        
                        /* Pushes the green box down and right so it NEVER touches the buttons */
                        position: absolute;
                        top: 15px;
                        left: 15px;
                    }
                    
                    /* 3. TOP NAVBAR TABS (Stretching full width) */
                    QTabBar::tab:north {
                        background-color: #030305;
                        color: #1a5e20;
                        height: 25px; /* Locks height so it stretches horizontally evenly */
                        padding: 10px;
                        border: 1px solid #1a5e20; 
                        border-radius: 4px;
                        margin-right: 5px; 
                    }
                    QTabBar::tab:north:selected {
                        background-color: #0a0a0c;
                        color: #00FF41;
                        border: 1px solid #00FF41; 
                    }

                    /* 4. LEFT SIDEBAR BUTTONS (Inside the massive safe zone) */
                    QTabBar::tab:west { 
                        width: 200px;
                        height: 45px;
                        text-align: left;
                        padding-left: 15px;
                        color: #1a5e20;
                        background-color: #030305;
                        border: 1px solid #1a5e20; 
                        border-radius: 4px;
                        
                        /* The math: 45 height + 15 bottom gap + 5 top gap = 65 (Fits inside our 70px safe zone!) */
                        /* The math: 200 width + 20 right gap = 220 (Fits inside our 240px safe zone!) */
                        margin-bottom: 15px; 
                        margin-right: 20px;  
                        margin-top: 5px;
                    }
                    QTabBar::tab:west:selected {
                        background-color: #0a0a0c;
                        color: #00FF41;
                        border: 1px solid #00FF41; 
                    }
                    QTabBar::tab:west:hover {
                        border: 1px solid #00FF41;
                        color: #00FF41;
                    }
                    
                    /* 5. FIX CLIPPING FOR THE LAST BOTTOM BUTTON */
                    QTabBar:west {
                        margin-bottom: 25px; 
                        text-align: left;
                    }

                    /* 6. PREVENT "..." AND ENABLE FULL NAME DISPLAY */
                    QTabBar {
                        qproperty-elideMode: ElideNone;
                    }
                """
                self.secondary_window.setStyleSheet(hub_style)
                
            self.secondary_window.raise_()
            self.secondary_window.activateWindow()
            
    def update_secondary_title(self, index):
        """Updates the pop-up window title dynamically when a top category tab is clicked."""
        if hasattr(self, 'secondary_window') and self.secondary_window.isVisible():
            parent_tab_name = "ARF"
            top_level = self.window()
            if top_level and hasattr(top_level, 'tabs'):
                parent_tab_name = top_level.tabs.tabText(top_level.tabs.indexOf(self))
            
            # Fetch names from our strict list to guarantee the title updates correctly
            cat_names = ["🔍 Recon && Data", "🛠️ System Diagnostics", "🚀 Automation && Config", "🛡️ ARF Tool Arsenal"]
            if 0 <= index < len(cat_names):
                category_name = cat_names[index]
                self.secondary_window.setWindowTitle(f"{parent_tab_name} - {category_name}")
                
    def force_focus_live_log(self):
        """Pops up the Module Hub and switches focus to the Live Scanner Log."""
        log_name = "[📜] Live Scanner Log"
        if log_name in self.modules_dict:
            cat_idx, tool_idx = self.modules_dict[log_name]
            
            # 1. Ensure the Hub window is visible
            self.secondary_window.show()
            
            # 2. Switch to Category 0 (Recon) and the Log tab
            self.category_tabs.setCurrentIndex(cat_idx)
            self.cat_widgets[cat_idx].setCurrentIndex(tool_idx)
            self.update_secondary_title(cat_idx)
            
            # 3. Highlight it in the sidebar for visual consistency
            items = self.sidebar.findItems(log_name, Qt.MatchFlag.MatchExactly)
            if items:
                self.sidebar.setCurrentItem(items[0])
            
            # 4. Bring the window to the absolute front of the screen
            self.secondary_window.raise_()
            self.secondary_window.activateWindow()            

    def setup_modules(self):
        """Categorizes and initializes all modules for both Main GUI and Pop-up Hub."""
        
        # ===================================================
        # --- SECTION 0: ⚒ Recon & Data ---
        # ===================================================
        self.current_category_assignment = 0 
        
        self.log_output = QTextEdit()
        self.log_output.setReadOnly(True)
        # --- STABILITY FIX: Prevents GUI crash by limiting scrollback memory ---
        self.log_output.document().setMaximumBlockCount(1000)
        # --- IMPROVEMENT 1: Idle Screen Banner ---
        idle_html = r"""
        <div style="margin-top: 40px; font-family: monospace;">
            <pre style="color: #00FF41; font-weight: bold; font-size: 14px; text-align: center;">
                _      _____ __      __ ______   _____  ______  _____  ____  _   _ 
               | |    |_   _|\ \    / /|  ____| |  __ \|  ____|/ ____|/ __ \| \ | |
               | |      | |   \ \  / / | |__    | |__) | |__  | |    | |  | |  \| |
               | |      | |    \ \/ /  |  __|   |  _  /|  __| | |    | |  | | . ` |
               | |____ _| |_    \  /   | |____  | | \ \| |____| |____| |__| | |\  |
               |______|_____|    \/    |______| |_|  \_\______|\_____|\____/|_| \_|
            </pre>
            <div style="text-align: center;">
                <h2 style="color: #00ff00; margin-top: 20px;">[ SYSTEM IDLE ]</h2>
                <p style="color: #888888;">Awaiting telemetry. Configure targets and initiate the pipeline.</p>
            </div>
        </div>
        """
        self.log_output.setHtml(idle_html)
        self.add_module(self.log_output, "[📜] Live Scanner Log")
        
        # Unified Data & Viz Container
        self.results_tab = QTabWidget()
        self.results_table = QTableWidget(); self.results_table.setColumnCount(8)
        self.results_table.setSortingEnabled(True)
        self.results_table.setHorizontalHeaderLabels(["Target", "IP", "OS", "Services", "WAF", "Vulns", "Secrets", "Screenshot"])
        self.results_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        
        self.viz_dashboard = QWebEngineView()
        self.viz_dashboard.setHtml("<html><body style='background-color:#050508; color:#00FF41; display:flex; justify-content:center; align-items:center; height:100vh;'><h2 style='font-family:monospace;'>[AWAITING RECON DATA...]</h2></body></html>")

        self.map_dashboard = QWebEngineView()
        self.map_dashboard.setHtml("<html><body style='background-color:#050508; color:#00FF41; display:flex; justify-content:center; align-items:center; height:100vh;'><h2 style='font-family:monospace;'>[AWAITING GEO-OSINT DATA...]</h2></body></html>")
        
        self.results_tab.addTab(self.results_table, "Data Grid")
        self.results_tab.addTab(self.viz_dashboard, "Interactive Node Graph")
        self.results_tab.addTab(self.map_dashboard, "Global Threat Map")
        
        viz_container = QWidget(); viz_layout = QVBoxLayout(viz_container)
        viz_layout.addWidget(self.results_tab)
        clear_viz_btn = QPushButton("🗑️ CLEAR DASHBOARD DATA")
        clear_viz_btn.setStyleSheet("background-color: #aa0000; color: #ffffff; font-weight: bold; padding: 8px;")
        clear_viz_btn.clicked.connect(self.clear_dashboard_data)
        viz_layout.addWidget(clear_viz_btn)
        
        self.add_module(viz_container, "[📊] Data && Viz")
        self.add_module(DiffEngineTab(self.config), "[🔍] Attack Surface Diff")
        
        # Setup helpers (These add themselves via add_module internally)
        self.setup_ai_assistant()        # AI Assistant
        self.setup_tool_manuals()       # Tool Manuals
        self.setup_history_tab()        # Target History
        self.setup_manual_history_tab() # Single Tool Logs
        self.setup_export_manager()     # Export & Reports
        
        # --- WIRELESS MODULE INITIALIZATION ---
        wireless_name = "[📶] Wireless Signals"
        # Create the tab widget (Now passing self.config!)
        self.w_signals_tab = WirelessReconTab(self.spawn_detached_process, self.fancy_log, self.config)
        
        # Add it to Category 0 (Recon & Data) in the Pop-up window
        target_cat = self.cat_widgets[0]
        # We store the index so we can show/hide it later
        self.wireless_tab_index = target_cat.addTab(self.w_signals_tab, "[📶] Wireless Signals")
        
        # Map it to our dictionary for navigation
        self.modules_dict[wireless_name] = (0, self.wireless_tab_index)
        
        # INITIAL SYNC: This forces the sidebar and pop-up to match the saved setting on startup
        self.toggle_wireless_module(self.config.get("wireless_enabled", False))

        self.add_separator() 

        # ===================================================
        # --- SECTION 1: ⚙ System Diagnostics ---
        # ===================================================
        self.current_category_assignment = 1 
        
        self.add_module(SystemCommandsTab(), "[🖥️] System Basics")
        self.add_module(SystemMonitorTab(), "[📈] System Monitor")
        
        self.add_separator() 

        # ===================================================
        # --- SECTION 2: 🚀 Automation & Config ---
        # ===================================================
        self.current_category_assignment = 2
        
        self.add_module(AutoScanTab("Domain", self.fancy_log, self.wordlist_input, self.config), "[🌐] Auto Scan: Domain")
        self.add_module(AutoScanTab("IP", self.fancy_log, self.wordlist_input, self.config), "[🎯] Auto Scan: IP")
        self.add_module(InstallationTab(), "[⚙️] Auto Installer")
        self.setup_workspace_tab()      # Workspace Config

        self.add_separator() 

        # ===================================================
        # --- SECTION 3: ⚔ ARF Tool Arsenal ---
        # ===================================================
        self.current_category_assignment = 3
        
        tools = [
            ("Nmap", {"Default": "-sV {t}", "Aggressive": "-A -T4 {t}"}),
            ("Subfinder", {"Fast Scan": "-d {t}", "Silent": "-d {t} -silent"}),
            ("Assetfinder", {"Subs Only": "--subs-only {t}"}),
            ("Amass", {"Passive": "enum -passive -d {t}"}),
            ("dnsx", {"Live Resolution": "-silent -a -resp {t}", "Brute Force": "-d {t} -w wordlist.txt -a -resp"}),
            ("tlsx", {"SAN Extraction": "-san -silent {t}", "Full Cert": "-ve -silent {t}"}),
            ("Naabu", {"Top 100": "-host {t} -top-ports 100"}),
            ("httpx", {"Tech Detect": "-tech-detect {t}"}),
            ("Nuclei", {"Default": "-u {t}", "Critical Vulns": "-tags cve,critical -u {t}", "Exposed Panels": "-tags panel,exposure -u {t}"}),
            ("WhatWeb", {"Aggressive": "-a 3 {t}"}),
            ("wafw00f", {"Standard": "{t}"}),
            ("ffuf", {"Dir Fuzz": "-w wordlist.txt -u http://{t}/FUZZ"}),
            ("Wfuzz", {"Common": "-c -w wordlist.txt http://{t}/FUZZ"}),
            ("Katana", {"Deep Crawl": "-u {t} -d 3 -jc"}),
            ("gau", {"All URLs": "{t}"}),
            ("cloud_enum", {"Keyword": "-k {t}"}),
            ("dig", {"ANY": "{t} ANY +short"}),
            ("nslookup", {"Any Type": "-type=any {t}"}),
            ("holehe", {"Email Footprint": "{t}"}),
            ("theHarvester", {"All": "-b all -l 100 -d {t}"}),
            ("whois", {"Default": "{t}"}),
            ("nikto", {"Web Scan": "-h {t}"}),
            ("searchsploit", {"Exact": "-e {t}"}),
            ("maigret", {"Profile Sweep": "{t} -a"}),
            ("sherlock", {"Social Media Hunt": "{t} --timeout 5"}),
            ("gitdorker", {"Repo Leak Search": "-tf tf/TOKENSFILE -q {t} -d Dorks/alldorksv3 -e 5"})
        ]
        
        for name, preset in tools:
            # --- FIX: Preserve casing for theHarvester to avoid Kali deprecation warning ---
            cmd_name = "theHarvester" if "theHarvester" in name else name.lower()
            
            self.add_module(
                UniversalToolTab(cmd_name, preset, self.config, self.trigger_save_config, self.fancy_log), 
                f" > {name}"
            )
            
        self.populate_workspace_list()
        
        
    def toggle_wireless_module(self, checked):
        """Dynamically shows or hides the Wireless Signals tab with visibility safety."""
        self.config["wireless_enabled"] = checked
        
        # Sync the menu checkmark
        if hasattr(self, 'wireless_action'):
            self.wireless_action.blockSignals(True)
            self.wireless_action.setChecked(checked)
            self.wireless_action.blockSignals(False)
        
        target_name = "[📶] Wireless Signals"
        target_cat = self.cat_widgets[0] # Recon & Data Category
        
        # DYNAMIC INDEX LOOKUP: Find exactly where the widget is right now
        current_idx = target_cat.indexOf(self.w_signals_tab)
        
        if checked:
            # 1. SHOW IN SIDEBAR
            if not self.sidebar.findItems(target_name, Qt.MatchFlag.MatchExactly):
                anchor_items = self.sidebar.findItems("[📄] Export & Reports", Qt.MatchFlag.MatchExactly)
                if anchor_items:
                    row = self.sidebar.row(anchor_items[0])
                    self.sidebar.insertItem(row + 1, target_name)
                else:
                    self.sidebar.addItem(target_name)
            
            # 2. SHOW IN POP-UP
            if current_idx != -1:
                target_cat.setTabVisible(current_idx, True)
            
        else:
            # 1. REMOVE FROM SIDEBAR
            items = self.sidebar.findItems(target_name, Qt.MatchFlag.MatchExactly)
            for item in items:
                row = self.sidebar.row(item)
                self.sidebar.takeItem(row)
            
            # 2. HIDE IN POP-UP
            if current_idx != -1:
                target_cat.setTabVisible(current_idx, False)

    # ===================================================
    # --- AI ASSISTANT WITH RAM CONTROLLER & THREADING ---
    # ===================================================
    def setup_ai_assistant(self):
        ai_widget = QWidget(); ai_layout = QVBoxLayout(ai_widget)
        
        # --- SERVICE CONTROLLER HEADER ---
        ctrl_group = QGroupBox("Ollama Intelligence Service (RAM Optimization)")
        ctrl_layout = QHBoxLayout()
        
        self.ai_status_lbl = QLabel("SYSTEM STATUS: CHECKING...")
        self.ai_status_lbl.setStyleSheet("font-weight: bold; color: #888888;")
        
        wake_btn = QPushButton("WAKE UP AI")
        wake_btn.setStyleSheet("background-color: #00aa00; color: #000000;")
        wake_btn.clicked.connect(lambda: self.toggle_ai_service("start"))
        
        sleep_btn = QPushButton("KILL AI PROCESS (FREE RAM)")
        sleep_btn.setStyleSheet("background-color: #aa0000; color: #ffffff;")
        sleep_btn.clicked.connect(lambda: self.toggle_ai_service("stop"))
        
        ctrl_layout.addWidget(self.ai_status_lbl); ctrl_layout.addStretch()
        ctrl_layout.addWidget(wake_btn); ctrl_layout.addWidget(sleep_btn)
        ctrl_group.setLayout(ctrl_layout); ai_layout.addWidget(ctrl_group)

        # --- NEW: AI ENGINE SELECTOR ---
        engine_layout = QHBoxLayout()
        engine_layout.addWidget(QLabel("Select Active Neural Engine:"))
        
        self.ai_model_dropdown = QComboBox()
        self.ai_model_dropdown.addItems([
            "Local: Qwen2.5-Coder (Offline, Free)", 
            "Cloud: AWS Bedrock - Claude Opus 4.7 (Heavy Compute)"
        ])
        self.ai_model_dropdown.setStyleSheet("padding: 8px; font-weight: bold; background-color: #141414; color: #00ff00; border: 1px solid #005500;")
        engine_layout.addWidget(self.ai_model_dropdown, stretch=1)
        ai_layout.addLayout(engine_layout)
        # ---------------------------------

        header = QLabel("[🤖] Tactical Pentest Assistant")
        header.setStyleSheet("font-size: 18px; font-weight: bold; color: #00ff00;")
        ai_layout.addWidget(header)

        # --- NEW: TACTICAL AI CONTROL PANEL ---
        ai_btn_layout = QHBoxLayout()
        
        self.tactical_btn = QPushButton("🚀 GENERATE TACTICAL BRIEFING")
        self.tactical_btn.setStyleSheet("""
            QPushButton { background-color: #ff0000; color: #ffffff; font-weight: bold; padding: 12px; border: 1px solid #770000;}
            QPushButton:hover { background-color: #cc0000; }
        """)
        self.tactical_btn.clicked.connect(self.get_tactical_briefing)
        
        self.end_chat_btn = QPushButton("💾 END DISCUSSION && SAVE TO PDF")
        self.end_chat_btn.setStyleSheet("""
            QPushButton { background-color: #0055aa; color: #ffffff; font-weight: bold; padding: 12px; border: 1px solid #000077;}
            QPushButton:hover { background-color: #004488; }
        """)
        self.end_chat_btn.clicked.connect(self.end_ai_discussion)
        
        ai_btn_layout.addWidget(self.tactical_btn)
        ai_btn_layout.addWidget(self.end_chat_btn)
        ai_layout.addLayout(ai_btn_layout)
        # ------------------------------------------------------
        
        self.ai_chat = QTextBrowser()
        self.ai_chat.setOpenExternalLinks(True)
        self.ai_chat.append("<b style='color:#ffffff;'>ARF AI:</b> Ready. Ensure Ollama service is 'Wake' if using the Local Model. AWS Bedrock requires API Key config. Ask me for payloads, command flags, or vulnerability explanations.")
        
        input_layout = QHBoxLayout()
        self.ai_input = QLineEdit(); self.ai_input.setPlaceholderText("root@arf:~# Ask the AI about commands or payloads... (Press Enter to send)")
        self.ai_input.setStyleSheet("font-size: 14px; padding: 12px;")
        self.ai_input.returnPressed.connect(self.ask_ai)
        
        self.ai_send_btn = QPushButton("Execute")
        self.ai_send_btn.setStyleSheet("background-color: #00aa00; color: #000000; padding: 12px;")
        self.ai_send_btn.clicked.connect(self.ask_ai)
        
        input_layout.addWidget(self.ai_input); input_layout.addWidget(self.ai_send_btn)
        
        ai_layout.addWidget(self.ai_chat); ai_layout.addLayout(input_layout)
        self.add_module(ai_widget, "[🤖] AI Assistant")

    def toggle_ai_service(self, action):
        """Starts or Stops the Ollama system service to manage RAM usage."""
        try:
            subprocess.run(["pkexec", "systemctl", action, "ollama"], check=True)
            self.ai_chat.append(f"<br><span style='color:#ffff00;'>[*] AI Service signal '{action}' sent successfully.</span>")
            self.update_ai_service_status()
        except Exception as e:
            QMessageBox.critical(self, "Root Access Required", f"Failed to {action} Ollama service.\n\nRun this in terminal first:\nsudo systemctl {action} ollama")

    def update_ai_service_status(self):
        """Check if Ollama is running and update the GUI label."""
        try:
            res = subprocess.run(["systemctl", "is-active", "ollama"], capture_output=True, text=True)
            if res.stdout.strip() == "active":
                self.ai_status_lbl.setText("SYSTEM STATUS: ONLINE (Model Loaded)")
                self.ai_status_lbl.setStyleSheet("font-weight: bold; color: #00ff00;")
            else:
                self.ai_status_lbl.setText("SYSTEM STATUS: OFFLINE (RAM Free)")
                self.ai_status_lbl.setStyleSheet("font-weight: bold; color: #ff0000;")
        except:
            pass

    def ask_ai(self):
        prompt = self.ai_input.text().strip()
        if not prompt: return
        self.ai_input.clear()
        
        model_choice = self.ai_model_dropdown.currentText()
        aws_bedrock_key = self.aws_bedrock_input.text().strip()
        
        # Add a placeholder that we will replace/update
        self.ai_chat.append(f"<br><span style='color:#ffffff;'><b>root@arf:~#</b> {prompt}</span>")
        self.ai_chat.append(f"<span id='ai-status' style='color:#888888;'><i>[SYSTEM]: Consulting Tactical Advisor ({model_choice.split(':')[0]})...</i></span>")
        
        self.ai_send_btn.setEnabled(False)
        self.ai_input.setEnabled(False) # Prevent double-entry during high CPU load

        self.ai_thread = AIWorker(prompt, model_choice, aws_bedrock_key)
        self.ai_thread.response_signal.connect(self.handle_ai_response)
        self.ai_thread.error_signal.connect(self.handle_ai_error)
        
        # Ensure cleanup happens even if the worker crashes or times out
        self.ai_thread.finished.connect(self.cleanup_ai_ui)
        self.ai_thread.start()

    def cleanup_ai_ui(self):
        self.ai_send_btn.setEnabled(True)
        self.ai_input.setEnabled(True)
        self.ai_input.setFocus()
        
    def end_ai_discussion(self):
        """Grabs the entire chat history and saves it for the Master PDF Report."""
        if getattr(self, 'current_scan_dir', None) is None:
            QMessageBox.warning(self, "No Active Scan", "No scan is currently loaded. Please run a scan or load one from the Export tab first.")
            return
            
        chat_content = self.ai_chat.toPlainText()
        
        # 1. Clean out the boilerplate boot message
        boilerplate = "ARF AI: 3B Coder Model Ready. I am running completely offline. Ensure Ollama service is 'Wake' to use me. Ask me for payloads, command flags, or vulnerability explanations."
        clean_content = chat_content.replace(boilerplate, "")
        
        # 2. Strip out UI elements and system tags, but PRESERVE newlines
        cleaned_lines = []
        for line in clean_content.split('\n'):
            if "root@arf:~#" in line or "[SYSTEM]:" in line or "[*] ANALYZING WORKSPACE" in line:
                continue
            if line.startswith("[AI]:"):
                line = line.replace("[AI]:", "").strip()
            cleaned_lines.append(line.strip())
            
        # Collapse excessive empty lines but preserve paragraph breaks
        final_clean_content = re.sub(r'\n{3,}', '\n\n', "\n".join(cleaned_lines)).strip()
        
        # --- SQLITE SIPHON ---
        scan_id = os.path.basename(self.current_scan_dir)
        try:
            db.delete_tool_output(scan_id, "AI_Briefing")
            db.save_tool_output(scan_id, "AI_Briefing", final_clean_content)
            
            self.ai_chat.append("<br><span style='color:#00ffff;'><b>[SYSTEM]:</b> Discussion ended. Full AI strategic log synchronized with SQLite Vault.</span>")
            self.fancy_log(f"[INFO] AI Discussion manually saved to Vault for {scan_id}")
        except Exception as e:
            QMessageBox.critical(self, "Save Error", f"Failed to save discussion to DB: {str(e)}")

    def handle_ai_response(self, text):
        self.ai_chat.append(f"<span style='color:#00ff00;'><b>[AI]:</b> {text}</span>")
        
        # --- IMPROVED: Save Briefing directly to SQLite Vault ---
        if getattr(self, 'is_briefing_mode', False) and self.current_scan_dir:
            scan_id = os.path.basename(self.current_scan_dir)
            try:
                # --- FIX: Use the thread-safe class method instead of raw cursor! ---
                db.delete_tool_output(scan_id, 'AI_Briefing')
                db.save_tool_output(scan_id, "AI_Briefing", text)
                self.fancy_log(f"[INFO] Tactical Briefing automatically synced to SQLite Vault.")
            except Exception as e:
                self.fancy_log(f"[ERROR] Failed to save AI briefing to Vault: {e}")
            self.is_briefing_mode = False # Reset flag
            
    def handle_ai_error(self, error_msg):
        self.ai_chat.append(f"<span style='color:#ff0000;'><b>[!] AI Error:</b> {error_msg}</span>")

    def setup_tool_manuals(self):
        manual_widget = QWidget(); m_layout = QVBoxLayout(manual_widget)
        header = QLabel("[📚] Offline Tool Manuals & Help")
        header.setStyleSheet("font-size: 18px; font-weight: bold; color: #00ff00;")
        m_layout.addWidget(header)
        m_layout.addWidget(QLabel("Select a tool to execute its help command."))
        
        controls = QHBoxLayout()
        self.tool_dropdown = QLineEdit(); self.tool_dropdown.setPlaceholderText("e.g., nmap, subfinder, httpx")
        self.tool_dropdown.setStyleSheet("padding: 10px; font-size: 14px;")
        fetch_btn = QPushButton("Fetch Manual"); fetch_btn.clicked.connect(self.fetch_manual)
        fetch_btn.setStyleSheet("padding: 10px; font-size: 14px;")
        controls.addWidget(self.tool_dropdown); controls.addWidget(fetch_btn)
        m_layout.addLayout(controls)
        
        self.manual_output = QTextBrowser()
        m_layout.addWidget(self.manual_output)
        self.add_module(manual_widget, "[📚] Tool Manuals")

    def fetch_manual(self):
        # 1. Get input without forcing lowercase yet
        raw_input = self.tool_dropdown.text().strip()
        if not raw_input: return
        
        # 2. Normalize the name for system calls
        # If user types 'theharvester', we force it to 'theHarvester' for Kali
        if raw_input.lower() == "theharvester":
            cmd_tool = "theHarvester"
        else:
            cmd_tool = raw_input.lower() # Default to lowercase for other tools

        self.manual_output.setText(f"[*] Fetching manual for {cmd_tool}...\n")
        
        cmd = []
        # 3. Tool-specific flag handling
        if cmd_tool == "theHarvester":
            cmd = ["theHarvester", "-h"]
        elif cmd_tool == "dig":
            cmd = ["dig", "-h"]
        elif cmd_tool == "nslookup":
            cmd = ["nslookup", "-version"] 
        elif cmd_tool == "cloud_enum":
            # Wrapper call (now synced to System Python via our symlink)
            cmd = ["cloud_enum", "-h"] 
        else:
            # Default for most tools
            cmd = [cmd_tool, "--help"]

        # 4. Push to worker (No changes needed here)
        self.man_worker = ManualWorker(cmd)
        self.man_worker.output_signal.connect(lambda txt: self.manual_output.setHtml(f"<pre style='color:#00ff00;'>{ansi_to_html(txt)}</pre>"))
        self.man_worker.start()

    def setup_history_tab(self):
        hist_widget = QWidget()
        hist_layout = QVBoxLayout(hist_widget)

        btn_layout = QHBoxLayout()
        clear_hist_btn = QPushButton("🗑️ Clear Target History")
        clear_hist_btn.setStyleSheet("background-color: #aa0000; color: #ffffff; font-weight: bold; padding: 8px;")
        clear_hist_btn.clicked.connect(self.clear_target_history)
        btn_layout.addStretch()
        btn_layout.addWidget(clear_hist_btn)
        hist_layout.addLayout(btn_layout)

        self.history_table = QTableWidget(); self.history_table.setColumnCount(4)
        self.history_table.setSortingEnabled(True)
        self.history_table.setHorizontalHeaderLabels(["Date/Time", "Target", "Assets Found", "Status"])
        self.history_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        hist_layout.addWidget(self.history_table)

        self.add_module(hist_widget, "[🕒] Target History")
        self.refresh_history_table()

    def refresh_history_table(self):
        project = self.config.get("project_name", "Default_Workspace")
        self.history_table.setRowCount(0)
        
        with db.lock:
            # Pull Master Scans from SQLite
            db.cursor.execute("SELECT scan_id, timestamp, target FROM scans WHERE workspace=? AND scan_type IN ('AdvancedRecon', 'BashAutoScan') ORDER BY timestamp DESC", (project,))
            rows = db.cursor.fetchall()
            
            self.history_table.setRowCount(len(rows))
            for row, (sid, ts, target) in enumerate(rows):
                # Fetch total assets for this scan
                db.cursor.execute("SELECT COUNT(id) FROM assets WHERE scan_id=?", (sid,))
                asset_count = db.cursor.fetchone()[0]
                
                self.history_table.setItem(row, 0, QTableWidgetItem(ts))
                self.history_table.setItem(row, 1, QTableWidgetItem(target))
                self.history_table.setItem(row, 2, QTableWidgetItem(str(asset_count)))
                self.history_table.setItem(row, 3, QTableWidgetItem("Completed (Vault)"))

    def clear_target_history(self):
        project = self.config.get("project_name", "Default_Workspace")
        reply = QMessageBox.question(self, 'Clear Target History', f"Are you sure you want to permanently clear the target scan history for [{project}] from the Vault?", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            # --- THE ANT FIX: Cascade delete to prevent DB bloat! ---
            with db.lock:
                db.cursor.execute("SELECT scan_id FROM scans WHERE workspace=? AND scan_type IN ('AdvancedRecon', 'BashAutoScan')", (project,))
                scans_to_delete = [r[0] for r in db.cursor.fetchall()]
                for sid in scans_to_delete:
                    db.cursor.execute("DELETE FROM assets WHERE scan_id=?", (sid,))
                    db.cursor.execute("DELETE FROM tool_outputs WHERE scan_id=?", (sid,))
                    
                db.cursor.execute("DELETE FROM scans WHERE workspace=? AND scan_type IN ('AdvancedRecon', 'BashAutoScan')", (project,))
                db.conn.commit()
            
            self.refresh_history_table()
            
    def setup_manual_history_tab(self):
        widget = QWidget(); layout = QVBoxLayout(widget)
        
        btn_layout = QHBoxLayout()
        refresh_btn = QPushButton("🔄 Refresh Tool Logs")
        refresh_btn.setStyleSheet("background-color: #005500; color: #ffffff; font-weight: bold; padding: 8px;")
        refresh_btn.clicked.connect(self.refresh_manual_history_table)
        
        clear_logs_btn = QPushButton("🗑️ Clear Tool Logs")
        clear_logs_btn.setStyleSheet("background-color: #aa0000; color: #ffffff; font-weight: bold; padding: 8px;")
        clear_logs_btn.clicked.connect(self.clear_manual_history)
        
        btn_layout.addWidget(refresh_btn); btn_layout.addWidget(clear_logs_btn); btn_layout.addStretch()
        layout.addLayout(btn_layout)
        
        self.manual_history_table = QTableWidget(); self.manual_history_table.setColumnCount(4)
        self.manual_history_table.setSortingEnabled(True)
        self.manual_history_table.setHorizontalHeaderLabels(["Date/Time", "Tool Name", "Target", "Executed Arguments"])
        self.manual_history_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.manual_history_table)
        
        self.add_module(widget, "[📝] Single Tool Logs")
        self.refresh_manual_history_table()

    def refresh_manual_history_table(self):
        project = self.config.get("project_name", "Default_Workspace")
        self.manual_history_table.setRowCount(0)
        
        with db.lock:
            # Pull Manual Tool logs from SQLite
            db.cursor.execute("SELECT scan_id, timestamp, target FROM scans WHERE workspace=? AND scan_type='Manual' ORDER BY timestamp DESC", (project,))
            rows = db.cursor.fetchall()
        
        self.manual_history_table.setRowCount(len(rows))
        for row, (sid, ts, target_info) in enumerate(rows):
            # We packed Tool and Args into 'target_info' when saving in UniversalToolTab
            parts = target_info.split(" | ", 2)
            tool = parts[0].strip() if len(parts) > 0 else "Unknown"
            target = parts[1].strip() if len(parts) > 1 else ""
            args = parts[2].strip() if len(parts) > 2 else ""

            self.manual_history_table.setItem(row, 0, QTableWidgetItem(ts))
            self.manual_history_table.setItem(row, 1, QTableWidgetItem(tool))
            self.manual_history_table.setItem(row, 2, QTableWidgetItem(target))
            self.manual_history_table.setItem(row, 3, QTableWidgetItem(args))

    def clear_manual_history(self):
        project = self.config.get("project_name", "Default_Workspace")
        reply = QMessageBox.question(self, 'Clear Tool Logs', f"Are you sure you want to permanently clear the individual tool logs for [{project}] from the Vault?", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            # --- THE ANT FIX: Cascade delete manual tool outputs! ---
            with db.lock:
                db.cursor.execute("SELECT scan_id FROM scans WHERE workspace=? AND scan_type='Manual'", (project,))
                scans_to_delete = [r[0] for r in db.cursor.fetchall()]
                for sid in scans_to_delete:
                    db.cursor.execute("DELETE FROM tool_outputs WHERE scan_id=?", (sid,))
                
                db.cursor.execute("DELETE FROM scans WHERE workspace=? AND scan_type='Manual'", (project,))
                db.conn.commit()
                
            self.refresh_manual_history_table()    

    def setup_export_manager(self):
        export_widget = QWidget(); e_layout = QVBoxLayout(export_widget)
        e_layout.addWidget(QLabel("Manage and view consolidated reports for past scans."))
        
        # --- SORTING CONTROLS ---
        sort_bar = QHBoxLayout()
        sort_bar.addWidget(QLabel("Sort By:"))
        
        self.export_sort_dropdown = QComboBox()
        self.export_sort_dropdown.addItems([
            "Name (A-Z)", 
            "Name (Z-A)", 
            "Date (Newest First)", 
            "Date (Oldest First)",
            "Project Grouping"
        ])
        self.export_sort_dropdown.setStyleSheet("background-color: #141414; color: #00ff00; border: 1px solid #005500; padding: 5px;")
        self.export_sort_dropdown.currentIndexChanged.connect(self.refresh_export_list)
        
        sort_bar.addWidget(self.export_sort_dropdown)
        sort_bar.addStretch()
        e_layout.addLayout(sort_bar)

        self.export_list = QListWidget()
        self.export_list.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.refresh_export_list()
        e_layout.addWidget(self.export_list)
        
        # --- EXPORT BUTTONS ---
        btn_layout = QHBoxLayout()
        refresh_btn = QPushButton("🔄 Refresh Workspace Data")
        refresh_btn.clicked.connect(self.refresh_export_list)

        # --- NEW: Maltego Launcher Button ---
        maltego_btn = QPushButton("🔱 Export && Launch Maltego")
        maltego_btn.setStyleSheet("background-color: #4b0082; color: #ffffff; font-weight: bold;")
        maltego_btn.clicked.connect(self.export_and_launch_maltego)
        
        pdf_btn = QPushButton("📄 Generate Master PDF")
        pdf_btn.setStyleSheet("background-color: #aa0000; color: #ffffff;")
        pdf_btn.clicked.connect(self.generate_master_pdf)
        
        self.graph_btn = QPushButton("🌐 Open Interactive Graph")
        self.graph_btn.setStyleSheet("background-color: #0000aa; color: #ffffff;")
        self.graph_btn.clicked.connect(self.open_historical_graph)
        self.load_dash_btn = QPushButton("⏳ Restore to Dashboard")
        self.load_dash_btn.setStyleSheet("background-color: #aa5500; color: #ffffff;")
        self.load_dash_btn.clicked.connect(self.load_historical_dashboard)
        
        # --- NEW: Delete Button ---
        delete_report_btn = QPushButton("🗑️ Delete Selected")
        delete_report_btn.setStyleSheet("background-color: #550000; color: #ffffff;")
        delete_report_btn.clicked.connect(self.delete_selected_report)
        
        btn_layout.addWidget(refresh_btn); btn_layout.addWidget(pdf_btn)
        btn_layout.addWidget(maltego_btn)
        btn_layout.addWidget(self.graph_btn); btn_layout.addWidget(self.load_dash_btn)
        btn_layout.addWidget(delete_report_btn)
        e_layout.addLayout(btn_layout)
        self.add_module(export_widget, "[📄] Export && Reports")

    def refresh_export_list(self):
        self.export_list.clear()
        
        temp_data = []
        with db.lock:
            # Fetch ONLY Live Reconnaissance Scans (Base Version Behavior)
            db.cursor.execute("SELECT scan_id, timestamp, workspace FROM scans WHERE scan_type = 'AdvancedRecon'")
            rows = db.cursor.fetchall()
            
        for r in rows:
            sid, ts, ws = r
            try:
                # Convert timestamp back to float for sorting
                mtime = datetime.datetime.strptime(ts, "%Y-%m-%d %H:%M:%S").timestamp()
            except:
                mtime = 0
            temp_data.append({"display": f"[{ws}] {sid}", "time": mtime, "proj": ws.lower(), "name": sid.lower()})

        # --- SORTING LOGIC ---
        method = self.export_sort_dropdown.currentText()
        
        if method == "Name (A-Z)":
            temp_data.sort(key=lambda x: x["display"].lower())
        elif method == "Name (Z-A)":
            temp_data.sort(key=lambda x: x["display"].lower(), reverse=True)
        elif method == "Date (Newest First)":
            temp_data.sort(key=lambda x: x["time"], reverse=True)
        elif method == "Date (Oldest First)":
            temp_data.sort(key=lambda x: x["time"])
        elif method == "Project Grouping":
            # Sorts by Project name first, then by the Date within that project
            temp_data.sort(key=lambda x: (x["proj"], x["time"]), reverse=True)

        # Re-populate the list with sorted data
        for item in temp_data:
            self.export_list.addItem(item["display"])           

    def generate_master_pdf(self):
        import textwrap # Safe native import for bulletproof text wrapping
        
        if not FPDF_AVAILABLE:
            QMessageBox.critical(self, "Missing Dependency", "The 'fpdf2' library is not installed. Please run the Auto Installer or type 'pip install fpdf2' in your terminal.")
            return
            
        selected_items = self.export_list.selectedItems()
        if not selected_items:
            QMessageBox.warning(self, "Export Warning", "Please select a scan directory first.")
            return
        if len(selected_items) > 1:
            QMessageBox.warning(self, "Export Warning", "Please select only ONE scan directory to generate a PDF.")
            return
            
        selected = selected_items[0]
        scan_name = selected.text().split("] ")[-1]
        proj_name = selected.text().split("] ")[0].replace("[", "")
        target_dir = os.path.join("Scan_Results", proj_name, scan_name)
        
        # Initialize Professional PDF
        pdf = FPDF()
        pdf.set_auto_page_break(auto=True, margin=15)
        
        # --- 1. PROFESSIONAL TITLE PAGE ---
        pdf.add_page()
        pdf.set_fill_color(10, 30, 10)
        pdf.rect(0, 0, 210, 100, 'F')
        
        pdf.ln(30)
        pdf.set_font("helvetica", 'B', 32)
        pdf.set_text_color(0, 255, 65) # Matrix Green
        pdf.cell(0, 20, text="ALI RAZA RECON FRAMEWORK", new_x=XPos.LMARGIN, new_y=YPos.NEXT, align='C')
        
        pdf.set_font("helvetica", 'B', 18)
        pdf.set_text_color(255, 255, 255)
        pdf.cell(0, 10, text="CYBERSECURITY INFRASTRUCTURE AUDIT", new_x=XPos.LMARGIN, new_y=YPos.NEXT, align='C')
        
        pdf.set_text_color(0, 0, 0)
        pdf.ln(60)
        pdf.set_font("helvetica", 'B', 14)
        pdf.cell(0, 10, text="PREPARED FOR:", new_x=XPos.LMARGIN, new_y=YPos.NEXT, align='C')
        pdf.set_font("helvetica", '', 12)
        pdf.cell(0, 10, text=f"Target: {scan_name}", new_x=XPos.LMARGIN, new_y=YPos.NEXT, align='C')
        pdf.cell(0, 10, text=f"Project Workspace: {proj_name}", new_x=XPos.LMARGIN, new_y=YPos.NEXT, align='C')
        pdf.ln(20)
        pdf.set_font("helvetica", 'I', 10)
        pdf.cell(0, 10, text=f"Generation Date: {datetime.datetime.now().strftime('%B %d, %Y - %H:%M')}", new_x=XPos.LMARGIN, new_y=YPos.NEXT, align='C')

        # --- 2. EXECUTIVE SUMMARY & RISK ASSESSMENT ---
        data = db.get_asset_data(scan_name)
        if data:
            pdf.add_page()
            pdf.set_font("helvetica", 'B', 16)
            pdf.set_text_color(0, 100, 0)
            pdf.cell(0, 10, text="1. EXECUTIVE RISK ASSESSMENT", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
            pdf.line(10, pdf.get_y(), 200, pdf.get_y())
            pdf.ln(10)
            
            risk_score = db.get_scan_risk(scan_name)
            pdf.set_font("helvetica", 'B', 12)
            pdf.set_text_color(0, 0, 0)
            pdf.cell(50, 10, text=f"THREAT LOAD RATING:")
            
            pdf.set_fill_color(220, 220, 220)
            pdf.rect(60, pdf.get_y()+2, 100, 6, 'F')
            if risk_score < 30: pdf.set_fill_color(0, 255, 0)
            elif risk_score < 70: pdf.set_fill_color(255, 255, 0)
            else: pdf.set_fill_color(255, 0, 0)
            pdf.rect(60, pdf.get_y()+2, risk_score, 6, 'F')
            pdf.cell(110, 10, text=f"{risk_score}/100", align='R', new_x=XPos.LMARGIN, new_y=YPos.NEXT)
            
            pdf.ln(5)
            total = len(data)
            vuln_hosts = sum(1 for d in data.values() if d.get('vulns'))
            pdf.set_font("helvetica", '', 11)
            pdf.multi_cell(0, 8, text=f"The reconnaissance phase identified {total} assets. Out of these, {vuln_hosts} hosts show critical vulnerabilities or insecure configurations. The framework has balanced offensive discovery with stability, ensuring real-time telemetry of host performance.")
            pdf.ln(10)

            # --- 3. AI TACTICAL ADVISOR BRIEFING ---
            pdf.set_font("helvetica", 'B', 16)
            pdf.set_text_color(0, 100, 0)
            pdf.cell(0, 10, text="2. AI-DRIVEN TACTICAL STRATEGY", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
            pdf.line(10, pdf.get_y(), 200, pdf.get_y())
            pdf.ln(5)
            
            with db.lock:
                db.cursor.execute("SELECT raw_text FROM tool_outputs WHERE scan_id=? AND tool_name='AI_Briefing'", (scan_name,))
                row = db.cursor.fetchone()
            
            if row and row[0].strip():
                tactical_text = row[0]
                
                # --- THE MAGIC PARSER: UN-PANCAKE THE AI TEXT ---
                tactical_text = tactical_text.replace('**', '').replace('`', '').replace('###', '').replace('##', '')
                
                # Expand hidden lists and separators into actual newlines
                tactical_text = tactical_text.replace(' - ', '\n- ')
                tactical_text = tactical_text.replace(' --- ', '\n\n')
                tactical_text = tactical_text.replace(' # ', '\n\n# ')
                tactical_text = re.sub(r'(?<!\n)( \d+\. )', r'\n\1', tactical_text)
                
                # Force breaks on Major Section Headers
                sections = ['MISSION BRIEFING:', 'SYSTEM CONTEXT', 'INFRASTRUCTURE DATA', "COMMANDER'S INTENT", 'RESPONSE FORMAT', 'CONCLUSION:']
                for sec in sections:
                    tactical_text = re.sub(rf'(?i)({sec})', r'\n\n\1\n', tactical_text)

                # Strip empty lines
                lines = [line.strip() for line in tactical_text.split('\n') if line.strip()]
                
                for line in lines:
                    safe_line = line.encode('latin-1', 'replace').decode('latin-1')
                    pdf.set_x(15) # Safety reset for FPDF cursor
                    
                    # Heuristic 1: Major Headers
                    if any(safe_line.upper().startswith(s.replace(':', '')) for s in sections) or (safe_line.isupper() and len(safe_line) > 6):
                        pdf.ln(6)
                        pdf.set_font("helvetica", 'B', 13)
                        pdf.set_text_color(0, 50, 100) # Dark Blue
                        pdf.multi_cell(0, 6, text=safe_line.replace(':', '').strip())
                        pdf.ln(2)
                        
                    # Heuristic 2: Sub-headers (Lines starting with #)
                    elif safe_line.startswith('# '):
                        pdf.ln(3)
                        pdf.set_font("helvetica", 'B', 11)
                        pdf.set_text_color(20, 20, 20)
                        pdf.multi_cell(0, 6, text=safe_line.replace('# ', '').strip())
                        
                    # Heuristic 3: Commands / Code Blocks
                    elif any(cmd in safe_line.lower() for cmd in ['bash ', 'nmap ', 'curl ', 'msfconsole', 'powershell']):
                        pdf.ln(2)
                        pdf.set_font("courier", 'B', 9)
                        pdf.set_text_color(0, 120, 0) # Terminal Green
                        wrapped_cmd = "\n".join(textwrap.wrap(safe_line, width=105, break_long_words=True))
                        pdf.multi_cell(0, 5, text="> " + wrapped_cmd)
                        pdf.ln(2)
                        
                    # Heuristic 4: Lists (Numbered or Bulleted)
                    elif re.match(r'^(\d+\.|[\-\*])\s+', safe_line) or safe_line.lower().startswith('step'):
                        pdf.set_font("helvetica", '', 11)
                        pdf.set_text_color(40, 40, 40)
                        indented = "      " + safe_line
                        wrapped_list = "\n      ".join(textwrap.wrap(indented.strip(), width=100, break_long_words=True))
                        pdf.multi_cell(0, 6, text=wrapped_list)
                        
                    # Heuristic 5: Standard Body Text
                    else:
                        pdf.set_font("helvetica", '', 11)
                        pdf.set_text_color(40, 40, 40)
                        wrapped_body = "\n".join(textwrap.wrap(safe_line, width=110, break_long_words=True))
                        pdf.multi_cell(0, 6, text=wrapped_body)
            else:
                pdf.set_font("helvetica", 'I', 11)
                pdf.set_text_color(100, 100, 100)
                pdf.set_x(15)
                pdf.multi_cell(0, 6, text="No Tactical Briefing generated for this scan.")
            
            pdf.ln(10)

            # --- 4. INFRASTRUCTURE OVERVIEW TABLE ---
            pdf.set_font("helvetica", 'B', 16)
            pdf.set_text_color(0, 100, 0)
            pdf.set_x(15)
            pdf.cell(0, 10, text="3. INFRASTRUCTURE INVENTORY", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
            pdf.line(10, pdf.get_y(), 200, pdf.get_y())
            pdf.ln(5)
            
            pdf.set_font("helvetica", 'B', 9)
            pdf.set_fill_color(10, 50, 10); pdf.set_text_color(255, 255, 255)
            pdf.cell(65, 10, text="Subdomain", border=1, fill=True)
            pdf.cell(45, 10, text="IP (Location)", border=1, fill=True)
            pdf.cell(80, 10, text="CVEs / Vulnerabilities", border=1, fill=True, new_x=XPos.LMARGIN, new_y=YPos.NEXT)
            
            pdf.set_text_color(0, 0, 0); pdf.set_font("helvetica", size=8)
            fill = False
            for sub, info in data.items():
                pdf.set_fill_color(245, 245, 245) if fill else pdf.set_fill_color(255, 255, 255)
                vuln_txt = ", ".join(info.get('vulns', [])) if info.get('vulns') else "Verified Secure"
                location = f"{info.get('city', 'U')}, {info.get('country', 'U')}"
                
                pdf.cell(65, 10, text=sub[:38], border=1, fill=fill)
                pdf.cell(45, 10, text=f"{info['ip']} ({location[:12]})", border=1, fill=fill)
                pdf.cell(80, 10, text=vuln_txt[:55], border=1, fill=fill, new_x=XPos.LMARGIN, new_y=YPos.NEXT)
                fill = not fill

        # --- 5. VISUAL EVIDENCE (AUTOMATED SCREENSHOTS) ---
        shot_dir = os.path.join(target_dir, "screenshots")
        if os.path.exists(shot_dir):
            for img_file in sorted(os.listdir(shot_dir)):
                if img_file.lower().endswith(".png"):
                    pdf.add_page()
                    pdf.set_draw_color(0, 100, 0)
                    pdf.rect(5, 5, 200, 287)
                    
                    pdf.set_font("helvetica", 'B', 14)
                    pdf.set_text_color(0, 100, 0)
                    pdf.set_x(15)
                    pdf.cell(0, 10, text=f"APPENDIX A: VISUAL EVIDENCE - {img_file}", new_x=XPos.LMARGIN, new_y=YPos.NEXT, align='C')
                    pdf.ln(10)
                    pdf.image(os.path.join(shot_dir, img_file), x=15, w=180)

        # --- 6. TECHNICAL EXECUTION LOGS (CLEANED) ---
        raw_logs = db.get_tool_logs(scan_name)
        if raw_logs:
            pdf.add_page()
            pdf.set_font("helvetica", 'B', 16)
            pdf.set_text_color(0, 100, 0)
            pdf.set_x(15)
            pdf.cell(0, 10, text="4. TECHNICAL EXECUTION LOGS", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
            pdf.line(10, pdf.get_y(), 200, pdf.get_y())
            pdf.ln(5)
            
            ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
            
            valid_logs_found = False
            for t_name, content in raw_logs:
                t_lower = t_name.lower()
                
                # Skip undesired background logs
                if t_lower in ["ai_briefing", "wayback_endpoints", "gui_master_log", "recon_runner"]:
                    continue
                    
                clean_content = ansi_escape.sub('', content).strip()
                if not clean_content:
                    continue
                    
                # --- NEW: EXECUTIVE ANTI-BLOAT FILTER ---
                # 1. Clean up massive FFUF/Wfuzz Help Menus (if they fail due to missing wordlists)
                if "Fuzz Faster U Fool" in clean_content and "Encountered error" in clean_content:
                    clean_content = "[!] FFUF Execution Failed (Ensure a valid wordlist is attached)."
                elif "Wfuzz" in clean_content and "Fatal exception" in clean_content:
                    clean_content = "[!] Wfuzz Execution Failed (Ensure a valid wordlist is attached)."

                # 2. Universal Truncation for massive outputs (Katana, GAU, FFUF, etc.)
                lines = clean_content.split('\n')
                if len(lines) > 40:
                    clean_content = "\n".join(lines[:40]) + f"\n\n... [ DATA TRUNCATED: {len(lines) - 40} additional lines hidden for Executive Report readability ] ..."
                # ----------------------------------------
                    
                valid_logs_found = True
                pdf.set_x(15)
                pdf.set_text_color(0, 50, 100)
                pdf.set_font("helvetica", 'B', 11)
                pdf.cell(0, 10, text=f"--- EXECUTED TOOL: {t_name.upper()} ---", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
                
                pdf.set_x(15)
                pdf.set_text_color(40, 40, 40)
                pdf.set_font("courier", size=8)
                safe_content = clean_content.encode('latin-1', 'replace').decode('latin-1')
                
                # Fix 2: Python native textwrap defuses the FPDF crash by splitting long strings 
                wrapped_content = "\n".join(["\n".join(textwrap.wrap(line, width=130, break_long_words=True)) for line in safe_content.split('\n')])
                
                pdf.multi_cell(0, 4, text=wrapped_content)
                pdf.ln(5)
                
            if not valid_logs_found:
                pdf.set_font("helvetica", 'I', 10)
                pdf.set_text_color(100, 100, 100)
                pdf.set_x(15)
                pdf.multi_cell(0, 6, text="No raw execution logs available for this scan.")

        # Output the Final File
        pdf_path = os.path.join(target_dir, f"{scan_name}_MASTER_AUDIT_REPORT.pdf")
        # --- BULLETPROOF PDF SAVER ---
        try:
            # 1. Force the directory to exist (creates it safely if missing)
            os.makedirs(os.path.dirname(pdf_path), exist_ok=True)
            # 2. Save the PDF
            pdf.output(pdf_path)
        except Exception as e:
            QMessageBox.critical(self, "PDF Export Error", f"Failed to save PDF. The operating system blocked the file write:\n\n{str(e)}")
            return
        # -----------------------------
        QMessageBox.information(self, "Audit Complete", f"Professional PDF Report Generated:\n{pdf_path}")

    def export_and_launch_maltego(self):
        """Converts SQLite asset data into a Maltego CSV and auto-launches Maltego CE."""
        selected_items = self.export_list.selectedItems()
        if not selected_items:
            QMessageBox.warning(self, "Export Warning", "Please select a scan to export.")
            return
        
        scan_name = selected_items[0].text().split("] ")[-1]
        proj_name = selected_items[0].text().split("] ")[0].replace("[", "")
        
        save_path = os.path.abspath(os.path.join("Scan_Results", proj_name, f"{scan_name}_Maltego.csv"))

        try:
            # --- THE FIX: Removed the redundant 'with db.lock:' wrap ---
            # get_asset_data() already safely handles its own database locking!
            data = db.get_asset_data(scan_name)
            
            if not data:
                QMessageBox.warning(self, "No Data", "This scan contains no asset data to export.")
                return

            with open(save_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow(["Type", "Value", "Notes", "IP Address"])
                for sub, info in data.items():
                    writer.writerow(["maltego.DNSName", sub, f"WAF: {info['waf']}", info['ip']])
                    if info['ip'] and info['ip'] != "Unknown":
                        writer.writerow(["maltego.IPv4Address", info['ip'], f"OS: {info['os']}", ""])
            
            self.fancy_log(f"[INFO] Maltego CSV generated: {save_path}")
            
            # --- DETACHED EXECUTION ---
            if platform.system() == "Linux":
                subprocess.Popen(
                    ["maltego", save_path], 
                    stdout=subprocess.DEVNULL, 
                    stderr=subprocess.DEVNULL,
                    start_new_session=True,  # Forces Maltego into its own isolated process group
                    close_fds=True           # Prevents Maltego from locking Python's files
                )
            elif platform.system() == "Windows":
                os.startfile(save_path)
                
            QMessageBox.information(self, "Export Successful", "Data exported. Maltego CE is launching in the background.")
        except Exception as e:
            QMessageBox.critical(self, "Export Error", f"Failed to generate/launch Maltego context: {str(e)}")
        
    def open_historical_graph(self):
        selected_items = self.export_list.selectedItems()
        if not selected_items:
            QMessageBox.warning(self, "Export Warning", "Please select a scan directory first.")
            return
        if len(selected_items) > 1:
            QMessageBox.warning(self, "Export Warning", "Please select only ONE scan directory to view its graph.")
            return
            
        selected = selected_items[0]
        scan_name = selected.text().split("] ")[-1]
        proj_name = selected.text().split("] ")[0].replace("[", "")
        target_dir = os.path.abspath(os.path.join("Scan_Results", proj_name, scan_name))
        graph_path = os.path.join(target_dir, "network_graph.html")
        
        # --- THE DYNAMIC GRAPH FIX ---
        if not os.path.exists(graph_path):
            data = db.get_asset_data(scan_name)
            if data: graph_path = self.generate_pyvis_graph(target_dir, data)
        # -----------------------------
        
        if graph_path and os.path.exists(graph_path):
            import webbrowser
            webbrowser.open(f"file://{graph_path}")
        else:
            QMessageBox.information(self, "Not Found", "No PyVis graph found, and auto-generation failed (Does the scan have data?).")  

    def setup_workspace_tab(self):
        workspace_widget = QWidget()
        layout = QVBoxLayout(workspace_widget)
        
        # --- 1. WORKSPACE SELECTOR (Quick Switch between existing) ---
        selector_group = QGroupBox("Switch Active Workspace")
        s_layout = QHBoxLayout()
        
        self.ws_dropdown = QComboBox()
        self.ws_dropdown.setStyleSheet("padding: 8px; background-color: #141414; color: #00ff00; border: 1px solid #005500;")
        
        refresh_ws_btn = QPushButton("🔄 Sync")
        refresh_ws_btn.setToolTip("Scans your folders and config to find existing workspaces.")
        refresh_ws_btn.clicked.connect(self.populate_workspace_list)
        
        load_ws_btn = QPushButton("📂 Load")
        load_ws_btn.setStyleSheet("background-color: #005500; color: white; font-weight: bold;")
        load_ws_btn.clicked.connect(self.load_selected_workspace)
        
        s_layout.addWidget(self.ws_dropdown, stretch=2)
        s_layout.addWidget(refresh_ws_btn)
        s_layout.addWidget(load_ws_btn)
        selector_group.setLayout(s_layout); layout.addWidget(selector_group)

        # --- 2. WORKSPACE SETTINGS (Create new or Edit current) ---
        group = QGroupBox("Persistent Workspace Settings")
        flayout = QFormLayout()
        
        current_proj = self.config.get("project_name", "Default_Workspace")
        current_shodan = self.config.get("shodan_keys", {}).get(current_proj, "")
        current_webhook = self.config.get("webhook_urls", {}).get(current_proj, "")
        
        # --- THE MISSING LINE WE NEEDED TO KEEP ---
        self.ws_project = QLineEdit(current_proj)
        self.ws_project.setPlaceholderText("Enter a name to create a new workspace...")
        flayout.addRow("Project / Workspace Name:", self.ws_project)
        # ------------------------------------------
        
        self.ws_shodan = QLineEdit(current_shodan)
        self.ws_shodan.setEchoMode(QLineEdit.EchoMode.Password)
        flayout.addRow("Saved Shodan Key:", self.ws_shodan)
        
        self.ws_webhook = QLineEdit(current_webhook)
        self.ws_webhook.setPlaceholderText("Discord/Slack Webhook URL")
        flayout.addRow("Saved Webhook URL:", self.ws_webhook)
        
        save_btn = QPushButton("SAVE / CREATE WORKSPACE")
        save_btn.setStyleSheet("background-color: #00aa00; color: #000000; padding: 10px; font-weight: bold;")
        save_btn.clicked.connect(self.save_workspace)
        
        group.setLayout(flayout); layout.addWidget(group); layout.addWidget(save_btn); layout.addStretch()
        self.add_module(workspace_widget, "[🗂️] Workspace Config")

    def save_workspace(self):
        new_proj = self.ws_project.text().strip() or "Default_Workspace"
        
        # 1. Save keys to workspace-specific dictionary
        if "shodan_keys" not in self.config: self.config["shodan_keys"] = {}
        if "webhook_urls" not in self.config: self.config["webhook_urls"] = {}
        if "out_of_scope" not in self.config: self.config["out_of_scope"] = {}
        
        self.config["shodan_keys"][new_proj] = self.ws_shodan.text().strip()
        self.config["webhook_urls"][new_proj] = self.ws_webhook.text().strip()
        self.config["out_of_scope"][new_proj] = self.scope_input.text().strip()
        
        # 2. Update the active project name
        self.config["project_name"] = new_proj

        # =========================================================
        # --- NEW: SAVE GLOBAL THREAT INTEL API KEYS ---
        # =========================================================
        if "api_keys" not in self.config:
            self.config["api_keys"] = {}
            
        self.config["api_keys"]["vt"] = self.vt_input.text().strip()
        self.config["api_keys"]["greynoise"] = self.greynoise_input.text().strip()
        self.config["api_keys"]["pulsedive"] = self.pulsedive_input.text().strip()
        self.config["api_keys"]["censys_id"] = self.censys_id_input.text().strip()
        self.config["api_keys"]["aws_bedrock"] = self.aws_bedrock_input.text().strip()  # <--- NEW AWS KEY SAVED
        # =========================================================

        self.trigger_save_config()

        # 3. Sync the top-panel UI fields with the active workspace keys
        self.shodan_input.setText(self.config["shodan_keys"].get(new_proj, ""))
        self.webhook_input.setText(self.config["webhook_urls"].get(new_proj, ""))
        
        # 4. Refresh tables to show isolated data
        self.refresh_history_table()
        self.refresh_manual_history_table()
        self.refresh_export_list()
        
        self.workspace_status_lbl.setText(f"ACTIVE WORKSPACE: [{self.config['project_name']}]  ")
        
        # --- THE FIX: Force the dropdown to acknowledge the new workspace immediately ---
        self.populate_workspace_list()

        QMessageBox.information(self, "Success", f"Workspace '{new_proj}' saved with independent settings.")
        
    def populate_workspace_list(self):
        """Finds all workspaces from both the SQLite Vault and the Config Registry."""
        workspaces = set()
        
        try:
            # --- FIX: Added with db.lock ---
            with db.lock:
                # 1. Pull directly from the database (Workspaces with actual scans)
                db.cursor.execute("SELECT DISTINCT workspace FROM scans")
                for row in db.cursor.fetchall():
                    workspaces.add(row[0])
        except Exception: pass
        
        # 2. Pull from the config file (Captures empty/new workspaces with no scans yet)
        for ws in self.config.get("shodan_keys", {}).keys():
            workspaces.add(ws)
            
        # 3. Add current active workspace (Failsafe)
        workspaces.add(self.config.get("project_name", "Default_Workspace"))
        
        self.ws_dropdown.clear()
        self.ws_dropdown.addItems(sorted(list(workspaces)))
        
        # 4. Set current active one as the selected item
        current = self.config.get("project_name", "Default_Workspace")
        index = self.ws_dropdown.findText(current)
        if index >= 0:
            self.ws_dropdown.setCurrentIndex(index)

    def load_selected_workspace(self):
        selected_ws = self.ws_dropdown.currentText()
        if not selected_ws: return
        
        # 1. Update the local workspace config fields
        self.ws_project.setText(selected_ws)
        
        # 2. Extract values from our main config dictionary
        shodan_key = self.config.get("shodan_keys", {}).get(selected_ws, "")
        webhook_url = self.config.get("webhook_urls", {}).get(selected_ws, "")
        scope_rules = self.config.get("out_of_scope", {}).get(selected_ws, "")
        
        # 3. CRITICAL SYNC: Push these values to the TOP Core Config panel
        self.shodan_input.setText(shodan_key)
        self.webhook_input.setText(webhook_url)
        self.scope_input.setText(scope_rules)
        
        # 4. Push these values to the Workspace Tab fields for editing
        self.ws_shodan.setText(shodan_key)
        self.ws_webhook.setText(webhook_url)
        
        # 5. Set as active project and save
        self.config["project_name"] = selected_ws
        self.save_workspace()

    def fancy_log(self, message):
        color_map = {"[DEBUG]": "#808080", "[INFO]": "#00ffff", "[WARNING]": "#ffff00", "[ERROR]": "#ff0000", "[CRITICAL]": "#ff0000"}
        for tag, color in color_map.items():
            if message.startswith(tag): message = f"<span style='color: {color}; font-weight: bold;'>{message}</span>"
        self.log_output.append(message)
        self.log_output.moveCursor(QTextCursor.MoveOperation.End)

    def start_scan(self):
        raw_input = self.target_input.text().strip()
        if not raw_input: return
        
        # --- THE FIX: Pop up the log window instantly ---
        self.force_focus_live_log()
    
        targets_str = ""
        if os.path.isfile(raw_input):
            with open(raw_input, 'r') as f: targets_str = ",".join([line.strip() for line in f if line.strip()])
        else:
            targets_str = raw_input

        self.scan_btn.setEnabled(False)
        self.term_scan_btn.setEnabled(True)
        self.results_table.setRowCount(0); self.progress_bar.setValue(0)
        self.log_output.clear()
    
        # Get active project and its unique keys
        current_proj = self.config.get("project_name", "Default_Workspace")
        active_shodan = self.config["shodan_keys"].get(current_proj, "")
        active_webhook = self.config["webhook_urls"].get(current_proj, "")
        
        # --- CRITICAL FIX: Fetch Threat Intel API keys from config ---
        api_keys = self.config.get("api_keys", {}) 
    
        self.worker = AdvancedReconWorker(
            targets_str, 
            self.wordlist_input.text(), 
            active_shodan, 
            int(self.threads_input.text()), 
            active_webhook, 
            self.continuous_check.isChecked(), 
            self.interval_spin.value(),
            current_proj,
            self.scope_input.text(),  
            api_keys  # <--- CRITICAL FIX: Pass the dictionary to the worker!
        )
    
        self.worker.signals.log_signal.connect(self.fancy_log)
        self.worker.signals.risk_score_signal.connect(self.update_risk_ui)
        self.worker.signals.progress_signal.connect(self.progress_bar.setValue)
        self.worker.signals.results_signal.connect(self.handle_results) 
        self.worker.signals.finished_signal.connect(self.scan_completed)
        self.worker.start()

    def terminate_scan(self):
        if self.worker and self.worker.isRunning():
            self.worker.stop()
            self.fancy_log("[CRITICAL] Force termination signal sent. Waiting for active tasks to stop...")

    def scan_completed(self):
        self.scan_btn.setEnabled(True)
        self.term_scan_btn.setEnabled(False)
        self.tray_icon.showMessage("ARF Framework", "Live Reconnaissance Scan Completed Successfully!", QSystemTrayIcon.MessageIcon.Information, 5000)

    def handle_results(self, data, target, base_dir):
        self.current_scan_data = data    
        self.current_scan_dir = base_dir
        self.populate_results(data)
        self.show_attack_path_alert()
        
        # --- STABILIZED UI RELOAD ---
        graph_path = os.path.abspath(os.path.join(base_dir, "network_graph.html"))
        
        if os.path.exists(graph_path):
            # 1. Clear internal browser cache to prevent loading broken/old JS files
            self.viz_dashboard.page().profile().clearHttpCache()
            
            # --- DEEP MEMORY LEAK FIX: Destroy C++ orphaned pointers ---
            old_page = self.viz_dashboard.page()
            blank_page = QWebEnginePage(self.viz_dashboard)
            self.viz_dashboard.setPage(blank_page)
            try:
                old_page.deleteLater()  # Explicitly tell Qt to free this block of RAM
            except RuntimeError:
                pass  # Qt already garbage collected the C++ object!

            # 2. Show visual placeholder to flush memory and reset the JS engine
            self.viz_dashboard.setHtml("""
        <html><body style='background-color: #050508; color: #00ff00; font-family: monospace; 
        display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0;'>
            <div style='border: 1px solid #1a5e20; padding: 20px;'>
                <h2 id='glitch'>[ SYNCING NEURAL TOPOLOGY... ]</h2>
                <script>
                    const el = document.getElementById('glitch');
                    const chars = "!<>-_\\/[]{}—=+*^?#________";
                    let original = el.innerText;
                    setInterval(() => {
                        el.innerText = original.split('').map(c => 
                            Math.random() > 0.9 ? chars[Math.floor(Math.random() * chars.length)] : c
                        ).join('');
                    }, 100);
                </script>
            </div>
        </body></html>
    """)
            
            # 3. 1000ms (1 second) delay to allow Disk I/O to settle on Kali 
            # and ensure the HTML file is fully accessible by the browser engine.
            QTimer.singleShot(1000, lambda: self.viz_dashboard.setUrl(QUrl.fromLocalFile(graph_path)))
        # ----------------------------
        
        self.refresh_history_table()
        self.refresh_export_list()

    def populate_results(self, data):
        self.results_table.setRowCount(len(data))
        port_counts = {}
        geo_points = [] # Collect coordinates for the map

        for row, (sub, info) in enumerate(data.items()):
            self.results_table.setItem(row, 0, QTableWidgetItem(sub))
            
            # Injecting Net Type into IP column
            ip_display = f"{info['ip']} ({info.get('type', 'Unknown')})"
            self.results_table.setItem(row, 1, QTableWidgetItem(ip_display))
            self.results_table.setItem(row, 2, QTableWidgetItem(info['os']))
            
            srv_str = "\n".join([f"P{p}: {b}" for p, b in info['services'].items()])
            self.results_table.setItem(row, 3, QTableWidgetItem(srv_str))
            self.results_table.setItem(row, 4, QTableWidgetItem(info['waf']))
            self.results_table.setItem(row, 5, QTableWidgetItem(", ".join(info['vulns'])))
            
            sec_item = QTableWidgetItem(str(info['js_secrets']))
            if info['js_secrets'] > 0: sec_item.setForeground(Qt.GlobalColor.red)
            self.results_table.setItem(row, 6, sec_item)
            
            self.results_table.setItem(row, 7, QTableWidgetItem(os.path.basename(info['screenshot']) if info['screenshot'] != 'Failed' else 'Failed'))
            
            # Count ports for the bar chart
            for p in info['services'].keys(): 
                port_counts[p] = port_counts.get(p, 0) + 1
            
            # --- GEO-OSINT COLLECTION ---
            # Assuming your worker now fetches lat/lon from an API like ip-api.com
            if info.get('lat') and info.get('lon'):
                geo_points.append({
                    'lat': info['lat'], 
                    'lon': info['lon'], 
                    'host': sub, 
                    'ip': info.get('ip', 'Unknown'),
                    'city': info.get('city', 'Unknown'),
                    'country': info.get('country', 'Unknown')
                })

        # Trigger the unified Data & Map visualization
        self.generate_data_viz(port_counts, geo_points)

    def generate_data_viz(self, port_counts, geo_points):
        # 1. Generate the Bar Chart HTML
        chart_html = ""
        if port_counts:
            max_count = max(port_counts.values())
            for port, count in sorted(port_counts.items(), key=lambda item: item[1], reverse=True):
                width = max(10, int((count / max_count) * 100))
                chart_html += f"""
                <div style='margin-bottom:10px;'>
                    <div style='color:#00ff00; font-size:12px;'>PORT {port} ({count} Hosts)</div>
                    <div style='background-color:#003300; border:1px solid #00ff00; height:12px; width:{width}%; border-radius:2px;'></div>
                </div>"""

        # 2. Generate the Leaflet Marker JS
        markers_js = ""
        for p in geo_points:
            markers_js += f"""
    L.circleMarker([{p['lat']}, {p['lon']}], {{
        radius: 6,
        fillColor: "#00ff00",
        color: "#050508",
        weight: 1,
        opacity: 1,
        fillOpacity: 0.8
    }}).addTo(map).bindPopup(`<b style="color:#000;">IP: {p.get("ip", "Unknown")}</b><br><span style="color:#333;">Host: {p["host"]}<br>{p["city"]}, {p["country"]}</span>`);
"""

        # 3. Final Combined Command Center HTML
        full_html = f"""
        <html>
        <head>
            <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
            <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
            <style>
                body {{ background-color: #050508; color: #00ff00; font-family: 'Consolas', monospace; margin: 0; display: flex; overflow: hidden; }}
                #sidebar {{ width: 30%; padding: 15px; border-right: 1px solid #1a5e20; overflow-y: auto; height: 100vh; box-sizing: border-box; }}
                #map-container {{ width: 70%; height: 100vh; position: relative; }}
                #map {{ height: 100%; width: 100%; background-color: #050508; }}
                h2 {{ font-size: 16px; border-bottom: 1px solid #1a5e20; padding-bottom: 5px; text-transform: uppercase; }}
            </style>
        </head>
        <body>
            <div id="sidebar">
                <h2>Port Distribution</h2>
                {chart_html if chart_html else "<p>No active services found.</p>"}
                <h2 style='margin-top:30px;'>Infrastructure OSINT</h2>
                <p style='font-size:12px; color:#888;'>Total Mapped Assets: {len(geo_points)}</p>
            </div>
            <div id="map-container">
                <div id="map"></div>
            </div>
            <script>
                // --- FIX: Wait for Leaflet to download before drawing the map ---
                window.onload = function() {{
                    // Define the physical limits of the Earth
                    var bounds = L.latLngBounds(L.latLng(-90, -180), L.latLng(90, 180));
                    
                    // Initialize the map with strict boundary locks
                    var map = L.map('map', {{
                        maxBounds: bounds,
                        maxBoundsViscosity: 1.0, // Solid walls, no bouncing
                        minZoom: 2 // Prevents zooming out into the grey void
                    }}).setView([20, 0], 2);
                    
                    L.tileLayer('https://{{s}}.basemaps.cartocdn.com/dark_all/{{z}}/{{x}}/{{y}}{{r}}.png', {{
                        attribution: '&copy; CARTO',
                        maxZoom: 19,
                        noWrap: true // Disables the infinite horizontal looping
                    }}).addTo(map);
                    
                    {markers_js}
                }};
            </script>
        </body>
        </html>
        """
        self.map_dashboard.setHtml(full_html)
        
    def generate_hacker_map(self, geo_points):
        """Generates a Dark-Mode Leaflet map for Global Infrastructure OSINT."""
        markers_js = ""
        for p in geo_points:
            # We use a custom green icon for the hacker aesthetic
            markers_js += f"""
            L.circleMarker([{p['lat']}, {p['lon']}], {{
                radius: 8,
                fillColor: "#00ff00",
                color: "#000",
                weight: 1,
                opacity: 1,
                fillOpacity: 0.8
            }}).addTo(map).bindPopup(`<b style="color:#000;">{p['host']}</b><br><span style="color:#333;">{p['city']}, {p['country']}</span>`);
            """

        html = f"""
        <html>
        <head>
            <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
            <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
            <style>
                body {{ margin: 0; padding: 0; background: #050508; }}
                #map {{ height: 100vh; width: 100vw; filter: invert(100%) hue-rotate(180deg) brightness(95%) contrast(90%); }}
                .leaflet-popup-content-wrapper {{ background: #00ff00; color: #000; font-family: monospace; border-radius: 0; }}
            </style>
        </head>
        <body>
            <div id="map"></div>
            <script>
                var map = L.map('map').setView([20, 0], 2);
                L.tileLayer('https://{{s}}.tile.openstreetmap.org/{{z}}/{{x}}/{{y}}.png').addTo(map);
                {markers_js}
            </script>
        </body>
        </html>
        """
        self.map_dashboard.setHtml(html)

    def process_attack_vectors(self):
        """Logic Engine: Identifies critical 'Attack Paths' for the final report."""
        # --- THE FIX: Point to current_scan_data instead of the worker ---
        if not getattr(self, 'current_scan_data', None):
            return "No data available for vector analysis."
        
        vectors = []
        for host, info in self.current_scan_data.items():
            ports = info.get('services', {}).keys()
            vulns = info.get('vulns', [])
            
            # Scenario: Unprotected management ports
            if any(p in [22, 3389, 445] for p in ports):
                vectors.append(f"[!] PATH: {host} -> Management Port Exposure (Potential Lateral Movement)")
            
            # Scenario: Secret Leak + No WAF
            if info.get('js_secrets', 0) > 0 and info.get('waf') == "None Detected":
                vectors.append(f"[!] PATH: {host} -> JS Secret Leak -> Unfiltered Access (High Exploitability)")
                
            # Scenario: Known CVE + Public IP
            if vulns and info.get('type') == 'Public':
                vectors.append(f"[CRITICAL] PATH: {host} -> {vulns[0]} -> Remote Code Execution (RCE)")
        
        return "\n".join(vectors) if vectors else "No high-risk attack paths identified."

    def show_attack_path_alert(self):
        """Displays a summary of discovered attack paths in the log."""
        results = self.process_attack_vectors()
        self.fancy_log("[CRITICAL] --- ATTACK VECTOR ENGINE RESULTS ---")
        self.fancy_log(results)
        self.fancy_log("-----------------------------------------------")
        
    def calculate_workspace_risk(self, data):
        score = 0
        for sub, info in data.items():
            if info.get('type') == 'Public': score += 2
            if info.get('waf') == 'None Detected': score += 8
            mgmt_ports = [21, 22, 23, 445, 3389]
            if any(p in info.get('services', {}) for p in mgmt_ports): score += 20
            if info.get('vulns'): score += 25 
            if info.get('js_secrets', 0) > 0: score += (info.get('js_secrets', 0) * 5)
        return min(100, score)    
        
    # --- ADD THESE INSIDE THE ReconProGUI CLASS ---

    def update_risk_ui(self, score):
        """Updates the top banner risk meter based on scan results."""
        self.current_risk_score = score
        self.risk_meter.setValue(score)
        if score < 30:
            self.risk_label.setText("RISK LEVEL: LOW (Secured)")
            self.risk_label.setStyleSheet("color: #00ff00;")
        elif score < 70:
            self.risk_label.setText("RISK LEVEL: ELEVATED (Vulnerable)")
            self.risk_label.setStyleSheet("color: #ffff00;")
        else:
            self.risk_label.setText("RISK LEVEL: CRITICAL (Exploitable)")
            self.risk_label.setStyleSheet("color: #ff0000;")

    def get_tactical_briefing(self):
        """
        Analyzes current scan data, Risk Score, and Geo-OSINT to generate 
        a high-level Red Team strategy via the local AI engine.
        """
        # --- FIXED: Now uses global state so it works on loaded historical scans too! ---
        if not getattr(self, 'current_scan_data', None):
            QMessageBox.warning(self, "No Data", "Please run a scan or restore a historical scan from the Export tab first.")
            return

        # 1. Collect the current Risk Meter value for the AI
        current_risk = getattr(self, 'current_risk_score', self.risk_meter.value())
        
        # 2. Build a highly detailed infrastructure summary
        summary = ""
        for host, info in self.current_scan_data.items():
            summary += (
                f"- Host: {host} | "
                f"IP: {info['ip']} | "
                f"Loc: {info.get('city', 'Unknown')}, {info.get('country', 'Unknown')} | "
                f"WAF: {info['waf']} | "
                f"Ports: {list(info['services'].keys())} | "
                f"Vulns: {info['vulns']}\n"
            )

        # 3. Construct the 'Master Prompt' with high-level mission objectives
        prompt = f"""
        [MISSION BRIEFING: OFFENSIVE CYBER OPERATIONS]
        
        SYSTEM CONTEXT:
        The ALI RAZA RECON FRAMEWORK has assigned a THREAT LOAD of {current_risk}% to this workspace.
        
        INFRASTRUCTURE DATA:
        {summary}
        
        COMMANDER'S INTENT:
        1. Identify the 'Crown Jewel' (The host most likely to grant internal network access).
        2. Analyze the Geo-location context—are any targets in sensitive jurisdictions?
        3. Provide exact CLI strings (Nmap, Metasploit, or Curl) to verify the vulnerabilities.
        4. Draft a 3-step 'Attack Path' to achieve initial foothold.
        
        RESPONSE FORMAT:
        Keep it professional, technical, and formatted for a high-level security audit report. Do not use emojis.
        """

        # 4. Use the modular helper to fire the prompt
        self.ai_input.setText("CONSULTING TACTICAL ADVISOR...")
        self.is_briefing_mode = True  # <--- NEW: Tells the worker to auto-save this response for the PDF
        self.ask_ai_with_prompt(prompt)
        
    def ask_ai_with_prompt(self, prompt):
        """Helper method to fire a pre-defined prompt at the AI worker."""
        model_choice = self.ai_model_dropdown.currentText()
        aws_bedrock_key = self.aws_bedrock_input.text().strip()
        
        self.ai_chat.append(f"<br><b style='color:#ffff00;'>[*] ANALYZING INFRASTRUCTURE VIA: {model_choice.split(':')[0].upper()}...</b>")
        self.ai_send_btn.setEnabled(False)
        
        # Initialize the background worker with the custom prompt & keys
        self.ai_thread = AIWorker(prompt, model_choice, aws_bedrock_key)
        
        # Connect signals for output and error handling
        self.ai_thread.response_signal.connect(self.handle_ai_response)
        self.ai_thread.error_signal.connect(self.handle_ai_error)
        
        # Re-enable the button once the AI finishes its thinking cycle
        self.ai_thread.finished.connect(lambda: self.ai_send_btn.setEnabled(True))
        
        self.ai_thread.start()

    def clear_dashboard_data(self):
        """Wipes the active session data from the dashboard grids and maps."""
        reply = QMessageBox.question(self, 'Clear Dashboard', 'Clear all active data grids and visualizers? (This does not delete saved reports).', QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            self.results_table.setRowCount(0)
            self.progress_bar.setValue(0)
            self.viz_dashboard.setHtml("<html><body style='background-color:#050508; color:#00FF41; display:flex; justify-content:center; align-items:center; height:100vh;'><h2 style='font-family:monospace;'>[AWAITING RECON DATA FOR GRAPH GENERATION...]</h2></body></html>")
            self.map_dashboard.setHtml("<html><body style='background-color:#050508; color:#00FF41; display:flex; justify-content:center; align-items:center; height:100vh;'><h2 style='font-family:monospace;'>[AWAITING GEO-OSINT DATA FOR GLOBAL MAP...]</h2></body></html>")
            
            # --- THE ANT FIX: Wipe the backend memory so the AI doesn't hallucinate ---
            self.current_scan_data = None
            self.current_scan_dir = None
            self.update_risk_ui(0)
            
    def delete_selected_report(self):
        """Permanently deletes one or multiple selected scan report directories."""
        selected_items = self.export_list.selectedItems()
        
        if not selected_items:
            QMessageBox.warning(self, "Selection Required", "Please select one or more report directories to delete.")
            return

        reply = QMessageBox.question(self, 'Confirm Bulk Deletion', f'Are you sure you want to permanently delete {len(selected_items)} report(s) and all their contents?', QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        
        if reply == QMessageBox.StandardButton.Yes:
            import shutil
            errors = []
            deleted_count = 0
            
            for selected in selected_items:
                scan_name = selected.text().split("] ")[-1]
                proj_name = selected.text().split("] ")[0].replace("[", "")
                target_dir = os.path.join("Scan_Results", proj_name, scan_name)
                
                # Delete from SQLite DB
                try:
                    with db.lock:
                        db.cursor.execute("DELETE FROM assets WHERE scan_id=?", (scan_name,))
                        db.cursor.execute("DELETE FROM tool_outputs WHERE scan_id=?", (scan_name,))
                        db.cursor.execute("DELETE FROM scans WHERE scan_id=?", (scan_name,))
                        db.conn.commit()
                except Exception as e:
                    errors.append(f"DB Error {scan_name}: {str(e)}")

                if os.path.exists(target_dir):
                    try:
                        shutil.rmtree(target_dir)
                        deleted_count += 1
                    except Exception as e:
                        errors.append(f"{scan_name}: {str(e)}")
                else:
                    deleted_count += 1 # Count it as deleted if it only existed in DB
            
            self.refresh_export_list()
            
            if errors:
                QMessageBox.critical(self, "Deletion Errors", "Some directories could not be deleted:\n\n" + "\n".join(errors))
            else:
                self.fancy_log(f"[INFO] Successfully deleted {deleted_count} scan directory(s).")
                
    def panic_purge(self):
        reply = QMessageBox.critical(self, '🚨 PANIC BUTTON 🚨', 'EMERGENCY PURGE INITIATED.\n\nThis will kill all active scans and aggressively delete the current working directories. Proceed?', QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            self.fancy_log("<h2 style='color:#ff0000;'>[CRITICAL] EMERGENCY PURGE EXECUTED!</h2>")
            
            # 1. Kill Main GUI Threads
            workers_to_kill = [
                getattr(self, 'worker', None),
                getattr(self, 'ai_thread', None),
                getattr(self, 'spider_thread', None)
            ]
            for w in workers_to_kill:
                if w and w.isRunning():
                    if hasattr(w, 'stop'): w.stop()
                    w.wait(1000)

            # 2. --- THE ANT FIX: Kill Sub-Tab Threads ---
            for child in self.findChildren(QWidget):
                if hasattr(child, 'worker') and child.worker and isinstance(child.worker, QThread) and child.worker.isRunning():
                    if hasattr(child.worker, 'stop'): child.worker.stop()
                    child.worker.wait(1000)
                if hasattr(child, 'active_workers'):
                    for w in child.active_workers:
                        if w and w.isRunning():
                            if hasattr(w, 'stop'): w.stop()
                            w.wait(1000)

            # 3. Wipe the hard drive artifacts
            try:
                project = self.config.get("project_name", "Default_Workspace")
                proj_dir = os.path.join("Scan_Results", project)
                if os.path.exists(proj_dir):
                    subdirs = sorted([os.path.join(proj_dir, d) for d in os.listdir(proj_dir)], key=os.path.getmtime)
                    if subdirs:
                        shutil.rmtree(subdirs[-1])
                        self.fancy_log(f"[-] Wiped directory: {subdirs[-1]}")
            except Exception as e:
                self.fancy_log(f"[!] Purge Error: {e}")
                
            self.results_table.setRowCount(0)
            self.viz_dashboard.setHtml("")
            self.map_dashboard.setHtml("")
            self.progress_bar.setValue(0)

    def run_health_check(self):
        """Audits the OS environment for all 23 binaries in the ARF Arsenal."""
        core_tools = [
            "nmap", "subfinder", "assetfinder", "amass", "dnsx", "tlsx", 
            "naabu", "httpx", "nuclei", "whatweb", "wafw00f", "ffuf", 
            "wfuzz", "katana", "gau", "cloud_enum", "dig", "nslookup", 
            "holehe", "theHarvester", "whois", "nikto", "searchsploit"
        ]
        
        # Tactical HTML styling for the diagnostic window
        msg = """
        <div style='font-family:Consolas, monospace;'>
            <h3 style='color:#00ff00; border-bottom: 1px solid #1a5e20;'>ARF ARSENAL DIAGNOSTICS</h3>
            <table width='100%'>
        """
        
        all_clear = True
        # We sort alphabetically so the list is easy to read
        for tool in sorted(core_tools):
            path = shutil.which(tool)
            if path:
                msg += f"<tr><td><span style='color:#00ff00;'>[✔]</span> <b>{tool}</b></td><td style='color:#555; font-size:10px;'>{path[:30]}...</td></tr>"
            else:
                msg += f"<tr><td><span style='color:#ff0000;'>[✘]</span> <b style='color:#ff0000;'>{tool}</b></td><td style='color:#aa0000;'>NOT FOUND</td></tr>"
                all_clear = False
        
        msg += "</table><br><hr>"
        
        if all_clear:
            msg += "<b style='color:#00ff00;'>SUMMARY: ALL SYSTEMS GO. Arsenal is fully weaponized.</b>"
        else:
            msg += "<b style='color:#ff0000;'>SUMMARY: DEPENDENCY GAP DETECTED. Run Auto-Installer to fix.</b>"
        
        msg += "</div>"
        
        QMessageBox.information(self, "Pre-Flight Diagnostics", msg)

    def generate_spider_wordlist(self):
        target = self.target_input.text().strip().split(',')[0]
        clean_target = re.sub(r'^https?://', '', target).split('/')[0]
        if not clean_target:
            QMessageBox.warning(self, "Error", "Enter a target first.")
            return

        # Grab the active workspace name
        current_ws = self.config.get("project_name", "Default_Workspace")
        
        # --- THE FIX: Pop up the log window instantly ---
        self.force_focus_live_log()
        
        self.fancy_log(f"[*] STARTING SPIDER: {clean_target} (Workspace: {current_ws})")
        
        # Pass both target and workspace name to the worker
        self.spider_thread = SpiderWorker(clean_target, current_ws)
        
        self.spider_thread.log_signal.connect(self.fancy_log)
        self.spider_thread.error_signal.connect(lambda msg: self.fancy_log(f"<span style='color:#ff0000;'>{msg}</span>"))
        self.spider_thread.finished_signal.connect(self.on_spider_success)
        
        self.spider_thread.start()

    def on_spider_success(self, full_path, count):
        """Now receives the full optimized path."""
        # Convert to absolute path so tools can find it regardless of execution context
        abs_path = os.path.abspath(full_path)
        
        self.wordlist_input.setText(abs_path)
        self.fancy_log(f"<b style='color:#00ff00;'>[✔] SUCCESS: {count} words saved.</b>")
        self.fancy_log(f"[+] Repository: {full_path}")

    def load_historical_dashboard(self):
        selected_items = self.export_list.selectedItems()
        if not selected_items or len(selected_items) > 1:
            QMessageBox.warning(self, "Warning", "Please select exactly ONE scan directory to restore.")
            return
        scan_name = selected_items[0].text().split("] ")[-1]
        proj_name = selected_items[0].text().split("] ")[0].replace("[", "")
        target_dir = os.path.join("Scan_Results", proj_name, scan_name)
        
        try:
            data = db.get_asset_data(scan_name)
            if not data:
                QMessageBox.warning(self, "Error", "No asset data found in SQLite vault for this report.")
                return
                
            # --- IMPROVEMENT 2: Historical Sync ---
            self.current_scan_data = data
            self.current_scan_dir = target_dir
            risk = self.calculate_workspace_risk(data)
            self.update_risk_ui(risk)
            
            self.populate_results(data)
            self.show_attack_path_alert()
            
            # --- Safely reload graph ---
            graph_path = os.path.abspath(os.path.join(target_dir, "network_graph.html"))
            
            # --- THE DYNAMIC GRAPH FIX ---
            if not os.path.exists(graph_path):
                graph_path = self.generate_pyvis_graph(target_dir, data)
            # -----------------------------
                
            if graph_path and os.path.exists(graph_path):
                self.viz_dashboard.page().profile().clearHttpCache()

            
            if os.path.exists(graph_path):
                self.viz_dashboard.page().profile().clearHttpCache()
                old_page = self.viz_dashboard.page()
                blank_page = QWebEnginePage(self.viz_dashboard)
                self.viz_dashboard.setPage(blank_page)
                try:
                    old_page.deleteLater() 
                except RuntimeError:
                    pass  # Qt already garbage collected the C++ object!
                    
                self.viz_dashboard.setHtml("<html><body style='background-color:#050508; color:#00ff00;'><h2 style='text-align:center; margin-top:20%;'>[ RELOADING HISTORICAL TOPOLOGY... ]</h2></body></html>")
                QTimer.singleShot(1000, lambda: self.viz_dashboard.setUrl(QUrl.fromLocalFile(graph_path)))
            
            # Auto-open the secondary window to the Data & Viz tab
            items = self.sidebar.findItems("[📊] Data & Viz", Qt.MatchFlag.MatchExactly)
            if items:
                self.open_tool_window(items[0])
                self.results_tab.setCurrentIndex(0)  # <--- THE FIX: Forces focus to the Data Grid!
                
            self.fancy_log(f"[INFO] Successfully restored {scan_name} to the Dashboard.")
        except Exception as e:
            QMessageBox.critical(self, "Restore Error", str(e))
    
    def closeEvent(self, event):
        """
        Overwrites the default close behavior to ensure ALL nested 
        background worker threads are explicitly hunted down and terminated.
        """
        self.fancy_log("[!] Initiating aggressive thread shutdown...")
        
        # 1. Kill direct workers attached to the Main GUI
        workers_to_kill = [
            getattr(self, 'worker', None),
            getattr(self, 'ai_thread', None),
            getattr(self, 'spider_thread', None),
            getattr(self, 'man_worker', None)
        ]

        for w in workers_to_kill:
            if w and w.isRunning():
                if hasattr(w, 'stop'): w.stop()
                w.quit()
                w.wait(2000)

        # 2. --- THE ANT FIX: Recursively hunt down workers hidden inside sub-tabs ---
        for child in self.findChildren(QWidget):
            # Target standard single workers (AutoScan, UniversalTool, Install)
            if hasattr(child, 'worker') and child.worker and isinstance(child.worker, QThread) and child.worker.isRunning():
                if hasattr(child.worker, 'stop'): child.worker.stop()
                child.worker.quit()
                child.worker.wait(2000)
            
            # Target arrays of concurrent workers (SystemCommandsTab)
            if hasattr(child, 'active_workers'):
                for w in child.active_workers:
                    if w and w.isRunning():
                        if hasattr(w, 'stop'): w.stop()
                        w.quit()
                        w.wait(2000)

        # 3. Ensure the secondary tool window is destroyed to free RAM
        if hasattr(self, 'secondary_window') and self.secondary_window:
            self.secondary_window.close()
            self.secondary_window.deleteLater()

        event.accept()
        
    def show_arf_docs(self):
        """Automatically navigates to the Manuals tab and displays the ARF Master Guide."""
        # 1. Ensure we can find the Manuals tab
        target_name = "[📚] Tool Manuals"
        if target_name not in self.modules_dict:
            return

        cat_idx, tool_idx = self.modules_dict[target_name]

        # 2. Open and focus the Hub Window
        self.secondary_window.show()
        self.category_tabs.setCurrentIndex(cat_idx)
        self.cat_widgets[cat_idx].setCurrentIndex(tool_idx)
        self.secondary_window.raise_()
        self.secondary_window.activateWindow()

        # 3. Inject the Master Documentation (Updated for v1.0 Master Build)
        doc_html = """
        <h2 style='color:#00ff00; border-bottom: 1px solid #1a5e20; padding-bottom: 5px; margin-top: 0;'>ARF v1.0 - MASTER TACTICAL GUIDE</h2>
        <p style='color:#888888; font-size: 12px;'>Complete index of the 16 core weaponized features and their operational parameters.</p>
        
        <b style='color:#00ffff;'>[1] 🤖 HYBRID NEURAL ENGINE (LOCAL + CLOUD)</b>
        <p style='color:#cccccc; margin-top: 2px; margin-bottom: 12px;'>Toggle between the offline <i>Qwen2.5-Coder</i> model or connect to Enterprise Cloud AI via an <b>AWS Bedrock Bearer Token</b> (Anthropic Claude 3.5 Sonnet) for heavy architectural analysis.</p>
        
        <b style='color:#00ffff;'>[2] ⚡ HIGH-CONCURRENCY ASYNC ENGINE</b>
        <p style='color:#cccccc; margin-top: 2px; margin-bottom: 12px;'>The core Python <code>asyncio</code> pipeline rapidly enumerates subdomains, probes ports, and utilizes a self-contained Playwright Chromium browser to securely screenshot targets bypassing invalid SSLs.</p>

        <b style='color:#00ffff;'>[3] 🕸️ INTERACTIVE PYVIS TOPOLOGY</b>
        <p style='color:#cccccc; margin-top: 2px; margin-bottom: 12px;'>Auto-generates dynamic, physics-based network graphs illustrating the relationships between targets, IPs, and open ports.</p>
        
        <b style='color:#00ffff;'>[4] 🗺️ GLOBAL GEO-OSINT MAPPING</b>
        <p style='color:#cccccc; margin-top: 2px; margin-bottom: 12px;'>Plots discovered infrastructure on a Dark-Mode CartoDB Leaflet map to visually identify physical server locations globally.</p>

        <b style='color:#00ffff;'>[5] 📄 EXECUTIVE PDF REPORTING</b>
        <p style='color:#cccccc; margin-top: 2px; margin-bottom: 12px;'>Compiles all vulnerabilities, threat intelligence APIs (Censys, GreyNoise, VT), AI briefings, and screenshots into a C-suite ready PDF audit.</p>

        <b style='color:#00ffff;'>[6] 📻 TACTICAL WIRELESS SUITE</b>
        <p style='color:#cccccc; margin-top: 2px; margin-bottom: 12px;'>Interfaces with monitor-mode adapters to orchestrate <code>airodump-ng</code>, <code>wifite</code>, and <code>wash</code> in detached terminal sessions.</p>

        <b style='color:#00ffff;'>[7] ⚖️ REAL-TIME RISK METER</b>
        <p style='color:#cccccc; margin-top: 2px; margin-bottom: 12px;'>Dynamically quantifies workspace threat load (0-100%) based on WAF presence, critical CVEs, and exposed management ports.</p>

        <b style='color:#00ffff;'>[8] 🗂️ GLOBAL WORKSPACE ISOLATION</b>
        <p style='color:#cccccc; margin-top: 2px; margin-bottom: 12px;'>Regardless of installation path, all databases, screenshots, and PDFs are permanently and safely sandboxed in your <b>~/ARF_Workspace/</b> directory.</p>

        <b style='color:#00ffff;'>[9] 🕷️ CUSTOM WORDLIST SPIDERING</b>
        <p style='color:#cccccc; margin-top: 2px; margin-bottom: 12px;'>Crawls target URLs to build highly contextual, tailored dictionary files for advanced fuzzing and brute-forcing.</p>

        <b style='color:#00ffff;'>[10] 🕵️ DETACHED BASH KILL-CHAINS</b>
        <p style='color:#cccccc; margin-top: 2px; margin-bottom: 12px;'>Merges passive OSINT APIs with aggressive active probing by spawning detached, parallel OS terminals (Domain & IP Auto-Scans).</p>

        <b style='color:#00ffff;'>[11] 🔄 VISUAL SURFACE DIFFING</b>
        <p style='color:#cccccc; margin-top: 2px; margin-bottom: 12px;'>Compares historical baseline scans against current data to instantly highlight newly opened ports or discovered subdomains.</p>

        <b style='color:#00ffff;'>[12] 🛠️ NATIVE DEBIAN DEPLOYMENT</b>
        <p style='color:#cccccc; margin-top: 2px; margin-bottom: 12px;'>ARF is deployed as a system-wide <code>.deb</code> package, utilizing a self-contained virtual environment in <b>/opt/arf</b> to guarantee execution without dependency conflicts.</p>

        <b style='color:#00ffff;'>[13] 📉 SYSTEM HARDWARE TELEMETRY</b>
        <p style='color:#cccccc; margin-top: 2px; margin-bottom: 12px;'>Live performance tracking of CPU, RAM, Network I/O, and heavy processes to prevent OS lockups during aggressive scans.</p>

        <b style='color:#00ffff;'>[14] 🚨 EMERGENCY PANIC PURGE</b>
        <p style='color:#cccccc; margin-top: 2px; margin-bottom: 12px;'>A global kill-switch (<code>Ctrl+Shift+K</code>) that instantly orphans processes and wipes current working directories of sensitive artifacts.</p>

        <b style='color:#00ffff;'>[15] 💻 INTERACTIVE HEADLESS CLI</b>
        <p style='color:#cccccc; margin-top: 2px; margin-bottom: 12px;'>A fully decoupled, Metasploit-style terminal interface for remote VPS execution without requiring X11 or a desktop environment.</p>

        <b style='color:#00ffff;'>[16] 🗄️ UNIFIED SQLITE VAULT AUDITING</b>
        <p style='color:#cccccc; margin-top: 2px; margin-bottom: 12px;'>A centralized SQLite backend that automatically logs metadata, execution modes (GUI vs CLI), and tool outputs for perfect persistence across updates.</p>
        
        <hr style='border: 1px solid #1a5e20;'>
        <i style='color:#888888;'>PRO TIP: Offline manuals for native binaries (nmap, nuclei, subfinder) can be fetched by typing their name in the search box above.</i>
        """
        self.manual_output.setHtml(doc_html)

    def generate_pyvis_graph(self, target_dir, data):
        """Dynamically builds a physics-based PyVis graph if a scan is missing it."""
        try:
            from pyvis.network import Network
            net = Network(height="100vh", width="100%", bgcolor="#050508", font_color="#00ff00")
            net.barnes_hut(gravity=-8000, central_gravity=0.3, spring_length=150)
            
            root_node = os.path.basename(target_dir).replace("AutoScanDomain_", "").replace("AutoScanIP_", "")
            net.add_node("ROOT", label=root_node, color="#ff0000", shape="diamond", size=30)
            
            for sub, info in data.items():
                net.add_node(sub, label=sub, color="#00ff00", shape="dot", size=20)
                net.add_edge("ROOT", sub, color="#1a5e20")
                
                ip = info.get("ip", "Unknown")
                if ip and ip != "Unknown":
                    ip_id = f"IP_{ip}"
                    net.add_node(ip_id, label=ip, color="#00aaff", shape="box", size=15)
                    net.add_edge(sub, ip_id, color="#1a5e20")
                    
                    for port in info.get("services", {}).keys():
                        p_node = f"{ip}:{port}"
                        net.add_node(p_node, label=f"Port {port}", color="#ffff00", size=10)
                        net.add_edge(ip_id, p_node, color="#1a5e20")
                        
            graph_path = os.path.join(target_dir, "network_graph.html")
            net.save_graph(graph_path)
            return graph_path
        except Exception as e:
            self.fancy_log(f"[ERROR] Auto-Graph generation failed: {e}")
            return None    
