import os
from PyQt6.QtWidgets import QMainWindow, QTabWidget, QApplication, QInputDialog
from PyQt6.QtGui import QIcon, QAction
from gui.main_window import ReconProGUI

# ===================================================
# --- MASTER HUB CONTAINER (TAB MANAGER) ---
# ===================================================
class MasterHub(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ALI RAZA Recon Framework - Master Command Hub")
        
        # 1. Smart Initial Sizing & Centering
        screen = QApplication.primaryScreen()
        w, h = screen.geometry().width(), screen.geometry().height()
        self.setMinimumSize(900, 700)
        self.resize(int(w * 0.85), int(h * 0.85))
        frame_geo = self.frameGeometry()
        frame_geo.moveCenter(screen.availableGeometry().center())
        self.move(frame_geo.topLeft())

        # 2. Icon Setup
        icon_path = "icon.png" if os.path.exists("icon.png") else "icon.svg" if os.path.exists("icon.svg") else ""
        if icon_path: self.setWindowIcon(QIcon(icon_path))
        
        # 3. Tab System Design
        self.tabs = QTabWidget()
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.tabs.tabBarDoubleClicked.connect(self.rename_tab)
        self.total_tabs_created = 0 
        self.tabs.setStyleSheet("""
            QTabWidget::pane { border: 2px solid #1a5e20; background: #050508; }
            QTabBar::tab { background: #0a0a0c; color: #1a5e20; padding: 12px 25px; border: 1px solid #1a5e20; font-family: 'Consolas'; font-weight: bold; font-size: 14px; }
            QTabBar::tab:selected { background: #00FF41; color: #000000; }
        """)
        self.setCentralWidget(self.tabs)

        # 4. Global Hotkey Setup (The "Ctrl+T" Listener)
        # We define this ONCE here so it doesn't duplicate every time a tab opens.
        self.new_tab_shortcut = QAction(self)
        self.new_tab_shortcut.setShortcut("Ctrl+T")
        self.new_tab_shortcut.triggered.connect(self.add_workspace)
        self.addAction(self.new_tab_shortcut)
        
        # 5. Launch first workspace
        self.add_workspace()

    def add_workspace(self):
        workspace = ReconProGUI()
        workspace.master_hub_add_tab = self.add_workspace 
        
        self.total_tabs_created += 1
        index = self.tabs.addTab(workspace, f"Tab {self.total_tabs_created}")
        self.tabs.setCurrentIndex(index)
        
        # Ensure scaling happens after parenting
        workspace.setup_display_scaling()

    def close_tab(self, index):
        if self.tabs.count() > 1:
            widget = self.tabs.widget(index)
            widget.close()
            self.tabs.removeTab(index)
            # Auto-renumbering removed here so custom tab names are preserved!
        else:
            self.close()

    def rename_tab(self, index):
        """Prompts the user to rename a tab upon double-clicking."""
        current_name = self.tabs.tabText(index)
        new_name, ok = QInputDialog.getText(self, "Rename Tab", "Enter new tab name:", text=current_name)
        if ok and new_name.strip():
            self.tabs.setTabText(index, new_name.strip())  
            
    def closeEvent(self, event):
        """Forces all child tabs to trigger their cleanup sequences before the main app exits."""
        for i in range(self.tabs.count()):
            widget = self.tabs.widget(i)
            if widget:
                widget.close()
        event.accept()