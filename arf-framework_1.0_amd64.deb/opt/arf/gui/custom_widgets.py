from PyQt6.QtWidgets import QTabBar, QStylePainter, QStyleOptionTab, QStyle
from PyQt6.QtCore import QSize

class SideTabBar(QTabBar):
    def tabSizeHint(self, index):
        # Base size for all tabs: 240px wide, 80px tall (45px button + 15px gap)
        size = QSize(240, 80)    
        return size

    def paintEvent(self, event):
        painter = QStylePainter(self)
        opt = QStyleOptionTab()
        for i in range(self.count()):
            # --- THE FIX: Only paint the tab if it is actually visible ---
            if not self.isTabVisible(i):
                continue 
                
            self.initStyleOption(opt, i)
            opt.shape = QTabBar.Shape.RoundedNorth 
            painter.drawControl(QStyle.ControlElement.CE_TabBarTabShape, opt)
            painter.drawControl(QStyle.ControlElement.CE_TabBarTabLabel, opt)