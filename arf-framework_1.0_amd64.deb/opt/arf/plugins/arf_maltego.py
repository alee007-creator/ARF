import sys
import os
import sqlite3
from maltego_trx.maltego import MaltegoTransform

# Maltego Entity Constants
DNSName = "maltego.DNSName"
IPv4Address = "maltego.IPv4Address"

def execute_transform():
    # 1. Initialize the XML payload constructor
    response = MaltegoTransform()
    
    # 2. Safely snatch the domain name, ignoring Maltego's buggy extra arguments
    if len(sys.argv) < 2:
        response.addUIMessage("Error: No domain was passed to the script.")
        print(response.returnOutput())
        return
        
    target_domain = sys.argv[1]
    
    try:
        # 3. Safely locate your ARF Vault Database automatically (ADJUSTED PATH)
        script_dir = os.path.dirname(os.path.abspath(__file__))
        root_dir = os.path.abspath(os.path.join(script_dir, "..")) # <--- Tells it to look one folder up!
        db_path = os.path.join(root_dir, "arf_vault.db")
        
        if not os.path.exists(db_path):
            response.addUIMessage(f"Database missing: Cannot find {db_path}")
            print(response.returnOutput())
            return

        # 4. Extract data from the Vault
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Find the most recent scan for this domain in your database
        cursor.execute("SELECT scan_id FROM scans WHERE target LIKE ? ORDER BY timestamp DESC LIMIT 1", (f"%{target_domain}%",))
        row = cursor.fetchone()
        
        if not row:
            response.addUIMessage(f"No historical ARF scan data found in vault for: {target_domain}")
            print(response.returnOutput())
            return
            
        scan_id = row[0]
        
        # Pull all discovered assets tied to that scan
        cursor.execute("SELECT subdomain, ip, os, waf FROM assets WHERE scan_id=?", (scan_id,))
        assets = cursor.fetchall()
        conn.close()
        
        # 5. Push entities to the graph
        for sub, ip, os_val, waf in assets:
            ent = response.addEntity(DNSName, sub)
            ent.addProperty("waf", "WAF", "loose", str(waf))
            ent.addProperty("os", "OS", "loose", str(os_val))
            
            # If we found an IP, link it to the graph too!
            if ip and ip != "Unknown":
                ip_ent = response.addEntity(IPv4Address, ip)
                ip_ent.addProperty("subdomain", "From Subdomain", "loose", sub)

    except Exception as e:
        # If anything breaks, print the exact error directly onto the Maltego UI
        response.addUIMessage(f"ARF Extractor Error: {str(e)}")
        
    # 6. Output the raw XML directly to Maltego's rendering engine
    print(response.returnOutput())

if __name__ == "__main__":
    execute_transform()