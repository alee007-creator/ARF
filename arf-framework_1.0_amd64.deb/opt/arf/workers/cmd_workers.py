import subprocess
import queue
import threading
import time
import os
import tempfile
from PyQt6.QtCore import QThread, pyqtSignal
from core.utils import ansi_to_html

# ===================================================
# --- UNIVERSAL SUBPROCESS WORKERS ---
# ===================================================
class ToolWorker(QThread):
    output_signal = pyqtSignal(str)
    error_signal = pyqtSignal(str)
    finished_signal = pyqtSignal()
    
    def __init__(self, command):
        super().__init__()
        self.command = command
        self.process = None
        self.is_running = True
        self.q = queue.Queue()
        
    def stop(self):
        self.is_running = False
        if self.process:
            try: self.process.kill()
            except: pass

    # --- THE FIX: C-Optimized high-speed reader ---
    def read_stream(self, stream):
        try:
            for line in stream:
                if not self.is_running: break
                self.q.put(line)
        except Exception:
            pass

    def run(self):
        try:
            self.process = subprocess.Popen(
                self.command, 
                stdout=subprocess.PIPE, 
                stderr=subprocess.STDOUT, 
                stdin=subprocess.DEVNULL,   # Prevent terminal input hijacking
                start_new_session=True,     # Sandbox process group
                text=True,                  # Auto-handles \r and \n universally!
                shell=False,
                bufsize=1
            )
            
            t = threading.Thread(target=self.read_stream, args=(self.process.stdout,))
            t.daemon = True
            t.start()
            
            last_emit = time.time()
            lines = []
            
            while self.is_running:
                if self.process.poll() is not None and not t.is_alive() and self.q.empty():
                    break
                    
                while not self.q.empty():
                    # --- FIX 1: Use .rstrip() to keep leading spaces intact! ---
                    lines.append(self.q.get_nowait().rstrip('\r\n'))
                    
                if time.time() - last_emit > 0.15:
                    if lines:
                        # --- FIX 2: Join with real newlines, no fake <br> tags ---
                        safe_text = ansi_to_html("\n".join(lines))
                        self.output_signal.emit(safe_text)
                        lines.clear()
                        last_emit = time.time()
                time.sleep(0.01)
                
            if lines:
                safe_text = ansi_to_html("\n".join(lines))
                self.output_signal.emit(safe_text)

        except Exception as e:
            if self.is_running:
                self.error_signal.emit(f"[{self.command[0]}] Execution Error: {str(e)}")
                self.output_signal.emit(f"<span style='color:#ff0000;'>[-] Tool crashed or not installed.</span>")
        finally:
            if self.process:
                try: self.process.stdout.close()
                except: pass
            self.finished_signal.emit()
            
# -------------------------------------------------------------
# --------------------------------------------------            
        
class ManualWorker(QThread):
    output_signal = pyqtSignal(str)
    finished_signal = pyqtSignal()

    def __init__(self, command):
        super().__init__()
        self.command = command

    def run(self):
        try:
            res = subprocess.run(self.command, capture_output=True, text=True, timeout=10)
            output = res.stdout if res.stdout else res.stderr
            if not output and self.command[0] not in ["nslookup", "dig"]: 
                res = subprocess.run(["man", self.command[0]], capture_output=True, text=True, timeout=10)
                output = res.stdout
            self.output_signal.emit(output if output else "[-] No manual output found.")
        except Exception as e:
            self.output_signal.emit(f"[!] Error fetching manual: {str(e)}")
        finally:
            self.finished_signal.emit()

# ===================================================
# --- ENVIRONMENT INSTALLATION WORKER ---
# ===================================================
class InstallWorker(QThread):
    output_signal = pyqtSignal(str)
    finished_signal = pyqtSignal()

    def __init__(self, script_content, sudo_password):
        super().__init__()
        self.script_content = script_content
        self.sudo_password = sudo_password
        
    def stop(self):
        if hasattr(self, 'process') and self.process:
            try: self.process.kill()
            except: pass    

    def run(self):
        fd, temp_path = tempfile.mkstemp(suffix=".sh")
        with os.fdopen(fd, 'w') as f: f.write(self.script_content)
        os.chmod(temp_path, 0o755)

        self.output_signal.emit("[*] Escaping GUI to execute root installation script...\n")
        cmd = ["sudo", "-S", "bash", temp_path]
        try:
            process = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            process.stdin.write(self.sudo_password + '\n')
            process.stdin.flush()
            for line in process.stdout: self.output_signal.emit(line.strip())
            process.stdout.close(); process.wait()
        except Exception as e:
            self.output_signal.emit(f"[-] FATAL SCRIPT ERROR: {str(e)}")
        finally:
            os.remove(temp_path)
            self.finished_signal.emit()            