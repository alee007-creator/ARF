import os, time, datetime, re, asyncio, aiohttp, requests, ipaddress, platform
import dns.asyncresolver
from bs4 import BeautifulSoup
from pyvis.network import Network
from PyQt6.QtCore import QThread, pyqtSignal, QObject
from core.database import db
from core.env import SHODAN_AVAILABLE, PLAYWRIGHT_AVAILABLE

try:
    import shodan
except ImportError:
    pass

try:
    from playwright.async_api import async_playwright
except ImportError:
    pass

# ===================================================
# --- CORE LOGIC WORKER (Multithreaded & Async) ---
# ===================================================
class ScanWorkerSignals(QObject):
    log_signal = pyqtSignal(str)
    progress_signal = pyqtSignal(int)
    results_signal = pyqtSignal(dict, str, str)
    risk_score_signal = pyqtSignal(int)
    finished_signal = pyqtSignal()

class AdvancedReconWorker(QThread):
    def __init__(self, targets, wordlist_path, shodan_key, threads, webhook_url, continuous, interval_mins, project_name, scope_rules, api_keys=None, exec_mode="GUI"):
        super().__init__()
        raw_targets = [t.strip() for t in targets.split(',') if t.strip()]
        self.targets = []
        for t in raw_targets:
            clean = re.sub(r'^https?://', '', t)
            clean = clean.split('/')[0]
            clean = clean.strip().rstrip('.')
            if clean:
                self.targets.append(clean)
        self.wordlist_path = wordlist_path
        self.shodan_key = shodan_key
        self.threads = threads
        self.webhook_url = webhook_url
        self.continuous = continuous
        self.interval_mins = interval_mins
        self.project_name = project_name
        self.scope_rules = [r.strip() for r in scope_rules.split(',') if r.strip()]
        self.signals = ScanWorkerSignals()
        self.is_running = True
        self.discovered_subs = set()
        self.processed_data = {} 
        self.secret_regex = re.compile(r'(?:A3T[A-Z0-9]|AKIA|AGPA|AIDA|AROA|AIPA|ANPA|ANVA|ASIA)[A-Z0-9]{16}|[a-zA-Z0-9]{32,}')
        self.api_keys = api_keys if api_keys else {}
        self.exec_mode = exec_mode # <--- Added
        
        # --- NEW: EXPOSURE METER LOGIC (POINT 5) ---
    def calculate_workspace_risk(self, data):
        """Quantifies the threat level with dynamic severity weighting."""
        score = 0
        for sub, info in data.items():
            # 1. Exposure Baseline
            if info.get('type') == 'Public': 
                score += 2
            
            # 2. Defense Gap (No WAF on a target is a significant multiplier)
            if info.get('waf') == 'None Detected': 
                score += 8
            
            # 3. Critical Entry Points (Management/Legacy Ports)
            mgmt_ports = [21, 22, 23, 445, 3389]
            if any(p in info.get('services', {}) for p in mgmt_ports):
                score += 20 # Bumped from 15 for higher visibility
            
            # 4. Known CVEs (The heaviest hitter)
            if info.get('vulns'): 
                score += 25 
            
            # 5. Information Disclosure (Dynamic Penalty)
            # 5 points per secret found. 4 secrets = 20 points.
            num_secrets = info.get('js_secrets', 0)
            if num_secrets > 0:
                score += (num_secrets * 5)
            
        # Clamp to 0-100% so the UI Progress Bar doesn't break
        return min(100, score)
    # ------------------------------------------

    # NEW: Scope Enforcement Gatekeeper
    def is_in_scope(self, target):
        if not self.scope_rules: return True
        for rule in self.scope_rules:
            if re.search(rule, target, re.IGNORECASE):
                return False
        return True

    def log(self, level, message):
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")
        self.signals.log_signal.emit(f"[{level}] [{timestamp}] {message}")

    def create_output_dirs(self, target_name):
        safe_name = target_name.replace('.', '_').replace(':', '_')
        ts = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        base_dir = f"Scan_Results/{self.project_name}/{safe_name}_LiveRecon_{ts}"
        os.makedirs(f"{base_dir}/screenshots", exist_ok=True)
        return base_dir

    def is_ip(self, address):
        try: ipaddress.ip_address(address); return True
        except ValueError: return False

    async def active_port_scan_and_banner_grab(self, ip):
        top_ports = [21, 22, 25, 80, 110, 143, 443, 445, 3306, 3389, 8080, 8443]
        web_ports = [80, 443, 8080, 8443]
        open_ports_and_banners = {}
        
        for port in top_ports:
            try:
                # 1. Establish the raw TCP connection
                conn = asyncio.open_connection(ip, port)
                reader, writer = await asyncio.wait_for(conn, timeout=1.5)
                
                # 2. Targeted Probing
                if port in web_ports:
                    # Web services need a nudge to reveal their banner/headers
                    # We add a Host header for better compatibility with virtual hosts
                    probe = f"HEAD / HTTP/1.1\r\nHost: {ip}\r\nUser-Agent: ARF-Recon/1.0\r\nConnection: close\r\n\r\n"
                    writer.write(probe.encode())
                    await writer.drain()
                
                # 3. For services like SSH/FTP, we don't send anything!
                # We just wait for the "Server Greeting" to hit the buffer.
                try:
                    banner_bytes = await asyncio.wait_for(reader.read(100), timeout=1.5)
                    banner = banner_bytes.decode('utf-8', errors='ignore').strip().split('\n')[0][:40]
                except Exception: 
                    banner = "Open (No Banner)"
                
                open_ports_and_banners[port] = banner if banner else "Open"
                
                writer.close()
                await writer.wait_closed()
                
            except Exception: 
                # Port is likely closed or filtered
                pass
                
        return open_ports_and_banners

    async def detect_waf(self, session, url):
        waf_signatures = ['cloudflare', 'incapsula', 'sucuri', 'akamai', 'imperva', 'aws']
        try:
            async with session.get(url, timeout=5) as resp:
                headers = str(resp.headers).lower()
                for waf in waf_signatures:
                    if waf in headers or 'cf-ray' in headers or 'x-amz-cf-id' in headers: return f"Protected ({waf.capitalize()})"
        except Exception: pass
        return "None Detected"

    async def extract_js_secrets(self, session, url):
        secrets_found = []
        try:
            async with session.get(url, timeout=5) as resp:
                html = await resp.text(); soup = BeautifulSoup(html, 'lxml')
                scripts = soup.find_all('script', src=True)
                for script in scripts[:3]: 
                    src = script['src']
                    js_url = src if src.startswith('http') else f"{url}/{src.lstrip('/')}"
                    async with session.get(js_url, timeout=5) as js_resp:
                        js_text = await js_resp.text()
                        matches = self.secret_regex.findall(js_text)
                        if matches: secrets_found.extend(matches)
        except Exception: pass
        return list(set(secrets_found))
    
    async def fetch_threat_intel(self, session, ip, target_domain):
        """Universal Async API Plug for GreyNoise, VT, Pulsedive, and Censys."""
        intel_flags = []
        if not ip or ip == "Unknown": return intel_flags

        # 1. GreyNoise Community (Free)
        if self.api_keys.get("greynoise"):
            try:
                async with session.get(f"https://api.greynoise.io/v3/community/{ip}", headers={"key": self.api_keys["greynoise"]}, timeout=5) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        if data.get("noise"): intel_flags.append("[GreyNoise] Known Background Scanner/Noise")
                        if data.get("riot"): intel_flags.append("[GreyNoise] Known Benign Service")
            except Exception: pass

        # 2. VirusTotal (Free)
        if self.api_keys.get("vt"):
            try:
                async with session.get(f"https://www.virustotal.com/api/v3/ip_addresses/{ip}", headers={"x-apikey": self.api_keys["vt"]}, timeout=5) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        malicious = data['data']['attributes']['last_analysis_stats']['malicious']
                        if malicious > 0: intel_flags.append(f"[VirusTotal] Flagged Malicious by {malicious} vendors")
            except Exception: pass

        # 3. Pulsedive (Free)
        if self.api_keys.get("pulsedive"):
            try:
                async with session.get(f"https://pulsedive.com/api/info.php?indicator={ip}&key={self.api_keys['pulsedive']}", timeout=5) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        risk = data.get("risk", "none")
                        if risk in ["high", "critical", "medium"]: intel_flags.append(f"[Pulsedive] Risk Level: {risk.upper()}")
            except Exception: pass

        # 4. Censys Platform v3 (New Free Tier)
        censys_token = self.api_keys.get("censys_id") 
        if censys_token:
            try:
                headers = {"Authorization": f"Bearer {censys_token}"}
                url = f"https://api.platform.censys.io/v3/global/asset/host/{ip}"
                async with session.get(url, headers=headers, timeout=5) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        services = data.get("result", {}).get("services", [])
                        if services: 
                            intel_flags.append(f"[Censys] Detected {len(services)} active platform services")
            except Exception: pass

        return intel_flags

    async def wayback_discovery(self, domain, base_dir):
        if self.is_ip(domain): return 
        self.log("INFO", f"Querying Wayback Machine for {domain}...")
        url = f"http://web.archive.org/cdx/search/cdx?url=*.{domain}/*&collapse=urlkey&output=json&fl=original&limit=100"
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=15) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        endpoints = [row[0] for row in data[1:]] if len(data) > 1 else []
                        if endpoints:
                            with open(f"{base_dir}/wayback_endpoints.txt", "w") as f: f.write("\n".join(endpoints))
                            self.log("INFO", f"Saved {len(endpoints)} historical endpoints.")
        except Exception: pass

    async def take_screenshot(self, url, filepath):
        if not PLAYWRIGHT_AVAILABLE: return False
        try:
            async with async_playwright() as p:
                browser = await p.chromium.launch(headless=True)
                
                # --- FIX 1: Ignore Bad SSL/TLS Certs (Crucial for Recon!) ---
                context = await browser.new_context(ignore_https_errors=True)
                page = await context.new_page()
                
                # --- FIX 2: Wait until the network is completely quiet (No active AJAX/Images loading) ---
                await page.goto(url, timeout=15000, wait_until="networkidle")
                
                # --- FIX 3: Force a hard 1.5s delay to let heavy JS frameworks (React/Vue) draw the UI ---
                await page.wait_for_timeout(1500)
                
                await page.screenshot(path=filepath)
                await browser.close()
                return True
        except Exception as e: 
            self.log("WARNING", f"Playwright Error on {url}: {str(e)}")
            return False

    async def send_webhook(self, message):
        if not self.webhook_url: return
        try:
            async with aiohttp.ClientSession() as session:
                payload = {"content": message}
                async with session.post(self.webhook_url, json=payload) as resp:
                    if resp.status in [200, 204]: self.log("INFO", "Discord Webhook alert sent successfully!")
                    else: self.log("ERROR", f"Discord rejected webhook: {resp.status}")
        except Exception as e: self.log("ERROR", f"Webhook connection error: {e}")

    def shodan_blocking_call(self, api, ip):
        time.sleep(1.2); return api.host(ip)

    async def enrich_host(self, session, target, ip_data, sem, browser_sem, base_dir):
        if not self.is_running: return # <--- INSTANT KILL SWITCH
        async with sem:
            http_url = f"http://{target}"; https_url = f"https://{target}"
            waf_status = await self.detect_waf(session, http_url)
            if waf_status == "None Detected": waf_status = await self.detect_waf(session, https_url)
            secrets = await self.extract_js_secrets(session, http_url)
            active_services = await self.active_port_scan_and_banner_grab(ip_data['ip'])
            
            # --- NEW: Call Deep Threat Intel API Engine ---
            threat_intel = await self.fetch_threat_intel(session, ip_data['ip'], target)
            # ----------------------------------------------
            
            # Wrap the heavy Playwright screenshots in the secondary semaphore
            img_path = f"{base_dir}/screenshots/{target.replace('.', '_')}.png"
            async with browser_sem:
                shot_taken = await self.take_screenshot(http_url, img_path)
                if not shot_taken: await self.take_screenshot(https_url, img_path)

            shodan_data = {"ports": [], "vulns": [], "os": "Unknown"}
            if ip_data['type'] == 'Public' and self.shodan_key and SHODAN_AVAILABLE:
                try:
                    loop = asyncio.get_running_loop()
                    api = shodan.Shodan(self.shodan_key)
                    host_info = await loop.run_in_executor(None, self.shodan_blocking_call, api, ip_data['ip'])
                    shodan_data["ports"] = host_info.get('ports', [])
                    shodan_data["vulns"] = host_info.get('vulns', [])
                    shodan_data["os"] = host_info.get('os', 'Unknown')
                except Exception:
                    # Fails silently if out of Shodan credits!
                    pass

            # --- GEO-IP OSINT FETCHING (For Hacker Map) ---
            lat, lon, city, country = None, None, "Unknown", "Unknown"
            if ip_data['type'] == 'Public':
                try:
                    # Use http (free tier) to fetch geolocation data
                    async with session.get(f"http://ip-api.com/json/{ip_data['ip']}", timeout=5) as geo_resp:
                        if geo_resp.status == 200:
                            g = await geo_resp.json()
                            lat, lon = g.get('lat'), g.get('lon')
                            city, country = g.get('city', 'Unknown'), g.get('country', 'Unknown')
                except Exception: pass
            # --------------------------------------------------

            # Combine Shodan Vulns with our new Threat Intel Flags
            combined_vulns = shodan_data["vulns"] + threat_intel

            self.processed_data[target] = {
                "ip": ip_data['ip'], 
                "type": ip_data['type'], 
                "waf": waf_status, 
                "services": active_services,
                "os": shodan_data["os"], 
                "shodan_ports": shodan_data["ports"], 
                "vulns": combined_vulns,           # <--- MERGED VULNS & THREAT INTEL
                "js_secrets": len(secrets), 
                "screenshot": img_path if os.path.exists(img_path) else "Failed",
                "lat": lat,        
                "lon": lon,        
                "city": city,      
                "country": country 
            }

    async def async_resolve(self, subdomain, resolver):
        try:
            answers = await resolver.resolve(subdomain, 'A'); ip = str(answers[0])
            routing = "Private" if ipaddress.ip_address(ip).is_private else "Public"
            return subdomain, {"ip": ip, "type": routing}
        except Exception: return subdomain, None

    async def enum_and_brute(self, target):
        live_hosts = {}
        if self.is_ip(target):
            self.log("INFO", f"Target {target} recognized as IP. Skipping subdomain brute-force.")
            routing = "Private" if ipaddress.ip_address(target).is_private else "Public"
            live_hosts[target] = {"ip": target, "type": routing}
            return live_hosts

        resolver = dns.asyncresolver.Resolver(); resolver.nameservers = ['8.8.8.8', '1.1.1.1']
        self.discovered_subs.add(target)

        # 1. crt.sh (Certificate Transparency)
        try:
            resp = requests.get(f"https://crt.sh/?q=%25.{target}&output=json", timeout=15)
            if resp.status_code == 200:
                for entry in resp.json():
                    for n in entry['name_value'].split('\n'):
                        if not n.startswith('*'): self.discovered_subs.add(n.strip())
        except Exception: pass
        
        time.sleep(1) # Gap to avoid hitting API burst limits

        # 2. HackerTarget (Passive DNS)
        try:
            resp = requests.get(f"https://api.hackertarget.com/hostsearch/?q={target}", timeout=10)
            if resp.status_code == 200 and "error" not in resp.text.lower():
                for line in resp.text.split('\n'):
                    if ',' in line: self.discovered_subs.add(line.split(',')[0].strip())
        except Exception: pass
        
        # --- POINT 4 FIX: ALIENVAULT OTX WITH RATE-LIMIT PROTECTION ---
        time.sleep(1) # Essential courtesy delay for free tier APIs
        self.log("INFO", "Querying AlienVault OTX (Passive DNS)...")
        try:
            otx_url = f"https://otx.alienvault.com/api/v1/indicators/domain/{target}/passive_dns"
            resp = requests.get(otx_url, timeout=10)
            if resp.status_code == 200:
                otx_results = resp.json().get('passive_dns', [])
                for entry in otx_results:
                    sub = entry.get('hostname')
                    if sub and sub.endswith(target): 
                        self.discovered_subs.add(sub.strip())
            elif resp.status_code == 429:
                self.log("WARNING", "AlienVault OTX: Rate limit exceeded. Try again later.")
        except Exception as e: 
            self.log("WARNING", f"AlienVault OTX Query failed: {str(e)}")
        # --------------------------------------------------------------
        
        # 4. Wordlist Brute-force (Preparation)
        try:
            if os.path.exists(self.wordlist_path):
                with open(self.wordlist_path, 'r') as file:
                    for word in file: self.discovered_subs.add(f"{word.strip()}.{target}")
        except Exception: pass

        # 5. Apply Scope Enforcement
        original_count = len(self.discovered_subs)
        self.discovered_subs = {sub for sub in self.discovered_subs if self.is_in_scope(sub)}
        filtered_count = original_count - len(self.discovered_subs)
        
        if filtered_count > 0:
            self.log("WARNING", f"[SCOPE ENFORCER] Dropped {filtered_count} out-of-scope subdomains.")

        total = len(self.discovered_subs)
        if total == 0: return live_hosts

        self.log("INFO", f"Resolving {total} unique subdomains...")
        
        # 6. Async DNS Resolution
        subs_list = list(self.discovered_subs)
        resolved = 0
        for i in range(0, len(subs_list), 500):
            if not self.is_running: break
            
            # --- FIX: Only create coroutines for the current batch ---
            batch = subs_list[i:i+500]
            tasks = [self.async_resolve(sub, resolver) for sub in batch]
            
            results = await asyncio.gather(*tasks)
            for sub, data in results:
                if data: live_hosts[sub] = data
            resolved += len(batch)
            self.signals.progress_signal.emit(int((resolved / total) * 40))
            
        return live_hosts
    def generate_network_graph(self, target, data, output_path):
        self.log("INFO", "Generating Interactive PyVis Network Graph...")
        try:
            # Step 1: Keep 'in_line' to bypass Kali firewall/CDN blocks
            net = Network(height="100%", width="100%", bgcolor="#050508", font_color="#00FF41", select_menu=False, cdn_resources='in_line')
            
            # Stable Physics
            net.barnes_hut(gravity=-8000, central_gravity=0.3, spring_length=250)
            
            # Nodes and Edges
            net.add_node(target, label=target, title="Target Domain", color="#ff003c", size=40, shape="diamond")
            ip_nodes = set()
            for sub, info in data.items():
                ip = info.get('ip', 'Unknown')
                net.add_node(sub, label=sub, title=f"WAF: {info.get('waf')}\nOS: {info.get('os')}", color="#00ff00", size=25)
                net.add_edge(target, sub, color="#1a5e20")
                if ip not in ip_nodes and ip != 'Unknown':
                    net.add_node(ip, label=ip, title=f"IP Address", color="#0055ff", size=30, shape="box")
                    ip_nodes.add(ip)
                if ip != 'Unknown': net.add_edge(sub, ip, color="#002244")
                for port in info.get('services', {}).keys():
                    port_node = f"{ip}:{port}"
                    if port_node not in ip_nodes:
                        net.add_node(port_node, label=f"P:{port}", title="Active Service", color="#ffff00", size=15)
                        ip_nodes.add(port_node)
                    net.add_edge(ip, port_node, color="#444400")

            os.makedirs(output_path, exist_ok=True)
            graph_file = os.path.join(output_path, "network_graph.html")
            net.save_graph(graph_file)

            # Step 2: THE SURGICAL CSS INJECTION
            if os.path.exists(graph_file):
                with open(graph_file, 'r', encoding='utf-8') as f:
                    content = f.read()

                # Create a brand new style block. 
                # Using 100vw/100vh guarantees it stretches to the viewport edges.
                custom_style = """
                <style type="text/css">
                    /* ARF Master Override */
                    body, html { margin: 0; padding: 0; width: 100%; height: 100%; overflow: hidden; background-color: #050508 !important; }
                    #mynetwork { 
                        position: absolute !important; 
                        top: 0 !important; 
                        left: 0 !important; 
                        right: 0 !important; 
                        bottom: 0 !important; 
                        width: 100vw !important; 
                        height: 100vh !important; 
                        background-color: #050508 !important; 
                        border: none !important; 
                        margin: 0 !important; 
                    }
                </style>
                """
                
                # Replace the closing </head> tag with our custom style + </head>
                # The "1" at the end ensures we only do this replacement EXACTLY once.
                content = content.replace('</head>', custom_style + '\n</head>', 1)

                with open(graph_file, 'w', encoding='utf-8') as f:
                    f.write(content)

            return graph_file
        except Exception as e:
            self.log("ERROR", f"Graph Failed: {e}")
            return None

    async def run_scan_cycle(self):
        for target in self.targets:
            if not self.is_running: break
            self.discovered_subs.clear(); self.processed_data.clear()
            base_dir = self.create_output_dirs(target)
            
            self.log("INFO", f"--- Commencing Scan for {target} ---")
            
            # --- PHASE 1: Subdomain Enum ---
            live_hosts_map = await self.enum_and_brute(target)
            self.signals.progress_signal.emit(40)
            
            # CHECKPOINT 1
            if not self.is_running: 
                await self.finalize_report(target, base_dir)
                break
                
            # --- PHASE 2: Wayback Machine ---
            await self.wayback_discovery(target, base_dir)
            
            # CHECKPOINT 2
            if not self.is_running: 
                await self.finalize_report(target, base_dir)
                break

            # --- PHASE 3: Enrichment (WAF, OS, Ports) ---
            self.log("INFO", f"Enriching {len(live_hosts_map)} live hosts (Ports, Services, WAF, OS)...")
            sem = asyncio.Semaphore(self.threads)  
            browser_sem = asyncio.Semaphore(3)     
            
            async with aiohttp.ClientSession() as session:
                tasks = [self.enrich_host(session, sub, ip_data, sem, browser_sem, base_dir) for sub, ip_data in live_hosts_map.items()]
                if tasks:
                    await asyncio.gather(*tasks)

            self.signals.progress_signal.emit(90)
            
            # --- NORMAL FINISH ---
            await self.finalize_report(target, base_dir)

    async def finalize_report(self, target, base_dir):
        """Safely saves all gathered data, whether the scan finished or was terminated early."""
        if not self.is_running:
            self.log("CRITICAL", "[!] Pipeline halted. Preserving partially recovered data...")

        final_risk = self.calculate_workspace_risk(self.processed_data)
        self.signals.risk_score_signal.emit(final_risk)
        self.log("INFO", f"Workspace Vulnerability Rating: {final_risk}/100")
        
        # --- SQLITE BASELINE DIFFING (Zero Flat-Files) ---
        # Fetch the most recent previous scan for this target in this workspace
        with db.lock:
            db.cursor.execute("SELECT scan_id FROM scans WHERE target=? AND scan_type='AdvancedRecon' AND workspace=? ORDER BY timestamp DESC LIMIT 1", (target, self.project_name))
            last_scan = db.cursor.fetchone()
        
        if last_scan:
            baseline = db.get_asset_data(last_scan[0])
            new_subs = set(self.processed_data.keys()) - set(baseline.keys())
            
            if new_subs:
                self.log("CRITICAL", f"MONITOR ALERT: {len(new_subs)} new assets found on {target}!")
                alert_msg = f"🚨 **[ALI RAZA RECON FRAMEWORK]** 🚨\nFound {len(new_subs)} new assets on `{target}`:\n"
                for sub in new_subs: 
                    alert_msg += f"- {sub} (IP: {self.processed_data[sub]['ip']})\n"
                
                # --- THE ANT FIX: Truncate to comply with Discord's 2000 char limit ---
                if len(alert_msg) > 1900:
                    alert_msg = alert_msg[:1900] + "\n\n... [DATA TRUNCATED DUE TO DISCORD LIMITS. CHECK DASHBOARD FOR FULL LIST]."
                    
                await self.send_webhook(alert_msg)
        scan_id = os.path.basename(base_dir)
        db.save_scan_meta(scan_id, self.project_name, target, "AdvancedRecon", final_risk, self.exec_mode)

        for sub, info in self.processed_data.items():
            db.save_asset(
                scan_id, 
                sub, 
                info['ip'], 
                info['os'], 
                info['waf'], 
                info['js_secrets'], 
                info['services'], 
                info['vulns'],
                info.get('lat'),
                info.get('lon'),
                info.get('city', 'Unknown'),
                info.get('country', 'Unknown')
            )
            
        # --- NEW: Synthesize a Technical Execution Log for the Live Recon Engine ---
        synthetic_log = "LIVE RECONNAISSANCE ENGINE - TELEMETRY DUMP\n"
        synthetic_log += "="*60 + "\n"
        for sub, info in self.processed_data.items():
            synthetic_log += f"[*] Target: {sub}\n"
            synthetic_log += f"    IP Address : {info.get('ip', 'Unknown')}\n"
            synthetic_log += f"    Location   : {info.get('city', 'Unknown')}, {info.get('country', 'Unknown')}\n"
            synthetic_log += f"    WAF Status : {info.get('waf', 'Unknown')}\n"
            synthetic_log += f"    Open Ports : {list(info.get('services', {}).keys())}\n"
            synthetic_log += f"    Identified CVEs : {info.get('vulns', [])}\n"
            synthetic_log += f"    JS Secrets : {info.get('js_secrets', 0)}\n\n"
            
        db.save_tool_output(scan_id, "Live_Recon_Telemetry", synthetic_log)
        # -------------------------------------------------------------------------    

        for file_name in os.listdir(base_dir):
            if file_name.endswith(".txt") and "MASTER" not in file_name:
                file_path = os.path.join(base_dir, file_name)
                try:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        db.save_tool_output(scan_id, file_name.replace('.txt', ''), f.read())
                    os.remove(file_path)
                except Exception: pass

        ts = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        html = "<html><body style='background-color:#0d0d0d;color:#00ff00;'><table border='1' style='border-color:#005500;'><tr><th>Target</th><th>IP</th><th>OS</th><th>Services</th></tr>"
        for s, d in self.processed_data.items(): 
            html += f"<tr><td>{s}</td><td>{d['ip']}</td><td>{d['os']}</td><td>{str(d['services'])}</td></tr>"
        html += "</table></body></html>"
        with open(f"{base_dir}/report_{ts}.html", 'w', encoding='utf-8') as f: 
            f.write(html)
            
        # 5. Graph Generation
        self.generate_network_graph(target, self.processed_data, base_dir)
        
        self.log("INFO", f"Data automatically preserved in {base_dir}/")
        self.signals.results_signal.emit(self.processed_data, target, base_dir)

        self.signals.progress_signal.emit(100)

    async def run_async_tasks(self):
        while self.is_running:
            await self.run_scan_cycle()
            if not self.continuous: break
            
            self.log("INFO", f"Sleeping for {self.interval_mins} mins...")
            
            # --- THE ANT FIX: Responsive Sleep Tick Loop ---
            sleep_seconds = self.interval_mins * 60
            for _ in range(sleep_seconds):
                if not self.is_running: 
                    break  # Instantly break the sleep if the kill switch is hit!
                await asyncio.sleep(1)
                
        self.signals.finished_signal.emit()
    def run(self): asyncio.run(self.run_async_tasks())
    def stop(self): self.is_running = False