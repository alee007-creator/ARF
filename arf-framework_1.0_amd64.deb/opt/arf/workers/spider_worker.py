import os
import re
import requests
from bs4 import BeautifulSoup
from PyQt6.QtCore import QThread, pyqtSignal

class SpiderWorker(QThread):
    log_signal = pyqtSignal(str)
    finished_signal = pyqtSignal(str, int) 
    error_signal = pyqtSignal(str)

    def __init__(self, target, project_name):
        super().__init__()
        self.target = target
        self.project_name = project_name # Pass the active workspace here

    def run(self):
        headers = {'User-Agent': 'Mozilla/5.0 ARF-Crawler/1.0', 'Accept': 'text/html'}
        protocols = [f"https://{self.target}", f"http://{self.target}"]
        words = set()

        for url in protocols:
            try:
                self.log_signal.emit(f"  [>] Attempting: {url}")
                resp = requests.get(url, timeout=(5, 10), verify=False, headers=headers, stream=True)
                if resp.status_code != 200: continue

                content = b""
                for chunk in resp.iter_content(chunk_size=8192):
                    content += chunk
                    if len(content) > 1000000: break
                
                resp.close()
                soup = BeautifulSoup(content, 'html.parser')
                text = soup.get_text(separator=' ')
                extracted = re.findall(r'\b[a-zA-Z]{4,20}\b', text.lower())
                
                if extracted:
                    words.update(extracted)
                    break 
            except Exception:
                self.log_signal.emit(f"  [!] {url.split(':')[0]} failed.")

        if words:
            # --- NEW: OPTIMIZED PATH LOGIC ---
            # Path: Spider_Wordlists/[Workspace_Name]/
            save_dir = os.path.join("Spider_Wordlists", self.project_name)
            os.makedirs(save_dir, exist_ok=True)
            
            file_name = f"wordlist_{self.target.replace('.', '_')}.txt"
            full_path = os.path.join(save_dir, file_name)
            
            with open(full_path, 'w', encoding='utf-8') as f:
                f.write("\n".join(sorted(list(words))))
            
            # Emit the full path so the GUI can point to the correct location
            self.finished_signal.emit(full_path, len(words))
        else:
            self.error_signal.emit(f"[-] No words recovered from {self.target}")