import os
import json
import requests
import boto3
from PyQt6.QtCore import QThread, pyqtSignal

# ===================================================
# --- HYBRID ASYNC AI WORKER (Local + AWS Cloud) ---
# ===================================================
class AIWorker(QThread):
    response_signal = pyqtSignal(str)
    error_signal = pyqtSignal(str)
    finished_signal = pyqtSignal()  # Added to safely re-enable GUI buttons!

    def __init__(self, prompt, model_choice, aws_bedrock_key="", aws_region="us-east-1"):
        super().__init__()
        self.prompt = prompt
        self.model_choice = model_choice
        self.aws_bedrock_key = aws_bedrock_key
        self.aws_region = aws_region
        self.is_running = True

    def stop(self):
        self.is_running = False

    def run(self):
        try:
            # ========================================================
            # ENGINE 1: CLOUD (AWS BEDROCK - CLAUDE OPUS)
            # ========================================================
            if "AWS" in self.model_choice:
                if not self.aws_bedrock_key:
                    raise ValueError("Bedrock Bearer Token missing. Please add it in the Core Configuration tab.")
                
                # Natively pass the Bearer Token to AWS Boto3
                os.environ["AWS_BEARER_TOKEN_BEDROCK"] = self.aws_bedrock_key
                
                bedrock = boto3.client(
                    service_name='bedrock-runtime',
                    region_name=self.aws_region
                )

                body = json.dumps({
                    "anthropic_version": "bedrock-2023-05-31",
                    "max_tokens": 2048,
                    "messages": [{"role": "user", "content": [{"type": "text", "text": self.prompt}]}]
                })

                # Check panic button before making heavy cloud call
                if not self.is_running:
                    return

                response = bedrock.invoke_model(
                    body=body,
                    modelId="us.anthropic.claude-opus-4-1-20250805-v1:0", # Your AWS target model
                    accept="application/json",
                    contentType="application/json"
                )

                # Check panic button after call returns
                if not self.is_running:
                    return

                response_body = json.loads(response.get('body').read())
                ai_text = response_body.get('content')[0].get('text')
                self.response_signal.emit(ai_text)

            # ========================================================
            # ENGINE 2: LOCAL (OLLAMA OFFLINE)
            # ========================================================
            else:
                # --- CRASH FIX: stream=True allows us to check for interruptions mid-generation ---
                resp = requests.post("http://127.0.0.1:11434/api/generate", 
                                     json={"model":"qwen2.5-coder:3b", "prompt": self.prompt}, 
                                     stream=True, timeout=60)
                
                if resp.status_code == 200:
                    full_response = ""
                    for line in resp.iter_lines():
                        if not self.is_running: break # Halt instantly if panic button is pressed!
                        if line:
                            # --- THE ANT FIX: Protect against fragmented AI stream chunks ---
                            try:
                                data = json.loads(line)
                                full_response += data.get("response", "")
                                if data.get("done"): break
                            except json.JSONDecodeError:
                                continue # Skip the broken chunk and wait for the next healthy packet
                                
                    if self.is_running:
                        self.response_signal.emit(full_response)
                else:
                    self.error_signal.emit(f"AI Server Error: {resp.status_code}")

        except requests.exceptions.Timeout:
            self.error_signal.emit("Timeout Exceeded: The AI took too long. Model may be heavy.")
        except requests.exceptions.ConnectionError:
            self.error_signal.emit("Connection Refused: Ollama is not responding. Ensure 'Wake' is active.")
        except Exception as e:
            self.error_signal.emit(f"AI Engine Error: {str(e)}")
            
        finally:
            # Emit this no matter what happens, so your UI doesn't stay frozen
            self.finished_signal.emit()