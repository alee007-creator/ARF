import os
import time
import datetime
import re
import subprocess
import platform
from PyQt6.QtCore import QThread, pyqtSignal
from core.database import db

# ===================================================
# --- DOMAIN & IP AUTO-SCAN WORKERS ---
# ===================================================
class DomainAutoScanWorker(QThread):
    output_signal = pyqtSignal(str)
    error_signal = pyqtSignal(str)
    finished_signal = pyqtSignal()

    def __init__(self, targets, wordlist, project_name="Default_Workspace", exec_mode="GUI"):
        super().__init__()
        self.targets = targets
        self.wordlist = wordlist
        self.project_name = project_name
        self.is_running = True
        self.current_save_dir = None
        self.clean_target = ""
        self.tool_status = {}
        self.is_finished = False
        self.final_msg = ""
        self.exec_mode = exec_mode # <--- Added
        
        self.tools = [
            ("WHOIS", ["whois", "{t}"]),
            ("Dig", ["dig", "{t}", "ANY", "+short"]),
            ("Subfinder", ["subfinder", "-d", "{t}", "-all", "-silent"]),
            ("Assetfinder", ["assetfinder", "--subs-only", "{t}"]),
            ("Amass", ["timeout", "-k", "1m", "10m", "amass", "enum", "-passive", "-d", "{t}", "-timeout", "10"]),
            ("DNSX", ["subfinder", "-d", "{t}", "-silent", "|", "dnsx", "-silent", "-a", "-resp"]),
            ("TLSX", ["tlsx", "-u", "{t}", "-san", "-cn", "-silent"]),
            ("theHarvester", ["theHarvester", "-d", "{t}", "-b", "all", "-l", "500"]),
            ("Naabu", ["naabu", "-host", "{t}", "-top-ports", "1000", "-silent"]),
            ("Nmap", ["nmap", "-sV", "-sC", "-Pn", "-T4", "{t}"]), 
            ("HTTPX", ["echo", "{t}", "|", "httpx-toolkit", "-title", "-tech-detect", "-status-code", "-silent", "||", "echo", "{t}", "|", "httpx", "-title", "-tech-detect", "-status-code", "-silent"]), 
            ("WhatWeb", ["whatweb", "-a", "3", "{t}", "--no-errors", "--color=NEVER"]),
            ("WAFw00f", ["wafw00f", "{t}"]),
            ("Katana", ["katana", "-u", "https://{t}", "-silent", "-jc", "-d", "3"]),
            ("Nuclei", ["nuclei", "-u", "https://{t}", "-silent", "-ni", "-nc", "-severity", "critical,high,medium"]),
            ("GAU", ["gau", "{t}"]),
            ("FFUF", ["ffuf", "-s", "-w", "{wordlist}", "-u", "http://{t}/FUZZ", "-t", "50", "-mc", "200,301,302,403"]),
            ("Wfuzz", ["wfuzz", "-w", "{wordlist}", "-t", "50", "-Z", "--hc", "404", "http://{t}/FUZZ", "2>/dev/null"]),
            ("Nikto", ["nikto", "-h", "{t}", "-Tuning", "4", "-maxtime", "5m", "-nolookup"])
        ]
        
    def stop(self):
        self.is_running = False
        if self.current_save_dir:
            try: open(os.path.join(self.current_save_dir, '.abort_scan'), 'w').close()
            except: pass

    def compile_master_report(self, save_dir, target):
        excluded = ["gau", "gui_master_log", "recon_runner"]
        ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])') 
        
        master_html = f"<html><body style='background-color:#050508; color:#00FF41; font-family: monospace; padding: 20px;'>"
        master_html += f"<h1 style='text-align:center; color:#ffffff;'>MASTER RECONNAISSANCE REPORT</h1>"
        master_html += f"<h3 style='text-align:center; color:#00ffff;'>Target: {target} | Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}</h3><hr style='border: 1px solid #1a5e20;'>"
        
        for file_name in sorted(os.listdir(save_dir)):
            if not file_name.endswith(".txt"): continue
            if any(ex in file_name.lower() for ex in excluded): continue
            
            tool_name = file_name.replace(".txt", "").replace("_", " ")
            file_path = os.path.join(save_dir, file_name)
            
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read().strip()
                    content = ansi_escape.sub('', content) 
                    
                lines = content.split('\n')
                seen = set()
                deduped = []
                for line in lines:
                    if line not in seen:
                        deduped.append(line)
                        seen.add(line)
                content = '\n'.join(deduped).strip()

                content = re.sub(r';; Warning: Client COOKIE mismatch\n?', '', content).strip()

                if tool_name.upper() == "WAFW00F":
                    content = re.sub(r'^[ \t]*[/\(\)\\\|_,.`\'-]+.*$', '', content, flags=re.MULTILINE)
                    content = re.sub(r'.*WAFW00F.*|.*The Web Application.*', '', content).strip()
                    
                if tool_name.upper() == "WFUZZ":
                    content = re.sub(r'\* Wfuzz.*\n\*.*\n\*{3,}', '', content).strip()
                    processed = re.search(r'Processed Requests: (\d+)', content)
                    filtered = re.search(r'Filtered Requests: (\d+)', content)
                    if processed and filtered and processed.group(1) == filtered.group(1):
                        content = "" 

                if tool_name.upper() == "NIKTO":
                    content = re.sub(r'- Nikto v.*\n-+', '', content).strip()
                    if "0 host(s) tested" in content or not content:
                        content = ""

                master_html += f"<h2 style='color:#00ffff; margin-top: 30px;'>▶ {tool_name.upper()}</h2>"
                
                lower_c = content.lower()
                
                empty_flags = [
                    "0 hosts", "total requests: 0", "execution expired", 
                    "no match for", "appears to be down", "malformed request", 
                    "no assets were discovered", "flag provided but not defined", 
                    "no such option", "missing wordlist", "0 errors and 0 items"
                ]
                
                is_empty = not content or any(flag in lower_c for flag in empty_flags)

                if is_empty:
                    master_html += f"<p style='color:#888888;'><i>[-] No significant data or vulnerabilities found using this tool.</i></p>"
                else:
                    master_html += f"<pre style='color:#00ff00; background:#0a0a0c; padding:15px; border:1px solid #1a5e20; border-radius: 5px; white-space: pre-wrap; word-wrap: break-word;'>{content}</pre>"
            except Exception as e:
                pass
                
        master_html += "</body></html>"
        
        report_path = os.path.join(save_dir, f"MASTER_REPORT_{target}.html")
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(master_html)

    def update_dashboard(self):
        html = f"<div style='background-color:#0d0d0d; color:#00ff00; font-family:monospace; white-space:pre; padding: 10px;'>"
        html += f"{'='*50}\n[#] DEPLOYING DETACHED DOMAIN RECON: {self.clean_target}\n"
        html += f"[#] Routed to Workspace: {self.project_name}\n{'='*50}\n\n"
        
        for name, _ in self.tools:
            status = self.tool_status.get(name, {"state": "Queued", "time": ""})
            safe_name = re.sub(r'[^a-zA-Z0-9]', '_', name)
            
            if status["state"] == "Queued":
                html += f"<span style='color:#00ffff;'>[*] Queued:</span> {name} <span style='color:#555;'>-> .../{safe_name}.txt</span>\n"
            elif status["state"] == "Running":
                html += f"<span style='color:#ffff00;'>[▶] Running:</span> {name} <span style='color:#888;'>(Detached Terminal)</span>\n"
            elif status["state"] == "Completed":
                html += f"<span style='color:#00ff00;'>[✔] Completed:</span> {name} <span style='color:#888;'>(Took: {status['time']}s) -> {safe_name}.txt</span>\n"
                
        if self.is_finished:
            html += f"\n{'='*50}\n{self.final_msg}\n{'='*50}\n"
            report_path = os.path.join(self.current_save_dir, f"MASTER_REPORT_{self.clean_target}.html")
            html += f"<br><b style='color:#00ff00;'>[✔] MASTER HTML REPORT COMPILED:</b> <a href='file://{report_path}' style='color:#ffff00;'>{report_path}</a><br>"
        else:
            html += f"\n<b style='color:#ffff00;'>[🚀] Payload running in detached native terminal...</b>\n"
            
        html += "</div>"
        self.output_signal.emit(html)

    def run(self):
        pipeline_start = time.time()
        
        for target in self.targets:
            if not self.is_running: break
            self.clean_target = re.sub(r'^https?://', '', target).rstrip('/')
            
            self.tool_status = {name: {"state": "Queued", "time": ""} for name, _ in self.tools}
            self.is_finished = False
            self.update_dashboard()
            
            ts = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            target_save_dir = os.path.abspath(f"Scan_Results/{self.project_name}/AutoScanDomain_{self.clean_target}_{ts}")
            os.makedirs(target_save_dir, exist_ok=True)
            self.current_save_dir = target_save_dir
            
            script_path = os.path.join(target_save_dir, "recon_runner.sh")
            sync_file = os.path.join(target_save_dir, ".gui_sync.log")
            abort_file = os.path.join(target_save_dir, ".abort_scan").replace("\\", "/")
            
            open(sync_file, 'w').close()
            if os.path.exists(abort_file): os.remove(abort_file)
            
            bash_content = "#!/bin/bash\n"
            bash_content += "trap 'kill $(jobs -p) 2>/dev/null' EXIT\n\n"
            bash_content += f"echo '=================================================='\n"
            bash_content += f"echo '  ARF DETACHED RECONNAISSANCE ENGINE'\n"
            bash_content += f"echo '  Target: {self.clean_target}'\n"
            bash_content += f"echo '=================================================='\n\n"
            
            # Navigate into the save directory so screenshots save here natively
            bash_content += f"cd '{target_save_dir}'\n\n"
            
            # Start the abort watcher and capture its PID
            bash_content += f"( while true; do if [ -f '{abort_file}' ]; then echo ''; echo '[!] SCAN TERMINATED BY USER!'; sleep 2; kill 0; fi; sleep 1; done ) &\n"
            bash_content += "ABORT_PID=$!\n\n"

            bash_content += "echo '[*] Initiating Dynamic Parallel Execution (Max 3 Concurrent)...'\n"
            bash_content += "MAX_TOTAL_JOBS=4\n" # 3 tools + 1 abort watcher
            bash_content += "ALL_PIDS=\"\"\n\n"
            
            for tool_name, cmd_template in self.tools:
                safe_target = f"'{self.clean_target.replace('\'', '')}'"
                safe_wordlist = f"'{self.wordlist.replace('\'', '')}'"
                cmd = [arg.replace("{t}", safe_target).replace("{wordlist}", safe_wordlist) for arg in cmd_template]
                cmd_str = " ".join(cmd)
                safe_tool_name = re.sub(r'[^a-zA-Z0-9]', '_', tool_name)
                out_file = os.path.join(target_save_dir, f"{safe_tool_name}.txt")
                
                # --- TERMINAL GLITCH FIX: Pure ASCII text with no \e codes ---
                bash_content += f"echo '[>] Launching: {tool_name}'\n"
                bash_content += f"echo \"LAUNCH:{tool_name}\" >> '{sync_file}'\n"
                bash_content += "(\n"
                bash_content += "  START_TIME=$(date +%s)\n"
                bash_content += f"  eval \"{cmd_str}\" < /dev/null > '{out_file}' 2>&1\n"
                bash_content += "  END_TIME=$(date +%s)\n"
                bash_content += "  ELAPSED=$((END_TIME - START_TIME))\n"
                bash_content += f"  echo \"DONE:{tool_name}:${{ELAPSED}}\" >> '{sync_file}'\n"
                bash_content += f"  echo \"[+] Completed: {tool_name} (Took: ${{ELAPSED}}s) -> {safe_tool_name}.txt\"\n"
                bash_content += ") &\n"
                bash_content += "ALL_PIDS=\"$ALL_PIDS $!\"\n\n"
                
                bash_content += "while [ $(jobs -p | wc -l) -ge $MAX_TOTAL_JOBS ]; do sleep 1; done\n\n"
                
            bash_content += "echo '--- All payloads launched. Waiting for final tasks to cross the finish line... ---'\n"
            bash_content += "wait $ALL_PIDS\n\n" 
            
            # Kill the abort watcher so the script can naturally exit
            bash_content += "kill $ABORT_PID 2>/dev/null\n\n"

            bash_content += "echo ''\n"
            bash_content += "echo '[+] ALL RECON TASKS COMPLETED!'\n"
            bash_content += f"touch '{os.path.join(target_save_dir, '.scan_done')}'\n"
            bash_content += "read -p 'Press Enter to close this window...' -n 1\n"

            with open(script_path, 'w') as f:
                f.write(bash_content)
            os.chmod(script_path, 0o755)

            try:
                if platform.system() == "Windows":
                    subprocess.Popen(f'start cmd.exe /K "{script_path}"', shell=True)
                else:
                    terminals = ['x-terminal-emulator', 'qterminal', 'gnome-terminal', 'konsole', 'xfce4-terminal', 'xterm']
                    spawned = False
                    for term in terminals:
                        try:
                            if term == 'gnome-terminal':
                                subprocess.Popen([term, '--', 'bash', '-c', script_path], start_new_session=True)
                            else:
                                subprocess.Popen([term, '-e', f'bash -c "{script_path}"'], start_new_session=True)
                            spawned = True
                            break
                        except FileNotFoundError:
                            continue
                    if not spawned:
                        self.error_signal.emit("Could not find a supported terminal emulator to spawn.")
            except Exception as e:
                self.error_signal.emit(f"Failed to launch terminal: {str(e)}")

            done_file = os.path.join(target_save_dir, '.scan_done')
            last_pos = 0
            
            while self.is_running and not os.path.exists(done_file):
                if os.path.exists(sync_file):
                    with open(sync_file, 'r') as f:
                        f.seek(last_pos)
                        for line in f:
                            line = line.strip()
                            if line.startswith("LAUNCH:"):
                                t_name = line.split(":", 1)[1]
                                if t_name in self.tool_status:
                                    self.tool_status[t_name]["state"] = "Running"
                                    self.update_dashboard()
                            elif line.startswith("DONE:"):
                                parts = line.split(":")
                                t_name = parts[1]
                                elapsed = parts[2] if len(parts) > 2 else "?"
                                if t_name in self.tool_status:
                                    self.tool_status[t_name]["state"] = "Completed"
                                    self.tool_status[t_name]["time"] = elapsed
                                    self.update_dashboard()
                        last_pos = f.tell()
                time.sleep(0.5) 
                
            if os.path.exists(sync_file):
                with open(sync_file, 'r') as f:
                    f.seek(last_pos)
                    for line in f:
                        line = line.strip()
                        if line.startswith("DONE:"):
                            parts = line.split(":")
                            t_name = parts[1]
                            elapsed = parts[2] if len(parts) > 2 else "?"
                            if t_name in self.tool_status:
                                self.tool_status[t_name]["state"] = "Completed"
                                self.tool_status[t_name]["time"] = elapsed
                                
            self.is_finished = True
            total_time = int(time.time() - pipeline_start)
            m, s = divmod(total_time, 60)
            
            if self.is_running:
                self.final_msg = f"<b style='color:#00ff00;'>[+] DOMAIN PIPELINE COMPLETED IN: {m}m {s}s</b>"
            else:
                self.final_msg = f"<b style='color:#ff0000;'>[-] PIPELINE ABORTED BY USER AFTER: {m}m {s}s</b>"
                
            self.compile_master_report(target_save_dir, self.clean_target)
            self.update_dashboard()


            # --- SQLITE SIPHON FOR BASH OUTPUT ---
            scan_id = os.path.basename(target_save_dir)
            db.save_scan_meta(scan_id, self.project_name, self.clean_target, "BashAutoScan", 0, self.exec_mode)
            for file_name in os.listdir(target_save_dir):
                if file_name.endswith(".txt") and "MASTER" not in file_name:
                    file_path = os.path.join(target_save_dir, file_name)
                    try:
                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                            db.save_tool_output(scan_id, file_name.replace('.txt', ''), f.read())
                        os.remove(file_path)
                    except Exception: pass

            try: 
                os.remove(done_file)
                os.remove(sync_file)
                os.remove(abort_file)
            except: pass
        self.finished_signal.emit()


class IPAutoScanWorker(QThread):
    output_signal = pyqtSignal(str)
    error_signal = pyqtSignal(str)
    finished_signal = pyqtSignal()

    def __init__(self, targets, wordlist, project_name="Default_Workspace", exec_mode="GUI"):
        super().__init__()
        self.targets = targets
        self.wordlist = wordlist
        self.project_name = project_name
        self.is_running = True
        self.current_save_dir = None
        self.clean_target = ""
        self.tool_status = {}
        self.is_finished = False
        self.final_msg = ""
        self.exec_mode = exec_mode # <--- Added
        
        self.tools = [
            ("WHOIS", ["whois", "{t}"]),
            ("nslookup", ["nslookup", "{t}"]),
            ("Naabu", ["naabu", "-host", "{t}", "-top-ports", "1000", "-silent"]),
            ("Nmap", ["nmap", "-sV", "-sC", "-Pn", "-T4", "--open", "{t}"]), 
            ("HTTPX", ["echo", "{t}", "|", "httpx-toolkit", "-title", "-tech-detect", "-status-code", "-silent", "||", "echo", "{t}", "|", "httpx", "-title", "-tech-detect", "-status-code", "-silent"]),
            ("WhatWeb", ["whatweb", "-a", "3", "{t}", "--no-errors", "--color=NEVER"]),
            ("WAFw00f", ["wafw00f", "{t}"]),
            ("Katana", ["katana", "-u", "http://{t}", "-silent", "-jc", "-d", "3"]),
            ("Nuclei", ["nuclei", "-u", "http://{t}", "-silent", "-ni", "-nc", "-severity", "critical,high,medium"]),
            ("FFUF", ["ffuf", "-s", "-w", "{wordlist}", "-u", "http://{t}/FUZZ", "-t", "50", "-mc", "200,301,302,403"]),
            ("Wfuzz", ["wfuzz", "-w", "{wordlist}", "-t", "50", "-Z", "--hc", "404", "http://{t}/FUZZ", "2>/dev/null"]),
            ("Nikto", ["nikto", "-h", "{t}", "-Tuning", "4", "-maxtime", "5m", "-nolookup"])
        ]
        
    def stop(self):
        self.is_running = False
        if self.current_save_dir:
            try: open(os.path.join(self.current_save_dir, '.abort_scan'), 'w').close()
            except: pass

    def compile_master_report(self, save_dir, target):
        excluded = ["gau", "gui_master_log", "recon_runner"]
        ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])') 
        
        master_html = f"<html><body style='background-color:#050508; color:#00FF41; font-family: monospace; padding: 20px;'>"
        master_html += f"<h1 style='text-align:center; color:#ffffff;'>MASTER RECONNAISSANCE REPORT</h1>"
        master_html += f"<h3 style='text-align:center; color:#00ffff;'>Target: {target} | Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}</h3><hr style='border: 1px solid #1a5e20;'>"
        
        for file_name in sorted(os.listdir(save_dir)):
            if not file_name.endswith(".txt"): continue
            if any(ex in file_name.lower() for ex in excluded): continue
            
            tool_name = file_name.replace(".txt", "").replace("_", " ")
            file_path = os.path.join(save_dir, file_name)
            
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read().strip()
                    content = ansi_escape.sub('', content) 
                    
                lines = content.split('\n')
                seen = set()
                deduped = []
                for line in lines:
                    if line not in seen:
                        deduped.append(line)
                        seen.add(line)
                content = '\n'.join(deduped).strip()

                content = re.sub(r';; Warning: Client COOKIE mismatch\n?', '', content).strip()

                if tool_name.upper() == "WAFW00F":
                    content = re.sub(r'^[ \t]*[/\(\)\\\|_,.`\'-]+.*$', '', content, flags=re.MULTILINE)
                    content = re.sub(r'.*WAFW00F.*|.*The Web Application.*', '', content).strip()
                    
                if tool_name.upper() == "WFUZZ":
                    content = re.sub(r'\* Wfuzz.*\n\*.*\n\*{3,}', '', content).strip()
                    processed = re.search(r'Processed Requests: (\d+)', content)
                    filtered = re.search(r'Filtered Requests: (\d+)', content)
                    if processed and filtered and processed.group(1) == filtered.group(1):
                        content = "" 

                if tool_name.upper() == "NIKTO":
                    content = re.sub(r'- Nikto v.*\n-+', '', content).strip()
                    if "0 host(s) tested" in content or not content:
                        content = ""

                master_html += f"<h2 style='color:#00ffff; margin-top: 30px;'>▶ {tool_name.upper()}</h2>"
                
                lower_c = content.lower()
                
                empty_flags = [
                    "0 hosts", "total requests: 0", "execution expired", 
                    "no match for", "appears to be down", "malformed request", 
                    "no assets were discovered", "flag provided but not defined", 
                    "no such option", "missing wordlist", "0 errors and 0 items"
                ]
                
                is_empty = not content or any(flag in lower_c for flag in empty_flags)

                if is_empty:
                    master_html += f"<p style='color:#888888;'><i>[-] No significant data or vulnerabilities found using this tool.</i></p>"
                else:
                    master_html += f"<pre style='color:#00ff00; background:#0a0a0c; padding:15px; border:1px solid #1a5e20; border-radius: 5px; white-space: pre-wrap; word-wrap: break-word;'>{content}</pre>"
            except Exception as e:
                pass
                
        master_html += "</body></html>"
        
        report_path = os.path.join(save_dir, f"MASTER_REPORT_{target}.html")
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(master_html)

    def update_dashboard(self):
        html = f"<div style='background-color:#0d0d0d; color:#00ff00; font-family:monospace; white-space:pre; padding: 10px;'>"
        html += f"{'='*50}\n[#] DEPLOYING DETACHED IP RECON: {self.clean_target}\n"
        html += f"[#] Routed to Workspace: {self.project_name}\n{'='*50}\n\n"
        
        for name, _ in self.tools:
            status = self.tool_status.get(name, {"state": "Queued", "time": ""})
            safe_name = re.sub(r'[^a-zA-Z0-9]', '_', name)
            
            if status["state"] == "Queued":
                html += f"<span style='color:#00ffff;'>[*] Queued:</span> {name} <span style='color:#555;'>-> .../{safe_name}.txt</span>\n"
            elif status["state"] == "Running":
                html += f"<span style='color:#ffff00;'>[▶] Running:</span> {name} <span style='color:#888;'>(Detached Terminal)</span>\n"
            elif status["state"] == "Completed":
                html += f"<span style='color:#00ff00;'>[✔] Completed:</span> {name} <span style='color:#888;'>(Took: {status['time']}s) -> {safe_name}.txt</span>\n"
                
        if self.is_finished:
            html += f"\n{'='*50}\n{self.final_msg}\n{'='*50}\n"
            report_path = os.path.join(self.current_save_dir, f"MASTER_REPORT_{self.clean_target}.html")
            html += f"<br><b style='color:#00ff00;'>[✔] MASTER HTML REPORT COMPILED:</b> <a href='file://{report_path}' style='color:#ffff00;'>{report_path}</a><br>"
        else:
            html += f"\n<b style='color:#ffff00;'>[🚀] Payload running in detached native terminal...</b>\n"
            
        html += "</div>"
        self.output_signal.emit(html)

    def run(self):
        pipeline_start = time.time()
        
        for target in self.targets:
            if not self.is_running: break
            self.clean_target = re.sub(r'^https?://', '', target).rstrip('/')
            
            self.tool_status = {name: {"state": "Queued", "time": ""} for name, _ in self.tools}
            self.is_finished = False
            self.update_dashboard()
            
            ts = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            target_save_dir = os.path.abspath(f"Scan_Results/{self.project_name}/AutoScanIP_{self.clean_target}_{ts}")
            os.makedirs(target_save_dir, exist_ok=True)
            self.current_save_dir = target_save_dir
            
            script_path = os.path.join(target_save_dir, "recon_runner.sh")
            sync_file = os.path.join(target_save_dir, ".gui_sync.log")
            abort_file = os.path.join(target_save_dir, ".abort_scan").replace("\\", "/")
            
            open(sync_file, 'w').close()
            if os.path.exists(abort_file): os.remove(abort_file)
            
            bash_content = "#!/bin/bash\n"
            bash_content += "trap 'kill $(jobs -p) 2>/dev/null' EXIT\n\n"
            bash_content += f"echo '=================================================='\n"
            bash_content += f"echo '  ARF DETACHED IP RECONNAISSANCE ENGINE'\n"
            bash_content += f"echo '  Target: {self.clean_target}'\n"
            bash_content += f"echo '=================================================='\n\n"
            
            # Navigate into the save directory so screenshots save here natively
            bash_content += f"cd '{target_save_dir}'\n\n"
            
            # Start the abort watcher and capture its PID
            bash_content += f"( while true; do if [ -f '{abort_file}' ]; then echo ''; echo '[!] SCAN TERMINATED BY USER!'; sleep 2; kill 0; fi; sleep 1; done ) &\n"
            bash_content += "ABORT_PID=$!\n\n"

            bash_content += "echo '[*] Initiating Dynamic Parallel Execution (Max 3 Concurrent)...'\n"
            bash_content += "MAX_TOTAL_JOBS=4\n" # 3 tools + 1 abort watcher
            bash_content += "ALL_PIDS=\"\"\n\n"
            
            for tool_name, cmd_template in self.tools:
                safe_target = f"'{self.clean_target.replace('\'', '')}'"
                safe_wordlist = f"'{self.wordlist.replace('\'', '')}'"
                cmd = [arg.replace("{t}", safe_target).replace("{wordlist}", safe_wordlist) for arg in cmd_template]
                cmd_str = " ".join(cmd)
                safe_tool_name = re.sub(r'[^a-zA-Z0-9]', '_', tool_name)
                out_file = os.path.join(target_save_dir, f"{safe_tool_name}.txt")
                
                # --- TERMINAL GLITCH FIX: Pure ASCII text with no \e codes ---
                bash_content += f"echo '[>] Launching: {tool_name}'\n"
                bash_content += f"echo \"LAUNCH:{tool_name}\" >> '{sync_file}'\n"
                bash_content += "(\n"
                bash_content += "  START_TIME=$(date +%s)\n"
                bash_content += f"  eval \"{cmd_str}\" < /dev/null > '{out_file}' 2>&1\n"
                bash_content += "  END_TIME=$(date +%s)\n"
                bash_content += "  ELAPSED=$((END_TIME - START_TIME))\n"
                bash_content += f"  echo \"DONE:{tool_name}:${{ELAPSED}}\" >> '{sync_file}'\n"
                bash_content += f"  echo \"[+] Completed: {tool_name} (Took: ${{ELAPSED}}s) -> {safe_tool_name}.txt\"\n"
                bash_content += ") &\n"
                bash_content += "ALL_PIDS=\"$ALL_PIDS $!\"\n\n"
                
                bash_content += "while [ $(jobs -p | wc -l) -ge $MAX_TOTAL_JOBS ]; do sleep 1; done\n\n"
                
            bash_content += "echo '--- All payloads launched. Waiting for final tasks to cross the finish line... ---'\n"
            bash_content += "wait $ALL_PIDS\n\n" 
            
            # Kill the abort watcher so the script can naturally exit
            bash_content += "kill $ABORT_PID 2>/dev/null\n\n"

            bash_content += "echo ''\n"
            bash_content += "echo '[+] ALL RECON TASKS COMPLETED!'\n"
            bash_content += f"touch '{os.path.join(target_save_dir, '.scan_done')}'\n"
            bash_content += "read -p 'Press Enter to close this window...' -n 1\n"

            with open(script_path, 'w') as f:
                f.write(bash_content)
            os.chmod(script_path, 0o755)

            try:
                if platform.system() == "Windows":
                    subprocess.Popen(f'start cmd.exe /K "{script_path}"', shell=True)
                else:
                    terminals = ['x-terminal-emulator', 'qterminal', 'gnome-terminal', 'konsole', 'xfce4-terminal', 'xterm']
                    spawned = False
                    for term in terminals:
                        try:
                            if term == 'gnome-terminal':
                                subprocess.Popen([term, '--', 'bash', '-c', script_path], start_new_session=True)
                            else:
                                subprocess.Popen([term, '-e', f'bash -c "{script_path}"'], start_new_session=True)
                            spawned = True
                            break
                        except FileNotFoundError:
                            continue
                    if not spawned:
                        self.error_signal.emit("Could not find a supported terminal emulator to spawn.")
            except Exception as e:
                self.error_signal.emit(f"Failed to launch terminal: {str(e)}")

            done_file = os.path.join(target_save_dir, '.scan_done')
            last_pos = 0
            
            while self.is_running and not os.path.exists(done_file):
                if os.path.exists(sync_file):
                    with open(sync_file, 'r') as f:
                        f.seek(last_pos)
                        for line in f:
                            line = line.strip()
                            if line.startswith("LAUNCH:"):
                                t_name = line.split(":", 1)[1]
                                if t_name in self.tool_status:
                                    self.tool_status[t_name]["state"] = "Running"
                                    self.update_dashboard()
                            elif line.startswith("DONE:"):
                                parts = line.split(":")
                                t_name = parts[1]
                                elapsed = parts[2] if len(parts) > 2 else "?"
                                if t_name in self.tool_status:
                                    self.tool_status[t_name]["state"] = "Completed"
                                    self.tool_status[t_name]["time"] = elapsed
                                    self.update_dashboard()
                        last_pos = f.tell()
                time.sleep(0.5)
                
            if os.path.exists(sync_file):
                with open(sync_file, 'r') as f:
                    f.seek(last_pos)
                    for line in f:
                        line = line.strip()
                        if line.startswith("DONE:"):
                            parts = line.split(":")
                            t_name = parts[1]
                            elapsed = parts[2] if len(parts) > 2 else "?"
                            if t_name in self.tool_status:
                                self.tool_status[t_name]["state"] = "Completed"
                                self.tool_status[t_name]["time"] = elapsed
                                
            self.is_finished = True
            total_time = int(time.time() - pipeline_start)
            m, s = divmod(total_time, 60)
            
            if self.is_running:
                self.final_msg = f"<b style='color:#00ff00;'>[+] IP PIPELINE COMPLETED IN: {m}m {s}s</b>"
            else:
                self.final_msg = f"<b style='color:#ff0000;'>[-] PIPELINE ABORTED BY USER AFTER: {m}m {s}s</b>"
                
            self.compile_master_report(target_save_dir, self.clean_target)
            self.update_dashboard()

            # --- SQLITE SIPHON FOR BASH OUTPUT ---
            scan_id = os.path.basename(target_save_dir)
            db.save_scan_meta(scan_id, self.project_name, self.clean_target, "BashAutoScan", 0, self.exec_mode)
            for file_name in os.listdir(target_save_dir):
                if file_name.endswith(".txt") and "MASTER" not in file_name:
                    file_path = os.path.join(target_save_dir, file_name)
                    try:
                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                            db.save_tool_output(scan_id, file_name.replace('.txt', ''), f.read())
                        os.remove(file_path)
                    except Exception: pass

            try: 
                os.remove(done_file)
                os.remove(sync_file)
                os.remove(abort_file)
            except: pass

        self.finished_signal.emit()