import sys
import os  
import argparse

# ========================================================
# --- THE GLOBAL WORKSPACE REDIRECT ---
# We force the application to 'run' from the user's home directory.
home_dir = os.path.expanduser("~")
workspace_dir = os.path.join(home_dir, "ARF_Workspace")
os.makedirs(workspace_dir, exist_ok=True)
os.chdir(workspace_dir)

# --- NEW: THE PLAYWRIGHT PATH FIX ---
# Tell the app to use the self-contained browser folder!
os.environ["PLAYWRIGHT_BROWSERS_PATH"] = "/opt/arf/pw-browsers"
# ========================================================

from PyQt6.QtWidgets import QApplication
from PyQt6.QtGui import QIcon  

# 1. Initialize OS settings BEFORE PyQt6 loads
import core.env 

# 2. Import core architecture
from core.config import initialize_environment
from gui.master_hub import MasterHub
from cli.handler import interactive_cli_menu, run_headless_auto

if __name__ == "__main__":
    # --- PHASE 1: BOOTSTRAP ---
    initialize_environment()
    
    # --- PHASE 2: PARSE ARGUMENTS ---
    parser = argparse.ArgumentParser(description="ALI RAZA RECON FRAMEWORK (ARF) v1.0 - Hacker Edition")
    
    parser.add_argument("-i", "--interactive", action="store_true", help="Launch the Interactive CLI Menu")
    parser.add_argument("-e", "--engine", choices=["live", "domain", "ip", "spider", "install", "tool"], help="Headless execution engine")
    parser.add_argument("-d", "--targets", help="Target domain(s) or IP(s), comma-separated")
    parser.add_argument("-w", "--wordlist", default="wordlist.txt", help="Path to wordlist")
    parser.add_argument("--scope", default="", help="Out of scope regex/keywords")
    parser.add_argument("-p", "--project", default="Default_Workspace", help="Workspace / Project Name")
    parser.add_argument("-s", "--shodan", default="", help="Shodan API Key")
    parser.add_argument("-t", "--threads", type=int, default=50, help="Threads for resolution")
    parser.add_argument("--webhook", default="", help="Discord/Slack Webhook")
    parser.add_argument("--continuous", action="store_true", help="Enable continuous monitoring loop")
    parser.add_argument("--interval", type=int, default=60, help="Interval in mins for continuous mode")
    parser.add_argument("--toolname", default="", help="Name of the binary to execute")
    parser.add_argument("--toolargs", default="", help="Arguments. Use {t} for target injection.")
    
    args = parser.parse_args()

    # --- PHASE 3: ROUTE EXECUTION ---
    if args.interactive:
        interactive_cli_menu()
    elif args.engine:
        if args.engine != "install" and not args.targets:
            print("[-] Error: -d / --targets is required for this engine.")
            sys.exit(1)
        run_headless_auto(args)
    else:
        # Launch Desktop GUI Mode
        app = QApplication(sys.argv)
        
        # ========================================================
        # --- THE LINUX TASKBAR MAPPING FIX ---
        app.setDesktopFileName("arf.desktop")
        
        # Look for the installed system icon first!
        system_icon = "/usr/share/pixmaps/arf-icon.png"
        local_icon = os.path.join(os.path.dirname(__file__), "icon.png")
        
        if os.path.exists(system_icon):
            app.setWindowIcon(QIcon(system_icon))
        elif os.path.exists(local_icon):
            app.setWindowIcon(QIcon(local_icon)) # Fallback for dev mode
        # ========================================================
        
        hub = MasterHub()
        hub.show()
        sys.exit(app.exec())